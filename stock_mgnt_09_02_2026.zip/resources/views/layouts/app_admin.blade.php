<!DOCTYPE html>
<html lang="en" data-layout-mode="light_mode">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="noindex, nofollow">
	<title>Accounting and Stock Management System</title>
	<meta name="csrf-token" content="{{ csrf_token() }}">
	@include('partials.admin.style')
	<!-- jQuery -->
	<script src="{{asset('admin/assets/js/jquery-3.7.1.min.js')}}"></script>
	<!-- <script src="{{asset('admin/assets/js/jquery.dataTables.min.js')}}"></script> -->
	@yield('style')
</head>

<body>
	<div id="global-loader">
		<div class="whirly-loader"> </div>
	</div>
	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<!-- Header -->
		@include('partials.admin.header')
		<!-- /Header -->
		@php //print_r(Auth::user()->role_id);die;@endphp
		<!-- Sidebar -->
		@if(Auth::check())
		@if(Auth::user()->role_id == 1)
		@include('partials.admin.sidebar_superadmin')
		@elseif(Auth::user()->role_id == 2)
		@include('partials.admin.sidebar_admin')
		@elseif(Auth::user()->role_id == 3)
		@include('partials.admin.sidebar_storemanager')
		@elseif(Auth::user()->role_id == 5)
		@include('partials.admin.sidebar_clerk')
		@endif
		@endif

		<!-- /Sidebar -->


		@include('partials.admin.model')



		@yield('content')

	</div>
	<!-- /Main Wrapper -->

	@include('partials.admin.footer')
	@yield('scripts')
	<script>
		$(document).on('click', '#refresh-page', function (e) {
			e.preventDefault();
			location.reload();
		});
	</script>

</html>