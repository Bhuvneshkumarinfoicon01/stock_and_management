@extends('layouts.app_admin') @section('title') Dashbaord @endsection
@section('styles') @endsection @section('content')>

<div class="page-wrapper">
    <div class="content settings-content">
        <div class="row">
            <div class="col-xl-12">
                <div class="settings-wrapper d-flex">
                    <div class="settings-page-wrap">
                        <div class="setting-title">
                            <h4>Settings</h4>
                        </div>
                        <div class="security-settings">


                            <form action="{{route('admin.setting-store')}}" method="POST">
                                @csrf
                                <div class="row">
                                    @foreach($settings as $setting)
                                    <div class="col-lg-3 col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{$setting->label}}</label>
                                            <input type="text" placeholder="{{$setting->placeholder}}"
                                                name="{{$setting->key_name}}"
                                                class="form-control @error($setting->key_name) is-invalid @enderror"
                                                value="{{ old($setting->key_name, $setting->value ?? '') }}">
                                            @error($setting->key_name)
                                            <div class="invalid-feedback d-block">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    @endforeach

                                </div>

                                <div class="text-end settings-bottom-btn">
                                    <a href="javascript:void(0);" class="btn btn-cancel me-2">Reset</a>
                                    <button type="submit" class="btn btn-submit">Save Changes</button>
                                </div>
                            </form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('scripts')

@if (session('success'))
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "{{ Js::from(session('success')) }}",
        timer: 2000,
        showConfirmButton: false
    });
</script>
@endif
@endsection