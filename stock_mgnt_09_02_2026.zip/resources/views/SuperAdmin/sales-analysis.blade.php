@extends('layouts.app_admin')

@section('title')
Dashbaord
@endsection

@section('styles')

@endsection

@section('content')



			<div class="page-wrapper">
				<div class="content">
					<div class="page-header">
						<div class="add-item d-flex">
							<div class="page-title">
								<h4>Sales Analysis</h4>
								<h6>Manage your Profit & Loss</h6>
							</div>
						</div>
						<ul class="table-top-head">
							<!-- <li>
								<a data-bs-toggle="tooltip" data-bs-placement="top" title="Pdf"><img src="assets/img/icons/pdf.svg" alt="img"></a>
							</li>
							<li>
								<a data-bs-toggle="tooltip" data-bs-placement="top" title="Excel"><img src="assets/img/icons/excel.svg" alt="img"></a>
							</li>
							<li>
								<a data-bs-toggle="tooltip" data-bs-placement="top" title="Print"><i data-feather="printer" class="feather-rotate-ccw"></i></a>
							</li> -->
							<li>
								<a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh" id="refresh-page"><i data-feather="rotate-ccw" class="feather-rotate-ccw"></i></a>
							</li>
							<li>
								<a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i data-feather="chevron-up" class="feather-chevron-up"></i></a>
							</li>
						</ul>
					</div>
					
				



					<div class="row mt-5">
						<div class="col-xl-12 col-sm-12 col-12 d-flex">
							<div class="card flex-fill default-cover">
								<div class="card-header d-flex justify-content-between align-items-center">
									<div class="finance-charts d-flex gap-3">
										<select id="filter-store" class="select">
											<option value="">Choose Store</option>
											@foreach($stores as $store)
												<option value="{{ $store->id }}">{{ $store->name }}</option>
											@endforeach
										</select>
									
										<select id="filter-category" class="select">
											<option value="">Choose Category</option>
											@foreach($categories as $category)
												<option value="{{ $category->id }}">{{ $category->name }}</option>
											@endforeach
										</select>
									
										<button id="search-btn" class="btn btn-primary">Search</button>
									</div>
									
								</div>
								
								<div class="card-body">
									<div id="sales-analysis-chart" class="chart-set"></div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>


       

	
@endsection
@section('scripts')
<script>
    document.getElementById("search-btn").addEventListener("click", function () {
        const storeId = document.getElementById("filter-store").value;
        const categoryId = document.getElementById("filter-category").value;

        fetch(`{{ url()->current() }}?store_id=${storeId}&category_id=${categoryId}`, {
            method: "GET",
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        })
        .then(response => response.json())
        .then(data => {
            // Define months for x-axis
            const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
            let monthlyTotals = {};
            // Initialize monthly totals to 0 for all months
            months.forEach(m => monthlyTotals[m] = 0);

            // Populate monthly totals with data from the response
            data.forEach(row => {
                monthlyTotals[row.month] = parseFloat(row.total);
            });

            // Create the chart data array based on the updated monthly totals
            const chartData = months.map(m => monthlyTotals[m]);

            // Configure chart options
            const options = {
                series: [{
                    name: "Sales Analysis",
                    data: chartData // Data for the chart
                }],
                chart: {
                    height: 273,
                    type: "area",
                    zoom: { enabled: false }
                },
                colors: ["#FF9F43"], // Chart line color
                dataLabels: { enabled: false }, // Disable data labels on the chart
                stroke: { curve: "straight" }, // Smooth line curve
                xaxis: {
                    categories: months, // Set months as x-axis categories
                },
                yaxis: {
                    min: 0, // Minimum value of y-axis
                    max: Math.max(...chartData) * 1.2, // Dynamically set max y-axis value based on data
                    tickAmount: 5,
                    labels: {
    					formatter: val => (val / 1000).toFixed(2) + "K"
					}
                },
                legend: {
                    position: "top",
                    horizontalAlign: "left",
                }
            };

            // Clear existing chart and render the updated chart
            document.querySelector("#sales-analysis-chart").innerHTML = "";
            new ApexCharts(document.querySelector("#sales-analysis-chart"), options).render();
        });
    });
</script>


	
@endsection