<?php

use App\Http\Controllers\admin\BalanceSheetController;
use App\Http\Controllers\admin\CategoryController;
use App\Http\Controllers\admin\ClerkDashboardController;
use App\Http\Controllers\admin\CommunicationController;
use App\Http\Controllers\admin\CustomerController;
use App\Http\Controllers\admin\DailyOperationsController;
use App\Http\Controllers\admin\DashboardController;
use App\Http\Controllers\admin\HistoryController;
use App\Http\Controllers\admin\IncomingStockController;
use App\Http\Controllers\admin\InventoryDashboardController;
use App\Http\Controllers\admin\InventoryFlowController;
use App\Http\Controllers\admin\InventoryReportController;
use App\Http\Controllers\admin\InvoiceController;
use App\Http\Controllers\admin\LedgerController;
use App\Http\Controllers\admin\NotificationController;
use App\Http\Controllers\admin\OrderController;
use App\Http\Controllers\admin\OutgoingStockController;
use App\Http\Controllers\admin\PerformingProductController;
use App\Http\Controllers\admin\PermissionController;
use App\Http\Controllers\admin\ProfitLossController;
use App\Http\Controllers\admin\RealTimeUpdatesController;
use App\Http\Controllers\admin\ReportSectionController;
use App\Http\Controllers\admin\SalesAnalysisSuperAdminController;
use App\Http\Controllers\admin\SalesPerformanceController;
use App\Http\Controllers\admin\SalesTrendController;
use App\Http\Controllers\admin\SettingController;
use App\Http\Controllers\admin\SidebarLinksController;
use App\Http\Controllers\admin\StockAdjustmentController;
use App\Http\Controllers\admin\StockController;
use App\Http\Controllers\admin\StockTransferController;
use App\Http\Controllers\admin\StoreController;
use App\Http\Controllers\admin\StoreManagerDashboardController;
use App\Http\Controllers\admin\SuperAdminDashboardController;
use App\Http\Controllers\admin\UnitController;
use App\Http\Controllers\admin\UserController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ResetPasswordController;
use App\Mail\StockTransferNotification;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('login');
// });

Route::get('/send-mail', function () {
    $recipientEmail = 'dev12@infoiconsoftware.com';
    $subject = 'Test Email from Laravel 12';
    $messageBody = 'This is a test email sent from Laravel 12';

    try {
        Mail::raw($messageBody, function ($message) use ($recipientEmail, $subject) {
            $message
                ->to($recipientEmail)
                ->subject($subject);
        });

        return response('Email sent successfully!', 200);
    } catch (\Exception $e) {
        return response('Error sending email: ' . $e->getMessage(), 500);
    }
});
Route::get('/send-stock-transfer-mail', function () {
    $transfer = (object) [
        'store_from' => 'Store A',
        'store_to' => 'Store B',
        'reference_no' => 'REF123456',
        'arrival_date' => now()->format('Y-m-d'),
        'notes' => 'Test stock transfer'
    ];

    $items = [
        (object) [
            'product_name' => 'Product X',
            'qty' => 10
        ]
    ];

    try {
        Mail::to('dev12@infoiconsoftware.com')->send(new StockTransferNotification($transfer, $items));
        return 'Stock transfer mail sent successfully.';
    } catch (\Exception $e) {
        return 'Mail send failed: ' . $e->getMessage();
    }
});
Route::get('/', [LoginController::class, 'login_view'])->name('login_view');
// Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/', [LoginController::class, 'login'])->name('login');
// Forgot Password
Route::get('/forgot-password', [ForgotPasswordController::class, 'index'])->name('forgot-password');
Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('/reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');

Route::group(['middleware' => ['auth']], function () {
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

    Route::get('/users', [UserController::class, 'getuser'])->name('admin.users');
    Route::post('/users/add', [UserController::class, 'add'])->name('add-employee');

    // Route::get('/json-data', [UserController::class, 'getjsondata'])->name('json-data');
    Route::get('/view-employee', [UserController::class, 'viewEmployee'])->name('view-employee');
    Route::get('/edit-employee/{id}', [UserController::class, 'edit'])->name('edit-employee');
    Route::post('/update-employee', [UserController::class, 'update'])->name('update-employee');

    Route::delete('/delete-employee/{id}', [UserController::class, 'destroy'])->name('delete-employee');

    Route::get('/profile', [UserController::class, 'getData'])->name('profile');
    Route::post('/profile', [UserController::class, 'getProfileInfo'])->name('postProfile');
    Route::get('/change-password', [UserController::class, 'changePassword'])->name('change-password');
    Route::post('/change-password', [UserController::class, 'updatePassword'])->name('update-password');
});

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'middleware' => ['auth']], function () {
    Route::get('/superadmin-dashboard', [SuperAdminDashboardController::class, 'superadminDashboard'])->name('superadmin_dashboard');
    Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('/storemanager_dashboard', [StoreManagerDashboardController::class, 'storemanagerDashboard'])->name('storemanager_dashboard');
    Route::get('/clerk_dashboard', [ClerkDashboardController::class, 'ClerkDashboard'])->name('clerk_dashboard');

    Route::group(['prefix' => 'stock'], function () {
        Route::get('list', [StockController::class, 'index'])->name('stock.list');
        Route::get('create', [StockController::class, 'create'])->name('stock.create');
        Route::get('edit/{stock}', [StockController::class, 'edit'])->name('stock.edit');
        Route::post('store', [StockController::class, 'store'])->name('stock.store');
        // Route::put('update/{id}', [StockController::class, 'update'])->name('stock.update');
        Route::put('update/{stock}', [StockController::class, 'update'])->name('stock.update');
        Route::delete('delete/{id}', [StockController::class, 'destroy'])->name('stock.delete');
        // EXPORTS
        Route::get('exports', [StockController::class, 'export'])->name('stocks-export');
        Route::get('list-storeMangaer', [StockController::class, 'indexStoreManager'])->name('stock.list.storemanager');
        // IMPORTING CSV FILE
        Route::post('stocks-import', [StockController::class, 'import'])->name('stocks-import');
        Route::post('upload-images', [StockController::class, 'uploadImages'])->name('stocks-upload-images');

        Route::get('admin/stocks/download-dummy', [StockController::class, 'downloadDummy'])->name('stocks-dummy-download');
    });
    Route::group(['prefix' => 'store'], function () {
        Route::post('/store', [StoreController::class, 'store'])->name('stores_store');
        Route::get('/all', [StoreController::class, 'allStores'])->name('stores_all');

        Route::get('/daily-operations', [DailyOperationsController::class, 'dailyoperations'])->name('daily-operations-overview-admin');
        Route::get('/daily-sales-overview', [DailyOperationsController::class, 'dailySalesOverview'])->name('daily-sales-overview-admin');
    });
    /*Route::group(['prefix' => 'category'], function () {
        Route::get('list', [CategoryController::class,'index'])->name('category.list');
        Route::get('create', [CategoryController::class,'create'])->name('category.create');
        Route::get('edit/{id}', [CategoryController::class,'edit'])->name('category.edit');
        Route::post('store', [CategoryController::class,'storeUpdate'])->name('category.store');
    });*/
    Route::get('/storeCommunication', [CommunicationController::class, 'communications'])->name('stores_communication');
    Route::get('/superAdmin-stor2storecomm', [CommunicationController::class, 'communicationSuperAdmin'])->name('stor2storecomm-superadmin');
    Route::get('/storeManage-stor2storecomm', [CommunicationController::class, 'communicationStoreManager'])->name('stor2storecomm-storemanager');
    Route::get('/fetch-messages', [CommunicationController::class, 'fetchMessages'])->name('fetchMessages');
    Route::post('/store', [CommunicationController::class, 'storeMessage'])->name('messages.store');
    Route::get('/fetch-unread-messages', [CommunicationController::class, 'fetchUnreadMessages'])->name('fetchUnreadMessages');
    Route::post('/mark-messages-as-read', [CommunicationController::class, 'markMessagesAsRead'])->name('markMessagesAsRead');
    Route::post('/send-notification', [NotificationController::class, 'sendNotification']);
    Route::get('/notifications/fetch', [NotificationController::class, 'fetchUserNotifications'])->name('notifications.fetch');
    Route::delete('/notifications/clear', [NotificationController::class, 'clear'])->name('notifications.clear');

    Route::resource('categories', CategoryController::class);

    // Route::resource('orders', OrderController::class);
    Route::resource('stocktransfers', StockTransferController::class);
    Route::resource('units', UnitController::class);

    Route::get('pos-terminal', [OrderController::class, 'index'])->name('pos-terminal');
    Route::get('create', [OrderController::class, 'create'])->name('category.create');
    Route::get('edit/{id}', [OrderController::class, 'edit'])->name('category.edit');
    // Route::post('store', [OrderController::class,'storeUpdate'])->name('category.store');
    Route::post('/add-to-cart', [OrderController::class, 'addToCart'])->name('add.to.cart');
    Route::get('/get-cart', [OrderController::class, 'getCart'])->name('get.cart');
    Route::post('remove-from-cart', [OrderController::class, 'removeFromCart'])->name('remove.from.cart');
    Route::post('clear-cart', [OrderController::class, 'clearCart'])->name('clear.cart');
    Route::post('place-order', [OrderController::class, 'placeOrder'])->name('place-order');
    Route::post('/create-customer', [CustomerController::class, 'store'])->name('create-customer');  // CREATING NEW CUSTOMER

    Route::get('stock-transfer', [StockTransferController::class, 'index'])->name('stock-transfer');
    Route::post('stock-transfer', [StockTransferController::class, 'storeTransfer'])->name('stock-transfer.store');
    Route::get('get-stores', [StockTransferController::class, 'getStores'])->name('get-stores');  // orderController new function
    Route::get('get-products', [StockTransferController::class, 'getProductsByStore'])->name('get-products');  // orderController new function
    Route::get('stock-transfer/edit/{id}', [StockTransferController::class, 'edit'])->name('stock-transfer.edit');
    Route::post('stock-transfer/update', [StockTransferController::class, 'updateTransfer'])->name('stock-transfer.update');
    Route::delete('/delete-transfer', [StockTransferController::class, 'destroy'])->name('stock-transfer-delete');

    Route::get('stock-adjustment', [StockAdjustmentController::class, 'showAdjustmentForm'])->name('stock-adjustment');
    Route::post('stock-adjustment', [stockAdjustmentController::class, 'createAdjustment'])->name('create-adjustment');
    Route::put('update/{id}', [StockAdjustmentController::class, 'update'])->name('update-adjustment');
    // Route::post('update/{id}', [StockAdjustmentController::class, 'update'])->name('update-adjustment');
    Route::delete('adjustment/{id}/delete', [StockAdjustmentController::class, 'destroy'])->name('delete-adjustment');
    Route::get('/get-adjustment-data/{id}', [StockAdjustmentController::class, 'getAdjustmentData'])->name('get-adjustment-data');

    Route::view('profit-loss', 'admin.profit-loss-statement')->name('profit-loss-statement');
    Route::get('/profit-loss/sales', [ProfitLossController::class, 'getMonthlySales'])->name('profit-loss.sales');  // for getting json data for profit loss staement
    Route::view('balance-sheet', 'admin.balance-sheet')->name('balance-sheet');
    Route::get('/balance-sheet/data', [BalanceSheetController::class, 'getBalanceSheetData'])->name('balance-sheet-data');

    // //////////////////////////////////////////////////////////////////////////////////////////////////////////// INOVICE
    Route::get('invoice', [InvoiceController::class, 'index'])->name('invoice');
    Route::get('/view-invoice', [InvoiceController::class, 'viewInvoice'])->name('view-invoice');
    Route::get('invoice-filter', [InvoiceController::class, 'filter'])->name('invoice.filter');

    // //////////////////////////////////////////////////////////////////////////////////////////////////////////// LEDGER
    // Route::view('ledger-view', 'admin.view-ledger')->name('view-ledger');
    Route::group(['prefix' => 'ledger'], function () {
        Route::get('/', [LedgerController::class, 'index'])->name('ledger');
        Route::post('store-ledger', [LedgerController::class, 'storeLedger'])->name('store-ledger');  // STORES LEDGER TO DB
        Route::get('view-ledger/{id}', [LedgerController::class, 'viewLedgerEntries'])->name('ledgerEntries');
        Route::get('{id}/entries', [LedgerController::class, 'getLedgerEntries'])->name('get-ledger-entries');
        Route::post('{id}/update', [LedgerController::class, 'updateLedger'])->name('update-ledger');
        Route::delete('{id}', [LedgerController::class, 'destroy'])->name('delete-ledger');
    });

    // ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    Route::get('transaction-mgnt', [OrderController::class, 'manageTransactions'])->name('transaction-manage');  // TRANSACTION_MANAGE
    Route::get('order-items/{order_id}', [OrderController::class, 'getOrderItems'])->name('get-orderItems');  // GET-ORDER-ITEMS
    Route::view('pos-sale-insight', 'admin.pos-sale-insight')->name('pos-sale-insight');

    Route::get('inventory-flow-admin', [InventoryFlowController::class, 'index'])->name('inventory-flow-admin');
    Route::get('inventory-flow-superAdmin', [InventoryFlowController::class, 'indexSuperAdmin'])->name('inventory-flow-superAdmin');
    Route::get('top-performing-product', [PerformingProductController::class, 'index'])->name('top-performing-product');
    Route::get('/top-products-data', [PerformingProductController::class, 'getTopProductsData'])->name('top-products-data');
    Route::get('/under-products-data', [PerformingProductController::class, 'getUnderProductsData'])->name('under-products-data');
    Route::get('/top-products-data/view-all', [PerformingProductController::class, 'topViewAll'])->name('top-view-all');
    Route::get('/under-products-data/view-all', [PerformingProductController::class, 'underViewAll'])->name('under-view-all');
    // ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // STORE- MANAGER ROUTES//

    Route::get('sales', [InvoiceController::class, 'sales'])->name('sales');
    Route::get('/view-details', [InvoiceController::class, 'showSalesDetail'])->name('sales_details');
    Route::get('storemanager/sales-trend', [SalesTrendController::class, 'storemgrSalesReport'])->name('salesTrend');

    Route::get('customer-report', [InvoiceController::class, 'customerReportIndex'])->name('customer-report');
    Route::get('customer-report-sold-products', [InvoiceController::class, 'soldProductReportIndex'])->name('customer-report-sold-products');
    Route::get('incoming-stock', [IncomingStockController::class, 'index'])->name('incoming-stock');
    Route::post('/update-transfer-status/{id}', [IncomingStockController::class, 'updateTransferStatus'])->name('update-transfer-status');

    Route::get('outgoing-stock', [OutgoingStockController::class, 'index'])->name('outgoing-stock');
    Route::get('real-time-stock', [RealTimeUpdatesController::class, 'index'])->name('real-time-stock');
    Route::get('sales-performance', [SalesPerformanceController::class, 'index'])->name('sales-performance');
    // Route::get('/monthly-data', [SalesPerformanceController::class, 'getMonthlySalesData'])->name('monthly-data');

    Route::get('inventory-report', [InventoryReportController::class, 'index'])->name('inventory-report');
    Route::get('inventory-report/outOfStock-view', [InventoryReportController::class, 'getOutOfStock'])->name('outOfStock-view');
    Route::get('inventory-report/lowOnStock-view', [InventoryReportController::class, 'getLowStock'])->name('lowOnStock-view');

    // Route::view('stor2storecomm', 'storemanager.stor2storecomm')->name('stor2storecomm');
    Route::get('employee-list', [StoreController::class, 'index'])->name('employee-list');
    // Route::view('User', 'storemanager.User')->name('User');
    Route::get('setting', [SettingController::class, 'index'])->name('setting');
    Route::post('seetings-store', [SettingController::class, 'storeSetting'])->name('setting-store');

    Route::post('/select-store', [StoreController::class, 'selectStore'])->name('select.store');
    Route::post('add', [StoreController::class, 'addEmployee'])->name('add-store-staff');
    Route::get('/view-staff', [StoreController::class, 'viewEmployee'])->name('view-staff');
    Route::get('/edit-staff', [StoreController::class, 'editEmployee'])->name('edit-staff');
    Route::post('/update-staff', [StoreController::class, 'updateEmployee'])->name('update-staff');
    Route::delete('/delete-staff', [StoreController::class, 'deleteEmployee'])->name('delete-staff');

    Route::get('customer', [CustomerController::class, 'index'])->name('customer');
    Route::get('/view-customer', [CustomerController::class, 'viewCustomer'])->name('view-customer');
    Route::get('/edit-customer', [CustomerController::class, 'editCustomer'])->name('edit-customer');
    Route::post('/update-customer', [CustomerController::class, 'updateCustomer'])->name('update-customer');
    Route::delete('/delete-customer', [CustomerController::class, 'deleteCustomer'])->name('delete-customer');

    Route::get('payment-trend-data', [DashboardController::class, 'getPaymentTrendData'])->name('payment.trend.data');  // PAYMENT METHOD CHART IN SALES INSIGHT
    Route::get('dashboard/pos-sales-data', [DashboardController::class, 'getPosSalesData']);  // POS SALES CHART IN SALES INSIGHT

    Route::get('sales-trend', [SalesTrendController::class, 'index'])->name('sales-trend');
    Route::get('/sales-trend-report/fetch', [SalesTrendController::class, 'fetchSalesData']);
    Route::get('/filter', [SalesTrendController::class, 'filter'])->name('sales-trend-filter');

    // STOREMGR DASBOARD SUB VIEWS
    // Route::view('sales-summary', 'storemanager.index')->name('sales-summary');
    Route::get('report-section', [ReportSectionController::class, 'index'])->name('report-section');
    Route::get('customer-insights', [ReportSectionController::class, 'customerInsightsView'])->name('customer-insights');

    // Route::view('sales-summary', 'storemanager.index')->name('sales-summary');

    Route::get('inventory-summary', [InventoryDashboardController::class, 'index'])->name('inventory-summary');
    Route::get('/low-stock/filter', [InventoryDashboardController::class, 'filterLowStock'])->name('low-stock.filter');
    Route::get('/out-of-stock/filter', [InventoryDashboardController::class, 'filterOutOfStock'])->name('out-of-stock.filter');

    // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // SUPER ADMIN ROUTES SIDEBAR
    Route::view('inventory-dashboard', 'SuperAdmin.inventory')->name('inventory-dashboard');
    Route::view('finance-dashboard', 'SuperAdmin.finance')->name('finance-dashboard');

    Route::get('daily-operations-overview', [DailyOperationsController::class, 'index'])->name('daily-operations-overview-superadmin');
    Route::view('manage-stock', 'SuperAdmin.manage-stocks')->name('manage-stocks-superadmin');

    Route::view('Invoice', 'SuperAdmin.store-manager')->name('store-manager-superadmin');

    Route::get('sales-analysis', [SalesAnalysisSuperAdminController::class, 'index'])->name('sales-analysis-superadmin');

    Route::get('store-list', [StoreController::class, 'superAdminStoreList'])->name('store-list-superadmin');
    Route::get('store-list/edit/{id}', [StoreController::class, 'editStore'])->name('edit-store-superadmin');
    Route::post('store-list/update/{id}', [StoreController::class, 'updateStore'])->name('update-store-superadmin');
    Route::delete('store-list/delete/{id}', [StoreController::class, 'destroy'])->name('delete-store-superadmin');

    Route::get('superAdmin/low-stock-products', [SuperAdminDashboardController::class, 'lowStockProducts'])->name('view-all-low-stock-products');

    // ROUTES FOR STORE EMPLOYEE IN SUPER-ADMIN AND ADMIN SIDEBAR
    Route::get('store-employee', [StoreController::class, 'indexStoreEmployee'])->name('store-employee');
    Route::post('/add-satff-admin', [StoreController::class, 'addEmployeeAdmin'])->name('add-store-staff-admin');
    Route::get('/view-staff-admin', [StoreController::class, 'viewEmployeeAdmin'])->name('view-staff-admin');
    Route::get('/edit-staff-admin', [StoreController::class, 'editEmployeeAdmin'])->name('edit-staff-admin');
    Route::post('/update-staff-admin', [StoreController::class, 'updateEmployeeAdmin'])->name('update-staff-admin');
    Route::delete('/delete-staff-admin', [StoreController::class, 'deleteEmployeeAdmin'])->name('delete-staff-admin');

    // EXPORTS
    Route::get('stock-transfers/export', [StockTransferController::class, 'exportStockTransferData'])->name('stock-transfers.export');
    Route::get('stock-adjustments/export', [StockAdjustmentController::class, 'exportStockAdjustmentData'])->name('stock-adjustments.export');
    Route::get('export-profit-loss', [ProfitLossController::class, 'exportMonthlyProfitLoss'])->name('export.profit-loss');
    Route::get('balance-sheet-export', [BalanceSheetController::class, 'exportBalanceSheet'])->name('balance-sheet.export');

    Route::get('invoices-export', [InvoiceController::class, 'exportCsv'])->name('invoices.export');

    Route::post('change-status', [UserController::class, 'changeStatus'])->name('change-status');
    Route::post('change-status-storeEmployee', [StoreController::class, 'changeStatusStoreEmployee'])->name('change-status-storeEmployee');

    // INVOICE GENERATION
    Route::post('generate-invoice-order', [OrderController::class, 'invoiceOrderCreate'])->name('invoice-order');
    Route::get('get-products-invoice', [InvoiceController::class, 'getProductsByStore'])->name('get-products-invoice');
    Route::get('edit-invoice', [InvoiceController::class, 'editInvoice'])->name('invoice-edit');
    Route::post('update-invoice', [OrderController::class, 'invoiceOrderUpdate'])->name('invoice-update');

    Route::get('/history', [HistoryController::class, 'index'])->name('history.index');
    Route::get('/data', [HistoryController::class, 'data'])->name('history.data');  // DataTables feed
    Route::get('/show/{history}', [HistoryController::class, 'show'])->name('history.show');  // modal payload

    Route::post('/users/save-permissions', [PermissionController::class, 'savePermissions'])->name('save-permission');
    Route::get('/users/{id}/permissions', [PermissionController::class, 'getPermissions']);

    Route::post('/sidebar-links/save', [SidebarLinksController::class, 'store'])->name('sidebar-links.store');
    Route::get('/sidebar-links/fetch', [SidebarLinksController::class, 'fetch'])->name('sidebar-links.fetch');
});
