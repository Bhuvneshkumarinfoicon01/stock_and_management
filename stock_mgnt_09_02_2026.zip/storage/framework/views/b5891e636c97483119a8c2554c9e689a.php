<!DOCTYPE html>
<html>
<head>
    <title>Stock Transfer Notification</title>
</head>
<body>
    <h2>
        <?php echo e($direction === 'incoming' ? 'Incoming Stock Transfer Alert' : 'Outgoing Stock Transfer Confirmation'); ?>

    </h2>

    <p>
        This is to inform you that a stock transfer has been
        <?php echo e($direction === 'incoming' ? 'initiated to your store' : 'sent from your store'); ?>.
    </p>

    <p><strong>Reference No:</strong> <?php echo e($transfer->reference_no); ?></p>
    <p><strong>From:</strong> <?php echo e($storeFrom->name); ?></p>
    <p><strong>To:</strong> <?php echo e($storeTo->name); ?></p>
    <p><strong>Arrival Date:</strong> <?php echo e(\Carbon\Carbon::parse($transfer->arrival_date)->format('d-m-Y')); ?></p>

    <h4>Transferred Items:</h4>
    <ul>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->product_name); ?> - Qty: <?php echo e($item->qty); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\stockmgnt\resources\views/emails/store-manager-stock-transfer.blade.php ENDPATH**/ ?>