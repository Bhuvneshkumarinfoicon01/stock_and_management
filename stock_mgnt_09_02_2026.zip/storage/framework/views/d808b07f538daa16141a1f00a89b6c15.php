<script src="<?php echo e(asset('admin/assets/js/theme-script.js')); ?>"></script>	

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">

	<!-- Datetimepicker CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap-datetimepicker.min.css')); ?>">

	<!-- DataTables CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dataTables.bootstrap5.min.css')); ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<!-- animation CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/animate.css')); ?>">

	<!-- animation CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/boxicons.min.css')); ?>">

	<!-- Select2 CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/select2.min.css')); ?>">

	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">


	<!-- Main CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>"><?php /**PATH /var/www/stockmgnt/resources/views/partials/admin/style.blade.php ENDPATH**/ ?>