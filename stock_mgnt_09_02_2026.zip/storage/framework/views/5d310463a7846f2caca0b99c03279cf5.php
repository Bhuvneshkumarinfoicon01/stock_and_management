 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Report Section</h4>
                </div>
            </div>
            <ul class="table-top-head">
                <!-- <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Pdf"
                        ><img src="assets/img/icons/pdf.svg" alt="img"
                    /></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Excel"
                        ><img src="assets/img/icons/excel.svg" alt="img"
                    /></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Print"
                        ><i
                            data-feather="printer"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li> -->
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Refresh"
                        id="refresh-page"
                        ><i
                            data-feather="rotate-ccw"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Collapse"
                        id="collapse-header"
                        ><i
                            data-feather="chevron-up"
                            class="feather-chevron-up"
                        ></i
                    ></a>
                </li>
            </ul>
        </div>

        <div class="row mt-5">
            <div class="col-xl-12 col-sm-12 col-12">
                <div class="card table-list-card">
                    <div class="add-item ps-4 pt-4 pb-4">
                        <div class="page-title">
                            <h4>Sales Report</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table datanew">
                                <thead>
                                    <tr>
                                        <th>Customer Name</th>
                                        <th>Reference</th>
                                        <th>Date</th>
                                        <th>Payment Status</th>
                                        <th>Grand Total</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Payment Method</th>
                                        <th>Biller</th>
                                    </tr>
                                </thead>
                                <tbody class="sales-list">
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($order->customer_name); ?></td>
                                        <td>INV/<?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->created_at->format('d M Y')); ?></td>
                                        <td>
                                            <?php if($order->status==0): ?>
                                            <span class="badge badge-linedanger"
                                                >Unpaid</span>
                                            <?php else: ?>
                                            <span class="badge badge-linesuccess"
                                                >Paid</span>
                                            <?php endif; ?>    
                                        </td>
                                        <td>$<?php echo e($order->total_price); ?></td>
                                        <td>$<?php echo e($order->total_price); ?></td>
                                        <td>$0.00</td>
                                        <td><?php echo e($order->payment_method); ?></td>
                                        <td>Admin</td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-12 col-sm-12 col-12">
                <div class="card table-list-card">
                    <div class="add-item ps-4 pt-4 pb-4">
                        <div class="page-title">
                            <h4>Customer Report</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table datanew">
                                <thead>
                                    <tr>
                                        <th>Customer ID</th>
                                        <th>Customer Name</th>
                                        <th>Amount</th>
                                        <th>Paid</th>
                                        <th>Due Amount</th>
                                        <th>Status</th>
                                        <th>Payment Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($order->customer_id); ?></td>
                                        <td><?php echo e($order->customer_name); ?></td>
                                        <td>$<?php echo e($order->total_price); ?></td>
                                        <td>$<?php echo e($order->total_price); ?></td>
                                        <td>$0.00</td>
                                        <td>
                                            <span class="badges status-badge"
                                                >Completed</span
                                            >
                                        </td>
                                        <td>
                                            <?php if($order->status==0): ?>
                                            <span class="badge badge-linedanger"
                                                >Unpaid</span>
                                            <?php else: ?>
                                            <span class="badge badge-linesuccess"
                                                >Paid</span>
                                            <?php endif; ?>    
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/storemanager/report-section.blade.php ENDPATH**/ ?>