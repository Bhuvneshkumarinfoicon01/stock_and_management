 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title me-auto">
                <h4>Low On Stocks Report</h4>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 col-lg-12 col-sm-12 col-12">
                <div class="card flex-fill default-cover w-100 mb-4">
                    <div
                        class="card-header d-flex justify-content-between align-items-center"
                    >
                        <h4 class="card-title mb-0">Low on stock products</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-borderless best-seller">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Store</th>
                                        <th>Available Qty</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="product-info">
                                                <a href="#" class="product-img">
                                                    <img src="<?php echo e(asset($product->images ? 'storage/'.$product->images : 'admin\assets\img\avatar\default-product.png')); ?>" alt="product" />


                                                </a>
                                                <div class="info">
                                                    <a
                                                        href="#"
                                                        ><?php echo e($product->product_name); ?></a
                                                    >
                                                    <p class="dull-text">
                                                        $<?php echo e(number_format($product->price,2)); ?>

                                                    </p>
                                                </div>

                                            </div>
                                        </td>
                                        <td>
                                            <p>
                                                <?php echo e($product->store->name ?? 'N/A'); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <?php echo e($product->quantity); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($lowStock->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/viewLowStockProduct.blade.php ENDPATH**/ ?>