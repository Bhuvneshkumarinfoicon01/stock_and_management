<!-- Header -->

<div class="header">
    <!-- Logo -->
    <div class="header-left active">
        <a href="<?php echo e(url('/')); ?>" class="logo logo-normal">
            <h6>Accounting and Stock Management System</h6>
        </a>
        <a href="<?php echo e(url('/')); ?>" class="logo logo-white">
            <h6>Accounting and Stock Management System</h6>
        </a>
        <a href="<?php echo e(url('/')); ?>" class="logo-small">
            <h6>A & S</h6>
        </a>
        <a id="toggle_btn" href="javascript:void(0);">
            <i data-feather="chevrons-left" class="feather-16"></i>
        </a>
    </div>
    <!-- /Logo -->

    <a id="mobile_btn" class="mobile_btn" href="#sidebar">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>

    <!-- Header Menu -->
    <ul class="nav user-menu">
        <!-- Search -->
        <li class="nav-item nav-searchinputs">
            <!-- <div class="top-nav-search">
                <a href="javascript:void(0);" class="responsive-search">
                    <i class="fa fa-search"></i>
                </a>
                <form action="#" class="dropdown">
                    <div
                        class="searchinputs dropdown-toggle"
                        id="dropdownMenuClickable"
                        data-bs-toggle="dropdown"
                        data-bs-auto-close="false"
                    >
                        <input type="text" placeholder="Search" />
                        <div class="search-addon">
                            <span
                                ><i
                                    data-feather="x-circle"
                                    class="feather-14"
                                ></i
                            ></span>
                        </div>
                    </div>
                </form>
            </div> -->
        </li>
        <!-- /Search -->
        <!-- <?php if($user && in_array($user->role_id, [1, 2])): ?>
        <li class="nav-item">
            <div class="page-header mb-0">
                <div class="page-btn">
                    <a
                        href="#"
                        class="btn btn-added"
                        data-bs-toggle="modal"
                        data-bs-target="#add-stores"
                        ><i data-feather="plus-circle" class="me-2"></i> Add
                        Store</a
                    >
                </div>
            </div>
        </li>
        <?php endif; ?> -->

        <?php if($user && in_array($user->role_id, [1, 2])): ?>
        <li class="nav-item">
            <div class="page-header mb-0">
                <div class="page-btn">
                    <a href="#" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#add-stores"><i
                            data-feather="plus-circle" class="me-2"></i> Add Store</a>
                </div>
            </div>
        </li>
        <?php endif; ?>

        <?php
        $user = auth()->user();
        ?>

        <?php if($user && in_array($user->role_id, [1, 2])): ?>
        <!-- Select Store -->
        <li class="nav-item dropdown has-arrow main-drop select-store-dropdown">
            <a href="javascript:void(0);" class="dropdown-toggle nav-link select-store" data-bs-toggle="dropdown">
                <span class="user-info">
                    <span class="user-letter">
                        <img src="<?php echo e(asset('admin/assets/img/store/store-01.png')); ?>" alt="Store Logo"
                            class="img-fluid" />
                    </span>
                    <?php
                    $storeId = session('selected_store_id');
                    $selectedStore = \App\Models\Store::find($storeId);
                    ?>
                    <span class="user-name">
                        <?php echo e($selectedStore ? $selectedStore->name : 'Select Store'); ?>

                    </span>
                </span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="javascript:void(0);" class="dropdown-item store-select" data-id="<?php echo e($store->id); ?>">
                    <img src="<?php echo e(asset('admin/assets/img/store/store-01.png')); ?>" class="img-fluid" />
                    <?php echo e($store->name); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>
        <!-- /Select Store -->
        <?php endif; ?>

        <!-- /Notifications -->

        <li class="nav-item dropdown nav-item-box">
            <a href="javascript:void(0);" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <i data-feather="bell"></i>
                <span class="badge rounded-pill">0</span>
            </a>
            <div class="dropdown-menu notifications">
                <div class="topnav-dropdown-header">
                    <span class="notification-title">Notifications</span>
                    <a href="javascript:void(0)" class="clear-noti">Clear All</a>
                </div>
                <div class="noti-content">
                    <ul class="notification-list" id="notification-list">
                        <!-- Notifications will be dynamically inserted here -->
                    </ul>
                </div>
                <div class="topnav-dropdown-footer">
                    <a href="#"><i data-feather="chevrons-up" class="feather-chevrons-up"></i>Close</a>
                </div>
            </div>
        </li>

        <!-- /Notifications -->

        <!-- <li class="nav-item nav-item-box">
            <a href="#"><i data-feather="settings"></i></a>
        </li> -->

        <li class="nav-item dropdown has-arrow main-drop">
            <a href="javascript:void(0);" class="dropdown-toggle nav-link userset" data-bs-toggle="dropdown">
                <span class="user-info">
                    <span class="user-letter">
                        <img src="<?php echo e($user->profile_image ? asset('storage/' . $user->profile_image) : asset('admin\assets\img\avatar\default-avatar.png')); ?>"
                            alt="" class="img-fluid" />
                    </span>
                    <span class="user-detail">
                        <span class="user-name"><?php echo e($user->name); ?></span>
                        <span class="user-role"><?php echo e($user->role->name); ?></span>
                    </span>
                </span>
            </a>
            <div class="dropdown-menu menu-drop-user">
                <div class="profilename">
                    <div class="profileset">
                        <span class="user-img"><img
                                src="<?php echo e($user->profile_image ? asset('storage/' . $user->profile_image) : asset('admin\assets\img\avatar\default-avatar.png')); ?>"
                                alt="" />
                            <span class="status online"></span></span>
                        <div class="profilesets">
                            <h6><?php echo e($user->name); ?></h6>
                            <h5><?php echo e($user->role->name); ?></h5>
                        </div>
                    </div>
                    <hr class="m-0" />
                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">
                        <i class="me-2" data-feather="user"></i> My Profile</a>
                    <a class="dropdown-item" href="<?php echo e(route('change-password')); ?>"><i class="me-2"
                            data-feather="lock"></i>Change
                        Password</a>
                    <!-- <a class="dropdown-item" href=""
                        ><i class="me-2" data-feather="settings"></i>Settings</a
                    > -->

                    <hr class="m-0" />
                    <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item">
                            <img src="<?php echo e(asset('admin/assets/img/icons/log-out.svg')); ?>" class="me-2" alt="img" />
                            Logout
                        </button>
                    </form>
                    <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('login_view')); ?>"><img src="<?php echo e(asset('admin/assets/img/icons/log-out.svg')); ?>" class="me-2" alt="img" />
                        Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->

    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"
            aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="">My Profile</a>
            <!-- <a class="dropdown-item" href=""
                >Settings</a
            > -->

            <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="dropdown-item">Logout</button>
            </form>
            <?php else: ?>
            <a class="dropdown-item" href="<?php echo e(route('login_view')); ?>">Login</a>
            <?php endif; ?>
        </div>
    </div>
    <!-- /Mobile Menu -->
</div>
<!-- /Header -->


<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll(".store-select").forEach(function (item) {
            item.addEventListener("click", function () {
                const storeId = this.getAttribute("data-id");
                console.log("Store clicked:", storeId);

                fetch("<?php echo e(route('admin.select.store')); ?>", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
                    },
                    body: JSON.stringify({ store_id: storeId }),
                })
                    .then((response) => {
                        console.log("Raw response:", response);
                        return response.json();
                    })
                    .then((data) => {
                        console.log("Fetch response:", data);
                        location.reload();
                    })
                    .catch((error) => {
                        console.error("Fetch error:", error);
                    });
            });
        });
    });
</script>


<script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
<script>
    window.NOTIFICATION_PORT = '<?php echo e(env('NOTIFICATION_PORT')); ?>'; 
</script>
<script src="<?php echo e(asset('admin/assets/js/notification.js')); ?>"></script>

<script>
    window.Laravel = {
        userId: "<?php echo e(auth()->id()); ?>"  // Pass the authenticated user's ID here
    };
</script><?php /**PATH /var/www/stockmgnt/resources/views/partials/admin/header.blade.php ENDPATH**/ ?>