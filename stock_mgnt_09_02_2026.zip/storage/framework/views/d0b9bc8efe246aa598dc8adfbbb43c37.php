 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Profit & Loss</h4>
                    <h6>Manage your Profit & Loss</h6>
                </div>
            </div>
            <ul class="table-top-head">
                
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Excel"
                        href="#"
                        id="export-profit-loss"
                    >
                        <img src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/excel.svg" alt="img"/>
                    </a>
                </li>
                
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Refresh"
                        id="refresh-page"
                        ><i
                            data-feather="rotate-ccw"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Collapse"
                        id="collapse-header"
                        ><i
                            data-feather="chevron-up"
                            class="feather-chevron-up"
                        ></i
                    ></a>
                </li>
            </ul>
        </div>

        <div class="card table-list-card border-0 mb-0">
            <div class="card-body mb-3">
                <div class="table-top mb-0 profit-table-top">
                    <div class="search-path profit-head">
                        <label class="form-label mb-0">From Date</label>
                        <div class="input-blocks mb-0">
                            <i data-feather="calendar" class="info-img"></i>
                            <div class="input-groupicon">
                                <input
                                    type="text"
                                    id="from_date"
                                    class="datetimepicker"
                                    placeholder="From Date"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="position-relative daterange-wraper input-blocks mb-0">
                        <label class="form-label mb-0">To Date</label>
                        <div class="input-blocks mb-0">
                            <i data-feather="calendar" class="info-img"></i>
                            <div class="input-groupicon">
                                <input
                                    type="text"
                                    id="to_date"
                                    class="datetimepicker"
                                    placeholder="To Date"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="position-relative daterange-wraper input-blocks mb-0">
                        <label class="form-label mb-0">Select Store</label>
                        <div class="input-blocks mb-0 me-2">
                            <select id="store_id" class="select">
                                <option value="">Choose Store</option>
                                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                   
                    <div class="date-btn">
                        <a
                            href="javascript:void(0);"
                            class="btn btn-secondary d-flex align-items-center"
                            id="display-profit-loss"
                        >
                            <i
                                data-feather="database"
                                class="feather-14 info-img me-2"
                            ></i
                            >Display Data</a
                        >
                    </div>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table profit-table">
                <thead class="profit-table-bg">
                    <tr id="dynamic-header">
                        <th class="no-sort">Category</th>
                        <!-- Dynamic month/year headers will be inserted here -->
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr class="table-heading">
                        <td>Income</td>
                        <td colspan="12"></td>
                    </tr> -->
                    <tr class="profit-table-bg" id="dynamic-sales-row">
                        <!-- Sales row will be generated here via JS -->
                    </tr>
                    
                    <tr id="dynamic-adjustments-row">
                        <!-- adjustments row will be generated here via JS -->
                    </tr>
                    <tr id="dynamic-incomingTransfer-row">
                        <!-- adjustments row will be generated here via JS -->
                    </tr>
                    <tr id="dynamic-outgoingTransfer-row">
                        <!-- adjustments row will be generated here via JS -->
                    </tr>
                    <tr id="dynamic-stocks-row">
                        <!-- adjustments row will be generated here via JS -->
                    </tr>
                    <tr class="profit-table-bg" id="dynamic-netProfit-row">
                        <!-- adjustments row will be generated here via JS -->
                    </tr>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    function generateMonthRange(start_date, end_date) {
    const result = [];
    function parseDMY(dateStr) {
        const [day, month, year] = dateStr.split("-");
        return new Date(`${year}-${month}-${day}`);
    }

    let start = parseDMY(start_date);
    let end = parseDMY(end_date);
    start.setDate(1);

    while (start <= end) {
        const month = monthNames[start.getMonth()];
        const year = start.getFullYear();
        const label = `${month} ${year}`;
        result.push({ key: label, label: label });

        start.setMonth(start.getMonth() + 1);
    }

    return result;
}


    $("#display-profit-loss").on("click", function () {
        const fromDate = $("#from_date").val();
        const toDate = $("#to_date").val();
        const storeId = $("#store_id").val();

        if (!fromDate || !toDate) {
    Swal.fire({
        icon: 'warning',
        title: 'Missing Dates',
        text: 'Please select both the Dates.',
        confirmButtonText: 'OK'
    });
    return;
}

        const months = generateMonthRange(fromDate, toDate);

        // Build table headers
        let headerHtml = `<th></th>`;
        months.forEach(m => {
            headerHtml += `<th>${m.label}</th>`;
        });
        $(".profit-table thead tr").html(headerHtml);

        // Build sales row with placeholders
        let salesHtml = `<td>Sales</td>`;
        months.forEach(m => {
            salesHtml += `<td data-month="${m.key}">-</td>`;
        });
        let adjustmentsHtml = `<td>Adjustments</td>`;
        months.forEach(m => {
            adjustmentsHtml += `<td data-month="${m.key}">-</td>`;
        });
        let incomingsHtml = `<td>Incoming Stocks</td>`;
        months.forEach(m => {
            incomingsHtml += `<td data-month="${m.key}">-</td>`;
        });
        let outgoingsHtml = `<td>Outgoing Stocks</td>`;
        months.forEach(m => {
            outgoingsHtml += `<td data-month="${m.key}">-</td>`;
        });
        let stocksHtml = `<td>Stocks Value</td>`;
        months.forEach(m => {
            stocksHtml += `<td data-month="${m.key}">-</td>`;
        });
        let netProfitHtml = `<td>Net Profit</td>`;
        months.forEach(m => {
            netProfitHtml += `<td data-month="${m.key}">-</td>`;
        });
        $("#dynamic-sales-row").html(salesHtml);
        $("#dynamic-adjustments-row").html(adjustmentsHtml);
        $("#dynamic-incomingTransfer-row").html(incomingsHtml);
        $("#dynamic-outgoingTransfer-row").html(outgoingsHtml);
        $("#dynamic-stocks-row").html(stocksHtml);
        $("#dynamic-netProfit-row").html(netProfitHtml);
        

        $.ajax({
            url: "<?php echo e(route('admin.profit-loss.sales')); ?>",
            method: "GET",
            data: {
                store_id: storeId,
                start_date: fromDate,
                end_date: toDate,
            },
            success: function (res) {
                if (res.sales && Array.isArray(res.sales)) {
                    res.sales.forEach((entry) => {
                        $('#dynamic-sales-row td[data-month="' + entry.month + '"]').text(
                            '$' + parseFloat(entry.total_sales).toLocaleString()
                        );
                    });
                }
                if (res.adjustments && Array.isArray(res.adjustments)) {
                    res.adjustments.forEach((entry) => {
                        $('#dynamic-adjustments-row td[data-month="' + entry.month + '"]').text(
                            '$' + parseFloat(entry.adjustment_value).toLocaleString()
                        );
                    });
                }
                if (res.incoming && Array.isArray(res.incoming)) {
                    res.incoming.forEach((entry) => {
                        $('#dynamic-incomingTransfer-row td[data-month="' + entry.month + '"]').text(
                            '$' + parseFloat(entry.incoming_value).toLocaleString()
                        );
                    });
                }
                if (res.outgoing && Array.isArray(res.outgoing)) {
                    res.outgoing.forEach((entry) => {
                        $('#dynamic-outgoingTransfer-row td[data-month="' + entry.month + '"]').text(
                            '$' + parseFloat(entry.outgoing_value).toLocaleString()
                        );
                    });
                }
                if (res.stocks && Array.isArray(res.stocks)) {
                    res.stocks.forEach((entry) => {
                        $('#dynamic-stocks-row td[data-month="' + entry.month + '"]').text(
                            '$' + parseFloat(entry.stock_value).toLocaleString()
                        );
                    });
                }
                if (res.net_profit && Array.isArray(res.net_profit)) {
                    res.net_profit.forEach((entry) => {
                        const amount = parseFloat(entry.net_profit);
                        const formatted = (amount < 0 ? '- $' : '$') + Math.abs(amount).toLocaleString();
                        const cell = $('#dynamic-netProfit-row td[data-month="' + entry.month + '"]');
                        cell.text(formatted);

                        // Apply red color if negative, else reset
                        if (amount < 0) {
                            cell.addClass('text-danger');
                        } else {
                            cell.removeClass('text-danger');
                        }
                    });
                }
                
            },

            error: function () {
                $("#dynamic-sales-row").html('<td colspan="' + (months.length + 1) + '">Failed to load sales data</td>');
                $("#dynamic-adjustments-row").html('<td colspan="' + (months.length + 1) + '">Failed to load adjustment data</td>');
                $("#dynamic-incomingTransfer-row").html('<td colspan="' + (months.length + 1) + '">Failed to load incoming stocks data</td>');
                $("#dynamic-outgoingTransfer-row").html('<td colspan="' + (months.length + 1) + '">Failed to load outgoing stocks data</td>');
                $("#dynamic-stocks-row").html('<td colspan="' + (months.length + 1) + '">Failed to load stocks data</td>');
                $("#dynamic-netProfit-row").html('<td colspan="' + (months.length + 1) + '">Failed to load net profit data</td>');
            }
        });
    });

    $("#export-profit-loss").on("click", function (e) {
    e.preventDefault();
    const fromDate = $("#from_date").val();
    const toDate = $("#to_date").val();
    const storeId = $("#store_id").val();

    // Optional: Validate dates
    if (!fromDate || !toDate) {
        Swal.fire({
            icon: 'warning',
            title: 'Missing Dates',
            text: 'Please select both the Dates.',
            confirmButtonText: 'OK'
        });
        return;
    }

    // Build the export URL with query parameters
    const url = `<?php echo e(route('admin.export.profit-loss')); ?>?store_id=${encodeURIComponent(storeId)}&start_date=${encodeURIComponent(fromDate)}&end_date=${encodeURIComponent(toDate)}`;
    window.location.href = url;
});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<style>
    .table-scroll-wrapper {
        overflow-x: auto;
        white-space: nowrap;
    }

    .table-scroll-wrapper table {
        width: auto;
        min-width: 100%;
    }

    .profit-table th,
    .profit-table td {
        white-space: nowrap;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/profit-loss-statement.blade.php ENDPATH**/ ?>