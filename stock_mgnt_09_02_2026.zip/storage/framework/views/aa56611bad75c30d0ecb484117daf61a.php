 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Stock Adjustment</h4>
                    <h6>Manage your products</h6>
                </div>
            </div>
            <ul class="table-top-head">
                <!-- <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Pdf"
                        ><img src="assets/img/icons/pdf.svg" alt="img"
                    /></a>
                </li> -->
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Excel"
                        href="<?php echo e(route('admin.stock-adjustments.export')); ?>"><img src="assets/img/icons/excel.svg"
                            alt="img" /></a>
                </li>
                <!-- <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Print"
                        ><i
                            data-feather="printer"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li> -->
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh" id="refresh-page"><i
                            data-feather="rotate-ccw" class="feather-rotate-ccw"></i></a>
                </li>
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                            data-feather="chevron-up" class="feather-chevron-up"></i></a>
                </li>
            </ul>
            <?php if(hasPermission('create', 'stock_adjustment')): ?>
            <div class="page-btn">
                <button type="button" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#add-new-stock">
                    <i data-feather="plus-circle" class="me-2"></i>Add New
                    Adjustment
                </button>
            </div>
            <?php endif; ?>
        </div>

        <!-- /product list -->
        <div class="card table-list-card">
            <div class="card-body">
                <div class="table-top">
                    <div class="search-set">
                        <div class="search-input d-flex align-items-center">
                            <div id="custom-search" class="me-2"></div> <!-- DataTable input will be moved here -->
                            <a href="#" class="btn btn-searchset">
                                <i data-feather="search" class="feather-search"></i>
                            </a>
                        </div>
                    </div>

                    <div class="form-sort">
                        <i data-feather="sliders" class="info-img"></i>
                        <select class="select" id="sort-order">
                            <option value="">Sort by</option>
                            <option value="desc">Newest First</option>
                            <option value="asc">Oldest First</option>
                        </select>
                    </div>

                </div>
                <!-- /Filter -->
                <?php
                $user=auth()->user();
                ?>
                <?php if($user && in_array($user->role_id,[1,2])): ?>
                <div class="card mb-0" id="filter_inputs">
                    <div class="card-body pb-0">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-2 col-sm-6 col-12">
                                        <div class="input-blocks">
                                            <i class="fas fa-money-bill info-img"></i>
                                            <?php
                                            $user=auth()->user();
                                            $selected_store_id=$user->selected_store_id;
                                            ?>

                                            <select class="select" id="store_filter">
                                                <?php if($user && in_array($user->role_id,[1,2]) ): ?>
                                                <option value="all">All Stores</option>
                                                <?php endif; ?>
                                                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($store->id==$selected_store_id): ?>
                                                <option value="<?php echo e($store->id); ?>" selected><?php echo e($store->name); ?></option>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <!-- /Filter -->
                <div class="table-responsive ">
                    <table class="table datanew" id="adjustment-table">
                        <thead>
                            <tr>
                                <!-- <th class="no-sort">
                                    <label class="checkboxs">
                                        <input
                                            type="checkbox"
                                            id="select-all"
                                        />
                                        <span class="checkmarks"></span>
                                    </label>
                                </th> -->
                                <th>Store</th>
                                <th>Product</th>
                                <th>Adjust Qty</th>
                                <th>Adjust Reason</th>
                                <th>Adjust Date</th>
                                <th class="no-sort">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <!-- /product list -->
    </div>
</div>

<!-- Edit Stock -->
<div class="modal fade" id="edit-units">
    <div class="modal-dialog modal-dialog-centered stock-adjust-modal">
        <div class="modal-content">
            <div class="page-wrapper-new p-0">
                <div class="content">
                    <div class="modal-header border-0 custom-modal-header">
                        <div class="page-title">
                            <h4>Edit Stock Adjustment</h4>
                        </div>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body custom-modal-body">
                        <form method="post" id="editForm" action="">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <input type="hidden" id="edit_id" name="id" />
                            <div class="row">
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Store</label>
                                        <select class="select form-control" id="edit_store_id" name="store_id">
                                            <option value="">Choose</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Product</label>
                                        <select class="select form-control" id="edit_product_id" name="product_id">
                                            <option value="">Choose</option>
                                        </select>
                                        <small class="text-muted available-stock"></small>

                                    </div>

                                </div>
                                <div class="col-lg-4 col-sm-6 col-12">
                                    <label class="form-label">Adjusted Quantity</label>
                                    <div class="product-quantity">
                                        <span class="quantity-btn"><i data-feather="minus-circle"
                                                class="feather-search"></i></span>
                                        <input type="text" class="quntity-input" id="edit_quantity"
                                            name="adjust_quantity" value="1" />
                                        <span class="quantity-btn">+<i data-feather="plus-circle"
                                                class="plus-circle"></i></span>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Adjustment Reason</label>
                                        <select class="select form-control" id="edit_reason" name="reason">
                                            <option value="">Choose</option>
                                            <option value="Loss">Loss</option>
                                            <option value="Damage">
                                                Damage
                                            </option>
                                            <option value="Error Correction">
                                                Error Correction
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-sm-6 col-12">
                                    <div class="input-blocks">
                                        <label>Adjustment Date</label>

                                        <div class="input-groupicon calender-input">
                                            <i data-feather="calendar" class="info-img"></i>
                                            <input type="text" class="form-control datetimepicker"
                                                id="edit_adjustment_date" name="adjust_date" placeholder="Choose Date"
                                                value="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer-btn">
                                <button type="button" class="btn btn-cancel me-2" data-bs-dismiss="modal">
                                    Cancel
                                </button>
                                <button type="submit" class="btn btn-submit">
                                    Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Edit Stock -->
<!--Add new Adjustment-->
<div class="modal fade" id="add-new-stock">
    <div class="modal-dialog modal-dialog-centered stock-adjust-modal">
        <div class="modal-content">
            <div class="page-wrapper-new p-0">
                <div class="content">
                    <div class="modal-header border-0 custom-modal-header">

                        <div class="page-title">
                            <h4>Add New Stock Adjustment</h4>
                        </div>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body custom-modal-body">
                        <form method="post" action="<?php echo e(route('admin.create-adjustment')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Store</label>
                                        <select class="select form-control" id="store_id" name="store_id">
                                            <option value="">Choose</option>

                                            <?php if(in_array($user->role_id, [1, 2])): ?>
                                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <option value="<?php echo e($user->selected_store_id); ?>">
                                                <?php echo e(optional($stores->firstWhere('id', $user->selected_store_id))->name); ?>

                                            </option>
                                            <?php endif; ?>
                                        </select>
                                        <?php $__errorArgs = ['store_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Product</label>
                                        <select class="select" id="product_id" name="product_id">
                                            <option value="">Choose</option>
                                        </select>
                                        <small class="text-muted available-stock"></small>
                                        <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 col-12">
                                    <label class="form-label">Adjusted Quantity</label>
                                    <div class="product-quantity">
                                        <span class="quantity-btn"><i data-feather="minus-circle"
                                                class="feather-search"></i></span>
                                        <input type="text" class="quntity-input" value="1" name="quantity" />
                                        <span class="quantity-btn">+<i data-feather="plus-circle"
                                                class="plus-circle"></i></span>

                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Adjustment Reason</label>
                                        <select class="select" name="reason">
                                            <option value="">Choose</option>
                                            <option value="Loss">Loss</option>
                                            <option value="Damage">
                                                Damage
                                            </option>
                                            <option value="Error Correction">
                                                Error Correction
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-sm-6 col-12">
                                    <div class="input-blocks">
                                        <label>Adjustment Date</label>
                                        <div class="input-groupicon calender-input">
                                            <i data-feather="calendar" class="info-img"></i>
                                            <input type="text" class="form-control datetimepicker"
                                                placeholder="Choose Date" name="adjustment_date" value="" />
                                            <?php $__errorArgs = ['adjustment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer-btn">
                                <button type="button" class="btn btn-cancel me-2" data-bs-dismiss="modal">
                                    Cancel
                                </button>
                                <button type="submit" class="btn btn-submit">
                                    Add Adjustment
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if($errors->any()): ?>
<script>
    $(document).ready(function () {
        $('#add-new-stock').modal('show');
    });
</script>
<?php endif; ?>
<!--/Add new Adjustment-->

<?php $__env->stopSection(); ?> <?php $__env->startSection('scripts'); ?> >
<script>
    $(document).ready(function () {
        let table = $('#adjustment-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('admin.stock-adjustment')); ?>",
                data: function (d) {
                    d.store = $('#store_filter').val();
                    d.order_type = $('#sort-order').val();
                }
            },
            columns: [
                { data: 'store_name', name: 'store.name' }, // if you join stores table
                { data: 'product_details', name: 'stock.product_name', orderable: false }, // if you join stocks table
                { data: 'adj_qty', name: 'adjust_quantity' },
                { data: 'reason', name: 'reason' },
                { data: 'adjust_date', name: 'stock_adjustments.adjust_date', orderable: false },
                { data: 'actions', name: 'actions', orderable: false, searchable: false },
            ],
            pageLength: 10,
            drawCallback: function () {
                feather.replace();
            },
            initComplete: function () {
                let searchWrapper = $('#adjustment-table_filter');
                let defaultSearchBox = searchWrapper.find('input');
                $('#custom-search').append(defaultSearchBox);
                defaultSearchBox.attr('placeholder', 'Search...');
                searchWrapper.remove();
            }
        });

        $('#store_filter').on('change', function () {
            table.ajax.reload();
        });
        $('#sort-order').on('change', function () {
            table.ajax.reload();
        });
    });


</script>

<script>
    let productCache = [];
    $(document).ready(function () {
        $("#add-new-stock, #edit-units").on("shown.bs.modal", function (e) {
            var modalId = $(this).attr("id");
            var storeDropdown = $("#" + modalId + " #store_id");
            var productDropdown = $("#" + modalId + " #product_id");
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                        "content"
                    ),
                },
            });

        });



        $(document).on("change", "#store_id, #edit_store_id", function () {
            var modalId = $(this).closest(".modal").attr("id");
            var storeId = $(this).val();
            var productDropdown =
                modalId === "edit-units"
                    ? $("#" + modalId + " #edit_product_id")
                    : $("#" + modalId + " #product_id");

            if (storeId) {
                $.ajax({
                    url: "<?php echo e(route('admin.get-products')); ?>",
                    type: "GET",
                    data: { store_id: storeId },
                    success: function (response) {
                        productCache = response;

                        productDropdown.empty().append('<option value="">Choose</option>');

                        if (response.length) {
                            $.each(response, function (key, product) {
                                productDropdown.append(
                                    '<option value="' +
                                    product.product_id +
                                    '">' +
                                    product.product_name +
                                    " (SKU: " +
                                    product.sku +
                                    ")</option>"
                                );
                            });
                        } else {
                            productDropdown.append('<option value="">No products found</option>');
                        }
                        $("#" + modalId + " .available-stock").text("");
                    },
                    error: function () {
                        alert("Failed to load products.");
                    }
                });
            } else {
                productDropdown.empty().append('<option value="">Choose</option>');
                $("#" + modalId + " .available-stock").text("");
            }
        });
        $(document).on("change", "#product_id, #edit_product_id", function () {
            var modalId = $(this).closest(".modal").attr("id");
            var productId = $(this).val();

            if (productId && productCache.length > 0) {
                var product = productCache.find(p => p.product_id == productId);
                if (product) {
                    $("#" + modalId + " .available-stock").text("Available Quantity: " + product.total_quantity);
                } else {
                    $("#" + modalId + " .available-stock").text("Stock not found");
                }
            } else {
                $("#" + modalId + " .available-stock").text("");
            }
        });

    });
    $(document).ready(function () {
        $(document).on("click", ".edit-btn", function () {
            var id = $(this).data("id");
            console.log("Edit button clicked, ID:", id); // Debug
            var url = "/admin/get-adjustment-data/" + id;

            console.log("Generated URL:", url);
            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    if (response.success) {
                        console.log(
                            "Data fetched successfully:",
                            response.data
                        );
                        populateEditModal(response.data);
                        $("#edit-units").modal("show");
                    } else {
                        alert(response.message);
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error fetching adjustment data:", error);
                },
            });
        });

        function populateEditModal(data) {
            $("#editForm").attr("action", "/admin/update/" + data.id);
            $("#edit_id").val(data.id);
            $.ajax({
                url: "<?php echo e(route('admin.get-stores')); ?>",
                type: "GET",
                success: function (response) {
                    $("#edit_store_id")
                        .empty()
                        .append('<option value="">Choose</option>');
                    $.each(response, function (key, store) {
                        var selected =
                            store.id == data.store_id ? "selected" : "";
                        $("#edit_store_id").append(
                            '<option value="' +
                            store.id +
                            '" ' +
                            selected +
                            ">" +
                            store.name +
                            "</option>"
                        );
                    });
                    loadProductsForEdit(data.store_id, data.product_id);
                },
            });
            $("#edit_quantity").val(data.adjust_quantity);
            $("#edit_reason").val(data.reason).trigger("change");
            if (data.adjust_date) {
                var formattedDate = moment(
                    data.adjust_date,
                    "YYYY-MM-DD"
                ).format("DD-MM-YYYY");
                $("#edit_adjustment_date").val(formattedDate);
                console.log("Date loaded into input field:", formattedDate);
            }
            console.log(
                "Date loaded into edit modal:",
                $("#edit_adjustment_date").val()
            );
        }
        function loadProductsForEdit(storeId, selectedProductId) {
            if (!storeId) return;

            $.ajax({
                url: "<?php echo e(route('admin.get-products')); ?>",
                type: "GET",
                data: { store_id: storeId },
                success: function (response) {
                    var productDropdown = $("#edit_product_id");
                    productDropdown.empty().append('<option value="">Choose</option>');
                    productCache = response;

                    $.each(response, function (key, product) {
                        var selected = product.product_id == selectedProductId ? "selected" : "";
                        productDropdown.append(
                            '<option value="' +
                            product.product_id +
                            '" ' +
                            selected +
                            ">" +
                            product.product_name +
                            " (SKU: " +
                            product.sku +
                            ")</option>"
                        );
                    });

                    // Trigger change to load available stock
                    productDropdown.val(selectedProductId).trigger("change");
                },
                error: function () {
                    alert("Failed to load products.");
                },
            });
        }


    });

    // Datepicker initialization
    $(document).ready(function () {
        $(".datetimepicker").datepicker({
            dateFormat: "yy-mm-dd", // Correct date format
        });

        $(document).on("click", ".edit-btn", function () {
            var id = $(this).data("id");
            var url = "/admin/get-adjustment-data/" + id;

            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    if (response.success) {
                        populateEditModal(response.data);
                        $("#edit-units").modal("show");
                    } else {
                        alert(response.message);
                    }
                },
            });
        });

        function populateEditModal(data) {
            $("#editForm").attr("action", "/admin/update/" + data.id);
            $("#edit_id").val(data.id);
            $("#edit_quantity").val(data.adjust_quantity);
            $("#edit_reason").val(data.reason).trigger("change");

            if (data.adjust_date) {
                var formattedDate = moment(
                    data.adjust_date,
                    "YYYY-MM-DD"
                ).format("YYYY-MM-DD");
                $("#edit_adjustment_date").val(formattedDate);
            }
        }
    });
</script>
<script>
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).on('click', '.delete-adjustment', function () {
            let id = $(this).data('id');

            Swal.fire({
                title: 'Are you sure?',
                text: 'This adjustment will be permanently deleted.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '/admin/adjustment/' + id + '/delete',
                        type: 'DELETE',
                        data: {
                            _token: $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (response) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: response.success,
                                timer: 1500,
                                showConfirmButton: false
                            });
                            location.reload();
                        },
                        error: function () {
                            Swal.fire('Error', 'Delete failed. Try again.', 'error');
                        }
                    });
                }
            });
        });
    });
</script>


<script>
    $(document).ready(function () {
        $(".datetimepicker").datepicker({
            dateFormat: "yy-mm-dd",
            changeMonth: true,
            changeYear: true,
        });
    });
</script>
<?php if(session('success')): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        Swal.fire({
            icon: "success",
            title: "Success!",
            text: "<?php echo e(session('success')); ?>",
            timer: 3000,
            showConfirmButton: false,
        });
    });
</script>
<?php endif; ?> <?php if(session('error')): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        Swal.fire({
            icon: "error",
            title: "Oops!",
            text: "<?php echo e(session('error')); ?>",
            timer: 3000,
            showConfirmButton: false,
        });
    });
</script>


<?php endif; ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/stock-adjustment.blade.php ENDPATH**/ ?>