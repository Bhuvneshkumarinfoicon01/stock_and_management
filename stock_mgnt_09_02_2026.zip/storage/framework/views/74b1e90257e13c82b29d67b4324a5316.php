<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Stock Adjustment Notification</title>
</head>
<body>
    <h2>Stock Adjustment Made</h2>

    <p><strong>Performed By:</strong> <?php echo e($performedBy); ?></p>
    <p><strong>Store:</strong> <?php echo e($store->name); ?></p>
    <p><strong>Product:</strong> <?php echo e($stock->product_name ?? 'N/A'); ?> (SKU: <?php echo e($stock->sku ?? 'N/A'); ?>)</p>
    <p><strong>Adjusted Quantity:</strong> <?php echo e($adjustment->adjust_quantity); ?></p>
    <p><strong>Reason:</strong> <?php echo e($adjustment->reason); ?></p>
    <p><strong>Adjustment Date:</strong> <?php echo e($adjustment->adjust_date); ?></p>
    <p><strong>Remaining Stock:</strong> <?php echo e($stock->quantity); ?></p>

    <p>Thank you.</p>
</body>
</html>
<?php /**PATH /var/www/stockmgnt/resources/views/emails/stock_adjustment_notification.blade.php ENDPATH**/ ?>