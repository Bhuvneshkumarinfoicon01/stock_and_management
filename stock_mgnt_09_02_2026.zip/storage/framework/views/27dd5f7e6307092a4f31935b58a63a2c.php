<h2>Stock Transfer Completed</h2>

<p><strong>From Store:</strong> <?php echo e($store_from->name); ?></p>
<p><strong>To Store:</strong> <?php echo e($store_to->name); ?></p>
<p><strong>Reference No:</strong> <?php echo e($transfer->reference_no); ?></p>
<p><strong>Arrival Date:</strong> <?php echo e($transfer->arrival_date); ?></p>

<h4>Products Transferred:</h4>
<ul>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($item->product_name); ?> (SKU: <?php echo e($item->sku); ?>) - Qty: <?php echo e($item->qty); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<p><strong>Notes:</strong> <?php echo e($transfer->notes); ?></p>
<?php /**PATH C:\xampp\htdocs\stockmgnt\resources\views/emails/stock_transfer_notification.blade.php ENDPATH**/ ?>