 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Sales Trend Reports</h4>
                </div>
            </div>
            <ul class="table-top-head">
                <!-- <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Pdf"
                        ><img src="assets/img/icons/pdf.svg" alt="img"
                    /></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Excel"
                        ><img src="assets/img/icons/excel.svg" alt="img"
                    /></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Print"
                        ><i
                            data-feather="printer"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li> -->
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh" id="refresh-page"><i
                            data-feather="rotate-ccw" class="feather-rotate-ccw"></i></a>
                </li>
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                            data-feather="chevron-up" class="feather-chevron-up"></i></a>
                </li>
            </ul>
        </div>

        <div class="row mt-5">
            <div class="col-xl-12 col-sm-12 col-12">
                <div class="card table-list-card">
                    <div class="card-body">
                        <div class="table-top">
                            <div class="search-set">
                                <div class="search-input d-flex align-items-center">
                                    <div id="custom-search" class="me-2"></div>
                                    <!-- DataTable input will be moved here -->
                                    <a href="#" class="btn btn-searchset">
                                        <i data-feather="search" class="feather-search"></i>
                                    </a>
                                </div>
                            </div>

                            <div class="form-sort">
                                <i data-feather="sliders" class="info-img"></i>
                                <select class="select" id="sort-order">
                                    <option value="">Sort by</option>
                                    <option value="desc">Newest First</option>
                                    <option value="asc">Oldest First</option>
                                </select>
                            </div>
                        </div>
                        <div class="card" id="filter_inputs">
                            <div class="card-body pb-0">
                                <div class="row">
                                    <div class="col-lg-2">
                                        <div class="input-blocks">
                                            <i data-feather="box" class="info-img"></i>
                                            <select class="select" name="store_id" id="storeSelect">
                                                <option value="choose">Choose</option>
                                                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-id="<?php echo e($store->id); ?>" value="<?php echo e($store->id); ?>">
                                                    <?php echo e($store->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="input-blocks">
                                            <i data-feather="zap" class="info-img"></i>
                                            <select class="select" name="category_id" id="categorySelect">
                                                <option value="">Choose Category</option>

                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>">
                                                    <?php echo e($category->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6 col-12">
                                        <div class="input-blocks">
                                            <i data-feather="calendar" class="info-img"></i>
                                            <div class="input-groupicon">
                                                <input type="text" name="date_from" id="dateFrom" class="datetimepicker"
                                                    placeholder="Choose Date From" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-6 col-12">
                                        <div class="input-blocks">
                                            <i data-feather="calendar" class="info-img"></i>
                                            <div class="input-groupicon">
                                                <input type="text" name="date_to" id="dateTo" class="datetimepicker"
                                                    placeholder="Choose Date To" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-sm-6 col-12">
                                        <div class="input-blocks">
                                            <a class="btn btn-filters ms-auto" id="searchBtn">
                                                <i data-feather="search" class="feather-search"></i>
                                                Search
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table datanew" id="sales-trend-table">
                                <thead>
                                    <tr>
                                        <!-- <th class="no-sort">
                                            <label class="checkboxs">
                                                <input
                                                    type="checkbox"
                                                    id="select-all"
                                                />
                                                <span class="checkmarks"></span>
                                            </label>
                                        </th> -->
                                        <th>Product Name</th>
                                        <th>SKU</th>
                                        <th>Category</th>
                                        <th>Sold Qty</th>
                                        <th>Sold Amount</th>
                                        <th>Instock Qty</th>
                                    </tr>
                                </thead>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-12 col-sm-12 col-12 d-flex">
                <div class="card flex-fill default-cover">

                    <div class="card-body">
                        <div id="sales-analysis-graph" class="chart-set"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chroma-js/2.1.0/chroma.min.js"></script>
<script>
    $(document).ready(function () {
        function generateColors(numColors) {
            const baseScale = chroma.scale([
                '#0074D9', // Bright Blue
            ])
                .mode('lab')
                .colors(numColors);

            // Increase vibrancy by boosting saturation and brightness
            const vibrantColors = baseScale.map(color =>
                chroma(color).saturate(10).hex(5)
            );

            return vibrantColors;
        }

        function loadSalesChart(data) {

            const categories = data.labels;
            const values = data.values;


            console.log("Categories:", categories);
            console.log("Values:", values);

            if (!categories || categories.length === 0 || !values || values.length === 0) {
                console.error("Invalid data structure");
                return;
            }

            const chartData = categories.map((category, index) => ({
                name: category,
                value: parseFloat(values[index]),
            }));
            const colors = generateColors(chartData.length);

            const options = {
                series: [{
                    name: "Sales",
                    data: chartData.map(d => d.value + 'k')
                }],
                chart: {
                    type: 'bar',
                    height: 350
                },
                colors: colors,
                xaxis: {
                    categories: categories
                },
                dataLabels: {
                    enabled: false
                },
                title: {
                    text: 'Sales Trend Analysis',
                    align: 'center'
                },
                tooltip: {
                    y: {
                        formatter: function (val) {
                            return val + "k";
                        }
                    }
                },
                dataLabels: {
                    formatter: function (val) {
                        return val + "k";
                    }
                }
            };

            // Initialize the chart
            $("#sales-analysis-graph").html("");
            const chart = new ApexCharts(document.querySelector("#sales-analysis-graph"), options);
            chart.render();
        }

        const table = $('#sales-trend-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('admin.sales-trend')); ?>",
                data: function (d) {
                    d.category_id = $('#categorySelect').val();
                    d.date_from = $('#dateFrom').val();
                    d.date_to = $('#dateTo').val();
                    d.store_id = $('#storeSelect').val();
                    d.order_type = $('#sort-order').val();
                },
            },
            columns: [
                { data: 'product_name', name: 'order_items.product_name' },
                { data: 'sku', name: 'order_items.sku' },
                { data: 'category', name: 'categories.name' },
                { data: 'sold_qty', name: 'sold_qty' },
                { data: 'sold_amount', name: 'sold_amount' },
                { data: 'instock_qty', name: 'stocks.quantity' }
            ],
            order: [[0, 'asc']],
            pageLength: 10,

            initComplete: function () {
                let searchWrapper = $('#sales-trend-table_filter');
                let defaultSearchBox = searchWrapper.find('input');
                $('#custom-search').append(defaultSearchBox);
                defaultSearchBox.attr('placeholder', 'Search orders...');
                searchWrapper.remove();
            },
            // dom: '<"top"i>rt<"bottom"lp><"clear">',
        });
        $('#sort-order').on('change', function () {
            table.ajax.reload();
        });



        $('#searchBtn').on('click', function () {
            let category_id = $('#categorySelect').val();
            let date_from = $('#dateFrom').val();
            let date_to = $('#dateTo').val();
            let store_id = $('#storeSelect').val();

            $.ajax({
                url: "<?php echo e(route('admin.sales-trend-filter')); ?>",
                type: 'GET',
                data: {
                    category_id: category_id,
                    date_from: date_from,
                    date_to: date_to,
                    store_id: store_id
                },
                success: function (response) {

                    loadSalesChart(response.chartData);
                    // table.clear().rows.add(response.tableData).draw();
                    table.ajax.reload(); // Reload the datatable

                }
            });
        });
    });
</script>
<!-- <script>
        $(document).ready(function () {
    let chart = null;

    // When the page loads, automatically fetch data based on the selected store in session
    function loadDataBasedOnStore() {
        let store_id = $("#store_id").val() || "<?php echo e(session('selected_store_id')); ?>";

        $.ajax({
            url: "<?php echo e(route('admin.sales-trend-filter')); ?>",
            type: "GET",
            data: {
                store_id,
                category_id: $("#category_id").val(),
                date_from: $("#date_from").val(),
                date_to: $("#date_to").val()
            },
            success: function (res) {
                updateTable(res.tableData);

                if (chart) {
                    chart.updateOptions({
                        series: [{
                            name: "Sales Analysis",
                            data: res.chartData.values
                        }],
                        xaxis: {
                            categories: res.chartData.labels
                        }
                    });
                } else {
                    chart = new ApexCharts(document.querySelector("#sales-analysis-admin"), {
                        series: [{
                            name: "Sales Analysis",
                            data: res.chartData.values
                        }],
                        chart: {
                            height: 300,
                            type: "area",
                            zoom: { enabled: false }
                        },
                        colors: ["#FF9F43"],
                        dataLabels: { enabled: false },
                        stroke: { curve: "straight" },
                        xaxis: { categories: res.chartData.labels },
                        yaxis: {
                            labels: {
                                formatter: (val) => (val).toFixed(2) + "K",
                            }
                        },
                        legend: { position: "top", horizontalAlign: "left" }
                    });
                    chart.render();
                }
            }
        });
    }

    // Call the function to load data on page load
    loadDataBasedOnStore();

    // Filter button click
    $("#searchBtn").on("click", function () {
        loadDataBasedOnStore();
    });

    // Update table
    function updateTable(data) {
        let html = "";
        data.forEach((item, index) => {
            html += `
                <tr>
                    <td><label class="checkboxs"><input type="checkbox"><span class="checkmarks"></span></label></td>
                    <td class="productimgname">${item.product_name}</td>
                    <td>${item.sku}</td>
                    <td>${item.category}</td>
                    <td>${item.sold_qty}</td>
                    <td>${item.sold_amount}</td>
                    <td>${item.instock_qty ?? '-'}</td>
                </tr>
            `;
        });
        $(".datanew tbody").html(html);
    }
});

        </script>
         -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/sales-trend.blade.php ENDPATH**/ ?>