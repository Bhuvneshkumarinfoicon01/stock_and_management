 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Invoice Report</h4>
                    <h6>Manage Your Invoice Report</h6>
                </div>
            </div>
            <ul class="table-top-head">
                <!-- <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Pdf"
                        ><img
                            src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/pdf.svg"
                            alt="img"
                    /></a>
                </li> -->
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Excel"
                        href="<?php echo e(route('admin.invoices.export', request()->all())); ?>"><img
                            src="<?php echo e(asset('admin/assets/img/icons/excel.svg')); ?>" alt="img" /></a>
                </li>
                <!-- <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Print"
                        ><i
                            data-feather="printer"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li> -->
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh" id="refresh-page"><i
                            data-feather="rotate-ccw" class="feather-rotate-ccw"></i></a>
                </li>
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                            data-feather="chevron-up" class="feather-chevron-up"></i></a>
                </li>
            </ul>
            <?php
            $user=auth()->user();
            ?>
            <?php if($user->role_id != 5): ?>
            <?php if(hasPermission('create', 'order')): ?>
            <div class="page-btn">
                <button href="#" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#add-units">
                    <i data-feather="plus-circle" class="me-2"></i>Generate Invoice
                </button>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <div class="page-btn">
                <button href="#" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#add-units">
                    <i data-feather="plus-circle" class="me-2"></i>Generate Invoice
                </button>
            </div>
            <?php endif; ?>
        </div>

        <div class="card table-list-card">
            <div class="card-body">
                <div class="table-top">
                    <div class="search-set">
                        <div class="search-input d-flex align-items-center">
                            <div id="custom-search" class="me-2"></div> <!-- DataTable input will be moved here -->
                            <a href="#" class="btn btn-searchset">
                                <i data-feather="search" class="feather-search"></i>
                            </a>
                        </div>
                    </div>
                    <!-- <div class="search-path">
                        <div class="d-flex align-items-center">
                            <a class="btn btn-filter" id="filter_search">
                                <i
                                    data-feather="filter"
                                    class="filter-icon"
                                ></i>
                                <span
                                    ><img
                                        src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/closes.svg"
                                        alt="img"
                                /></span>
                            </a>
                        </div>
                    </div> -->
                    <div class="form-sort">
                        <i data-feather="sliders" class="info-img"></i>
                        <select class="select" id="sort-order">
                            <option value="">Sort by</option>
                            <option value="desc">Newest First</option>
                            <option value="asc">Oldest First</option>
                        </select>
                    </div>
                </div>
                <!-- /Filter -->
                <?php
                $selectedStore = $user->selected_store_id;
                ?>
                <div class="card" id="filter_inputs">
                    <div class="card-body pb-0">
                        <div class="row">
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="input-blocks">
                                    <i data-feather="user" class="info-img"></i>
                                    <select class="select" id="filter_store">
                                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($store->id == $selectedStore): ?>
                                        <option value="<?php echo e($store->id); ?>" selected><?php echo e($store->name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="choose">All Stores</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="input-blocks">
                                    <i data-feather="calendar" class="info-img"></i>
                                    <div class="input-groupicon">
                                        <input type="text" name="date_from" id="date-from" class="datetimepicker"
                                            placeholder="Choose Date From" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="input-blocks">
                                    <i data-feather="calendar" class="info-img"></i>
                                    <div class="input-groupicon">
                                        <input type="text" name="date_to" id="date-to" class="datetimepicker"
                                            placeholder="Choose Date To" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 col-sm-6 col-12">
                                <div class="input-blocks">
                                    <a class="btn btn-filters" id="searchBtn">
                                        <i data-feather="search" class="feather-search"></i>
                                        Search
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- /Filter -->
                <div class="table-responsive">
                    <table class="table datanew" id="order-table">
                        <thead>
                            <tr>
                                <!-- <th class="no-sort">
                                    <label class="checkboxs">
                                        <input
                                            type="checkbox"
                                            id="select-all"
                                        />
                                        <span class="checkmarks"></span>
                                    </label>
                                </th> -->
                                <th>Invoice No</th>
                                <th>Store Name</th>
                                <th>Order Date</th>
                                <th>Amount</th>
                                <th>Paid</th>
                                <th>Amount Due</th>
                                <th>Status</th>
                                <?php if($user->role_id != 5): ?>
                                <th class="no-sort">
                                    Action
                                </th>
                                <?php endif; ?>
                            </tr>
                        </thead>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- New Order -->
<div class="modal fade" id="add-units" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered stock-adjust-modal">
        <div class="modal-content">
            <div class="page-wrapper-new p-0">
                <div class="content">
                    <div class="modal-header border-0 custom-modal-header">
                        <div class="page-title">
                            <h4>Add Transfer</h4>
                        </div>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body custom-modal-body">
                        <form method="POST" action="<?php echo e(route('admin.invoice-order')); ?>" id="transferForm">
                            <?php echo csrf_field(); ?>
                            <?php
                            $selectedStore = $user->selected_store_id;
                            ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Select Store</label>
                                        <select name="store_from" id="store_from" class="form-control select">
                                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($store->id==$selectedStore): ?>
                                            <option value="<?php echo e($store->id); ?>" selected>
                                                <?php echo e($store->name); ?>

                                            </option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Customer</label>
                                        <div class="input-block d-flex align-items-center mt-2">
                                            <div class="flex-grow-1 me-2 ">
                                                <select class="select" name="customer_id" id="customer-select">
                                                    <option value="">Choose Customer</option>
                                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($customer->id); ?>">
                                                        <?php echo e($customer->customer_name); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <a href="#" class="btn btn-primary btn-icon open-create-modal">
                                                <i data-feather="user-plus" class="feather-16"></i>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-12">
                                    <div class="input-blocks search-form mb-3">
                                        <label>Product</label>
                                        <input type="text" id="product_search" class="form-control"
                                            placeholder="Search Product by Name or SKU" />
                                        <!-- <ul id="product_list" class="list-group mt-2"></ul> -->
                                        <ul id="product_list" class="list-group"
                                            style="max-height: 200px; overflow-y: auto; position: absolute; z-index: 1000; width: 100%; display: none;">
                                        </ul>


                                        <i data-feather="search" class="feather-search"></i>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="modal-body-table">
                                        <div class="table-responsive">
                                            <table class="table datanew">
                                                <thead>
                                                    <tr>

                                                        <th>Product</th>
                                                        <th>SKU</th>
                                                        <th>Category</th>
                                                        <th>Qty</th>
                                                        <th>Price</th>
                                                        <th class="no-sort">
                                                            Action
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody id="product-tbody">
                                                    <!-- Template Row (Hidden by Default) -->
                                                    <tr id="product-row-template" class="d-none">
                                                        <td>
                                                            <input type="hidden" name="product_id[]"
                                                                class="form-control product-id" />
                                                            <input type="text" name="product_name[]"
                                                                class="form-control product-name" readonly />
                                                        </td>
                                                        <td>
                                                            <div class="productimgname">
                                                                <input name="product_name[]" type="text"
                                                                    class="form-control product-name" readonly />
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="input-blocks sku">
                                                                <input name="sku[]" type="text"
                                                                    class="form-control product-sku" readonly />
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <select name="category_id[]" class="select product-category"
                                                                disabled>
                                                                <option>
                                                                    Choose
                                                                </option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <div class="product-quantity">
                                                                <input name="qty[]" type="number"
                                                                    class="form-control product-qty" value="1"
                                                                    min="1" />
                                                            </div>
                                                        </td>
                                                        <td class="action-table-data">
                                                            <div class="edit-delete-action">
                                                                <a class="confirm-text p-2 delete-row"
                                                                    href="javascript:void(0);">
                                                                    <i data-feather="trash-2"
                                                                        class="feather-trash-2"></i>
                                                                </a>
                                                            </div>
                                                        </td>

                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Order Tax</label>
                                        <select name="tax" id="taxDropdown" class="select">
                                            <option value="0">No Tax</option>
                                            <option value="5">5%</option>
                                            <option value="10">10%</option>
                                            <option value="15">15%</option>
                                            <option value="20">20%</option>
                                            <option value="25">25%</option>
                                            <option value="30">30%</option>
                                        </select>
                                    </div>
                                </div>
                                <?php
                                $user = auth()->user();
                                ?>

                                <?php if($user && in_array($user->role_id, [1,2,3])): ?>
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Discount</label>
                                        <select name="discount" id="discountDropdown" class="select">
                                            <option value="0">No Discount</option>
                                            <option value="5">5%</option>
                                            <option value="10">10%</option>
                                            <option value="15">15%</option>
                                            <option value="20">20%</option>
                                            <option value="25">25%</option>
                                            <option value="30">30%</option>
                                        </select>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Discount</label>
                                        <select name="discount" id="discountDropdown" class="select">
                                            <option value="0">No Discount</option>
                                            <?php for($i = 5; $i <= $discount_percentage; $i +=5): ?> <option value="<?php echo e($i); ?>">
                                                <?php echo e($i); ?>%</option>
                                                <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <?php endif; ?>


                                <div class="row">
                                    <div class="col-lg-6 mt-5">
                                        <div class="order-total">
                                            <table class="table table-responsive table-borderless">
                                                <tr>
                                                    <td>Sub Total</td>
                                                    <td class="text-end" id="sub-total">
                                                        $0.00
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id="tax_percentage">Tax (GST 0%)</td>
                                                    <td class="text-end" id="tax">$0.00</td>
                                                </tr>
                                                <tr>
                                                    <td id="discount_percentage">Discount (0%)</td>
                                                    <td class="danger text-end" id="discount">
                                                        $0.00
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Total</td>
                                                    <td class="text-end" id="total">$0.00</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-5">
                                        <div class="block-section payment-method">
                                            <h6>Payment Method</h6>
                                            <div class="row d-flex align-items-center justify-content-center methods">
                                                <input type="hidden" name="payment_method" id="payment_method" />
                                                <div class="col-md-6 col-lg-4 item cash-method">
                                                    <div class="default-cover">
                                                        <a href="javascript:void(0);" class="payment-option"
                                                            data-method="Cash" id="cashPayment">


                                                            <span><img
                                                                    src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/cash-pay.svg"
                                                                    alt="Payment Method" />Cash</span>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-4 item">
                                                    <div class="default-cover">
                                                        <a href="javascript:void(0);" class="payment-option"
                                                            data-method="Card" id="cashPayment">

                                                            <span><img
                                                                    src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/credit-card.svg"
                                                                    alt="Payment Method" />Debit Card</span></a>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-4 item">
                                                    <div class="default-cover">
                                                        <a href="javascript:void(0);" class="payment-option"
                                                            data-method="Scan" id="cashPayment">

                                                            <span><img
                                                                    src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/qr-scan.svg"
                                                                    alt="Payment Method" />Scan</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-grid btn-block mt-5">
                                            <button type="submit" id="placeOrder" class="btn btn-secondary">
                                                Place Order: $<span id="placeOrderValue">0.00</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer-btn">
                                <button type="button" class="btn btn-cancel me-2" data-bs-dismiss="modal">
                                    Cancel
                                </button>
                                <!-- <button type="submit" class="btn btn-submit">
                                    Create
                                </button> -->
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /New Order -->
<!-- Edit Order -->
<div class="modal fade" id="edit-order" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered stock-adjust-modal">
        <div class="modal-content">
            <div class="page-wrapper-new p-0">
                <div class="content">
                    <div class="modal-header border-0 custom-modal-header">
                        <div class="page-title">
                            <h4>Add Transfer</h4>
                        </div>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body custom-modal-body">
                        <form method="POST" action="<?php echo e(route('admin.invoice-update')); ?>" id="edit_invoice_form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="order_id" id="edit-order-id" value="">

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Select Store</label>
                                        <select name="edit_store_from" id="edit_store_from" class="form-control select">
                                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($store->id == $selectedStore): ?>
                                            <option value="<?php echo e($store->id); ?>" selected><?php echo e($store->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Customer</label>
                                        <div class="input-block d-flex align-items-center mt-2">
                                            <div class="flex-grow-1 me-2">
                                                <select class="select" name="edit_customer_id"
                                                    id="edit_customer_select">
                                                    <option value="">Choose Customer</option>
                                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->customer_name); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <a href="#" class="btn btn-primary btn-icon open-create-modal">
                                                <i data-feather="user-plus" class="feather-16"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-blocks search-form mb-3">
                                        <label>Product</label>
                                        <input type="text" id="edit_product_search" class="form-control"
                                            placeholder="Search Product by Name or SKU" />
                                        <ul id="edit_product_list" class="list-group"
                                            style="max-height: 200px; overflow-y: auto; position: absolute; z-index: 1000; width: 100%; display: none;">
                                        </ul>
                                        <i data-feather="search" class="feather-search"></i>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="modal-body-table">
                                        <div class="table-responsive">
                                            <table class="table datanew">
                                                <thead>
                                                    <tr>
                                                        <th>Product</th>
                                                        <th>SKU</th>
                                                        <th>Category</th>
                                                        <th>Qty</th>
                                                        <th>Price</th>
                                                        <th class="no-sort">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="edit_product_tbody">
                                                    <!-- JS will populate rows -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Order Tax</label>
                                        <select name="edit_tax" id="edit_taxDropdown" class="select">
                                            <option value="0">No Tax</option>
                                            <option value="5">GST 5%</option>
                                            <option value="10">GST 10%</option>
                                            <option value="15">GST 15%</option>
                                            <option value="20">GST 20%</option>
                                            <option value="25">GST 25%</option>
                                            <option value="30">GST 30%</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="input-blocks">
                                        <label>Discount</label>
                                        <select name="edit_discount" id="edit_discountDropdown" class="select">
                                            <option value="0">No Discount</option>
                                            <option value="5">5%</option>
                                            <option value="10">10%</option>
                                            <option value="15">15%</option>
                                            <option value="20">20%</option>
                                            <option value="25">25%</option>
                                            <option value="30">30%</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6 mt-5">
                                        <div class="order-total">
                                            <table class="table table-responsive table-borderless">
                                                <tr>
                                                    <td>Sub Total</td>
                                                    <td class="text-end" id="edit_sub_total">$0.00</td>
                                                </tr>
                                                <tr>
                                                    <td id="edit_tax_percentage">Tax (GST 0%)</td>
                                                    <td class="text-end" id="edit_tax">$0.00</td>
                                                </tr>
                                                <tr>
                                                    <td id="edit_discount_percentage">Discount (0%)</td>
                                                    <td class="danger text-end" id="edit_discount">$0.00</td>
                                                </tr>
                                                <tr>
                                                    <td>Total</td>
                                                    <td class="text-end" id="edit_total">$0.00</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-5">
                                        <div class="block-section payment-method">
                                            <h6>Payment Method</h6>
                                            <div class="row d-flex align-items-center justify-content-center methods">
                                                <input type="hidden" name="edit_payment_method"
                                                    id="edit_payment_method" />
                                                <div class="col-md-6 col-lg-4 item cash-method">
                                                    <div class="default-cover">
                                                        <a href="javascript:void(0);" class="edit-payment-option"
                                                            data-method="Cash"><span><img
                                                                    src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/cash-pay.svg"
                                                                    alt="Cash" />Cash</span></a>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-4 item">
                                                    <div class="default-cover">
                                                        <a href="javascript:void(0);" class="edit-payment-option"
                                                            data-method="Card"><span><img
                                                                    src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/credit-card.svg"
                                                                    alt="Card" />Debit
                                                                Card</span></a>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-4 item">
                                                    <div class="default-cover">
                                                        <a href="javascript:void(0);" class="edit-payment-option"
                                                            data-method="Scan"><span><img
                                                                    src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/qr-scan.svg"
                                                                    alt="Scan" />Scan</span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-grid btn-block mt-5">
                                            <button type="submit" id="submit_edit_invoice" class="btn btn-secondary">
                                                Update Order: $<span id="edit_placeOrderValue">0.00</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer-btn">
                                <button type="button" class="btn btn-cancel me-2"
                                    data-bs-dismiss="modal">Cancel</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Edit Order -->
<!-- Eye button view modal -->
<div class="modal fade" id="edit-invoice">
    <div class="modal-dialog modal-dialog-centered stock-adjust-modal">
        <div class="modal-content">
            <div class="page-wrapper-new p-0">
                <div class="content">
                    <div class="modal-header border-0 custom-modal-header">
                        <div class="page-title">
                            <h4>View Invoice</h4>
                        </div>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body custom-modal-body">
                        <form>

                            <div class="row">
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Store</label>
                                        <input type="text" class="form-control" value="" name="store_name" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Invoice No.</label>
                                        <input type="text" class="form-control" value="" name="invoice_no" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Due Date</label>
                                        <input type="text" class="form-control" value="" name="due_date" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label>Amount</label>
                                        <input type="text" class="form-control list" value="" name="amount" disabled />
                                    </div>
                                </div>

                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Amount paid</label>
                                        <input type="text" class="form-control list" value="" name="amount_paid"
                                            disabled />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Amount Due</label>
                                        <input type="text" class="form-control list" value="$0.00" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 col-12">
                                    <div class="mb-3 add-product">
                                        <label class="form-label">Status</label>
                                        <input type="text" class="form-control list" value="" name="status" disabled />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Eye button view modal -->

<!-- Create customer -->
<div class="modal fade" id="create" tabindex="-1" aria-labelledby="create" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="create-customer-form">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12 col-12">
                            <div class="input-blocks">
                                <label>Customer Name</label>
                                <input name="customer_name" type="text" class="form-control" />
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12 col-12">
                            <div class="input-blocks">
                                <label>Email</label>
                                <input name="email" type="email" class="form-control" />
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12 col-12">
                            <div class="input-blocks">
                                <label>Phone</label>
                                <input name="phone" type="text" class="form-control" />
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12 col-12">
                            <div class="input-blocks">
                                <label>Country</label>
                                <input name="country" type="text" class="form-control" />
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12 col-12">
                            <div class="input-blocks">
                                <label>City</label>
                                <input name="city" type="text" />
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12 col-12">
                            <div class="input-blocks">
                                <label>Address</label>
                                <input name="address" type="text" />
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer d-sm-flex justify-content-end">
                        <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-submit me-2">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Receipt Print -->
<div class="modal fade modal-default" id="print-receipt" aria-labelledby="print-receipt">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="d-flex justify-content-end">
                <button type="button" class="close p-0 no-print" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="icon-head text-center">
                    <a href="javascript:void(0);">
                        <h6>Accounting and Stock Management System</h6>
                    </a>
                </div>
                <div class="text-center info">
                    <h6>Accounting and Stock Management System,</h6>
                    <p class="mb-0">Phone Number: +1 5656665656</p>
                    <p class="mb-0">
                        Email:
                        <a href="mailto:email@gmail.com">email@gmail.com</a>
                    </p>
                </div>

                <div class="tax-invoice">
                    <h6 class="text-center">Tax Invoice</h6>
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <div class="invoice-user-name">
                                <span>Name: </span><span></span>
                            </div>
                            <div class="invoice-user-name">
                                <span>Invoice No: </span><span>CS132453</span>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="invoice-user-name">
                                <span>Customer Id: </span><span></span>
                            </div>
                            <div class="invoice-user-name">
                                <span>Date: </span><span>01.07.2022</span>
                            </div>
                        </div>
                    </div>
                </div>

                <table class="table-borderless w-100 table-fit">
                    <thead>
                        <tr>
                            <th># Item</th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td>product1</td>
                            <td>$00</td>
                            <td>0</td>
                            <td>$0</td>
                        </tr>

                        <tr>
                            <td colspan="4">
                                <table class="table-borderless w-100 table-fit">
                                    <tr>
                                        <td>Sub Total :</td>
                                        <td class="text-end">$0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Discount (0%) :</td>
                                        <td class="text-end">-$0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Shipping (0%) :</td>
                                        <td class="text-end">0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Tax (0%) :</td>
                                        <td class="text-end">$0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Total Bill :</td>
                                        <td class="text-end">$0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Due :</td>
                                        <td class="text-end">$0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Total Payable :</td>
                                        <td class="text-end">$0.00</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <div class="text-center invoice-bar">
                    <p>
                        **VAT against this challan is payable through central
                        registration. Thank you for your business!
                    </p>
                    <a href="javascript:void(0);">
                        <img src="assets/img/barcode/barcode-03.jpg" alt="Barcode" />
                    </a>
                    <p>Sale 31</p>
                    <p>Thank You For Shopping With Us. Please Come Again</p>
                    <a href="javascript:void(0);" class="btn btn-primary no-print" id="printButton">Print Receipt</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Receipt Print -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        let userRoleId = <?php echo e(auth() -> user() -> role_id); ?>;

    let columns = [
        { data: 'order_id', name: 'id' },
        { data: 'store_name', name: 'store_name' },
        { data: 'created_at', name: 'created_at' },
        { data: 'total_price', name: 'total_price', orderable: false, searchable: false },
        { data: 'paid_price', name: 'paid_price', orderable: false, searchable: false },
        { data: 'due', name: 'due', orderable: false, searchable: false },
        { data: 'payment_status', name: 'payment_status', orderable: false, searchable: false }
    ];

    if (userRoleId !== 5) {
        columns.push({ data: 'actions', name: 'actions', orderable: false, searchable: false });
    }

    let table = $('#order-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('admin.invoice')); ?>",
            data: function (d) {
                d.store = $('#filter_store').val();
                d.order_type = $('#sort-order').val();
                d.date_to = $('#date-to').val();
                d.date_from = $('#date-from').val();
            }
        },
        columns: columns,
        pageLength: 10,
        drawCallback: function () {
            feather.replace();
        },
        initComplete: function () {
            let searchWrapper = $('#order-table_filter');
            let defaultSearchBox = searchWrapper.find('input');
            $('#custom-search').append(defaultSearchBox);
            defaultSearchBox.attr('placeholder', 'Search...');
            searchWrapper.remove();
        }
    });

    $('#filter_store').on('change', function () {
        table.ajax.reload();
    });
    $('#sort-order').on('change', function () {
        table.ajax.reload();
    });
    $('#searchBtn').on('click', function () {
        table.ajax.reload();
    });
});

</script>
<script>
    $(document).ready(function () {
        $("#taxDropdown, #discountDropdown").on("change", calculateTotals);
        $(document).on("input", 'input[name="qty[]"], input[name="price[]"]', calculateTotals);
        $(document).on("click", ".delete-row", calculateTotals);

        // $(".viewInvoice").on("click", function () {
        $(document).on("click", ".viewInvoice", function () {
            var invoiceId = $(this).data("id");


            $.ajax({
                url: "<?php echo e(route('admin.view-invoice')); ?>",
                type: "GET",
                data: {
                    invoiceId: invoiceId,
                },
                success: function (response) {
                    const date = new Date(response.data.created_at);
                    const formatted = date.toISOString().substring(0, 10);

                    if (response.success) {
                        console.log(response);

                        $('#edit-invoice input[name="store_name"]').val(
                            response.store_name
                        );
                        $('#edit-invoice input[name="invoice_no"]').val(
                            'INV/' + response.data.id
                        );
                        $('#edit-invoice input[name="due_date"]').val(
                            formatted
                        );
                        $('#edit-invoice input[name="amount"]').val(
                            response.data.total_price
                        );

                        $('#edit-invoice input[name="amount_paid"]').val(
                            response.data.total_price
                        );
                        $('#edit-invoice input[name="address"]').val(
                            response.data.address
                        );
                        $('#edit-invoice input[name="status"]').val(
                            response.data.status == 0
                                ? "Unpaid"
                                : "Paid"
                        );

                        $("#edit-invoice").modal("show");
                    } else {
                        alert("Invoice details not found!");
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error:", xhr.responseText);
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: "Failed to View/Find Invoice. Please try again.",
                        confirmButtonColor: "#d33",
                    });
                },
            });
        });

    })
</script>

<script>
    $("#product_search").on("focus", function () {
        let storeId = $("#store_from").val();
        if (storeId === "") {
            Swal.fire({
                icon: "warning",
                title: "Select Store!",
                text: "Please select a store first.",
            });
            return;
        }
        fetchProducts(storeId, $(this).val());
    });

    $("#product_search").on("keyup", function () {
        let query = $(this).val();
        let storeId = $("#store_from").val();

        if (storeId === "") {
            Swal.fire({
                icon: "warning",
                title: "Select Store!",
                text: "Please select a store first.",
            });
            return;
        }

        fetchProducts(storeId, query);
    });

    function fetchProducts(storeId, query) {
        $.ajax({
            url: "<?php echo e(route('admin.get-products-invoice')); ?>",
            method: "GET",
            data: { store_id: storeId, query: query },
            success: function (response) {
                $("#product_list").empty().show();

                if (response.length === 0) {
                    $("#product_list").append('<li class="list-group-item">No products found</li>');
                } else {
                    $.each(response, function (index, product) {
                        $("#product_list").append(`
                            <li class="list-group-item product-item" 
                                data-id="${product.product_id}"  
                                data-name="${product.product_name}" 
                                data-sku="${product.sku}" 
                                data-category="${product.category_name}"
                                data-category_id="${product.category_id}"
                                data-qty="${product.total_quantity}"
                                data-price="${product.price}">
                                ${product.product_name} - SKU: ${product.sku} - Qty: ${product.total_quantity}
                            </li>
                        `);
                    });
                }
            },
            error: function () {
                Swal.fire({
                    icon: "error",
                    title: "Error!",
                    text: "Failed to load products.",
                });
            },
        });
    }

    $(document).on("click", ".product-item", function () {
        let productId = $(this).data("id");
        let productName = $(this).data("name");
        let sku = $(this).data("sku");
        let category = $(this).data("category");
        let category_id = $(this).data("category_id")
        let availableQty = $(this).data("qty");
        let price = $(this).data("price");

        addProductToTable(productId, productName, sku, category, availableQty, price, category_id);
        $("#product_list").empty().hide();
        $("#product_search").val("");
    });

    function addProductToTable(productId, productName, sku, category, availableQty, price, category_id) {
        let isDuplicate = false;
        $("#product-tbody tr").each(function () {
            let existingProductId = $(this).find('input[name="product_id[]"]').val();
            if (existingProductId == productId) {
                isDuplicate = true;
                return false;
            }
        });

        if (isDuplicate) {
            Swal.fire({
                icon: "warning",
                title: "Duplicate Product!",
                text: "This product is already added to the list.",
            });
            return;
        }

        let newRow = `
            <tr>
                <td><input type="hidden" name="product_id[]" value="${productId}" />
                    <input type="text" name="product_name[]" class="form-control" value="${productName}" readonly /></td>
                <td><input type="text" name="sku[]" class="form-control" value="${sku}" readonly /></td>
                <td><input type="text" name="category[]" class="form-control" value="${category}" readonly /></td>
                <td><input type="hidden" name="category_id[]" value="${category_id}" /></td>
                <td>
                    <input type="number" name="qty[]" class="form-control product-qty" style="margin:20px 0 0 0;"
                        value="${availableQty > 0 ? 1 : 0}" min="1" max="${availableQty}" data-available="${availableQty}" />
                    <small class="available-qty">Available Qty: ${availableQty}</small>
                </td>
                <td><input type="text" name="price[]" class="form-control" value="${price}" readonly /></td>
                <td><a href="javascript:void(0);" class="btn btn-danger btn-sm delete-row">Delete</a></td>
            </tr>
        `;
        $("#product-tbody").append(newRow);
        calculateTotals();
    }

    $(document).on("input", ".product-qty", function () {
        let enteredQty = parseInt($(this).val());
        let availableQty = parseInt($(this).data("available"));
        if (enteredQty > availableQty) {
            Swal.fire({
                icon: "error",
                title: "Quantity Exceeded!",
                text: `Available quantity is only ${availableQty}.`,
            });
            $(this).val(availableQty);
        }
    });

    $("#store_from").on("change", function () {
        $("#product_list").empty().hide(); // clear and hide product list
        $("#product_search").val("");      // clear search input
    });

    $(document).on("click", ".delete-row", function () {
        $(this).closest("tr").remove();
    });

    $(document).on("click", function (e) {
        if (!$(e.target).closest("#product_search, #product_list").length) {
            $("#product_list").hide();
        }
    });

    $("#transferForm").on("submit", function (e) {
        e.preventDefault();

        const paymentMethod = $('#payment_method').val();
        const customerId = $('#customer-select').val();
        let formData = $(this).find(":input").not("#product-row-template :input").serialize();

        if ($('#product-tbody tr:not(#product-row-template)').length === 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Empty Cart',
                text: 'Please add at least one product before placing the order.',
                confirmButtonColor: '#3085d6'
            });
            return;
        }


        if (!customerId) {
            Swal.fire({
                icon: 'warning',
                title: 'Customer Required',
                text: 'Please select a customer.',
            });
            return;
        }

        if (!paymentMethod) {
            Swal.fire({
                icon: 'warning',
                title: 'Payment Required',
                text: 'Please select a payment method.',
            });
            return;
        }


        $.ajax({
            url: "<?php echo e(route('admin.invoice-order')); ?>",
            method: "POST",
            data: formData,
            success: function (response) {
                if (response.success) {
                    Swal.fire({
                        icon: "success",
                        title: "Order Successful!",
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: response.message,
                    });
                }
            },
            error: function () {
                Swal.fire({
                    icon: "error",
                    title: "Error!",
                    text: "Failed to create order.",
                });
            },
        });
    });
</script>
<script>
    // EDIT INVOICE
    $(document).on('click', '.edit-order', function () {
        const orderId = $(this).data('id');

        $.ajax({
            url: "<?php echo e(Route('admin.invoice-edit')); ?>",
            type: 'GET',
            data: { id: orderId },
            success: function (response) {
                if (response.success) {
                    const order = response.data;
                    const items = response.data.order_items;
                    $('#edit-order-id').val(order.id);
                    $('#edit_store_from').val(order.store_id).trigger('change');
                    $('#edit_customer_select').val(order.customer_id).trigger('change');
                    $('#edit_taxDropdown').val(order.tax).trigger('change');
                    $('#edit_discountDropdown').val(order.discount).trigger('change');
                    $('#edit_payment_method').val(order.payment_method);
                    $('#edit_product_tbody').empty();

                    items.forEach(function (item) {
                        let availableQty = item.available_qty || 0;
                        const row = `
                            <tr>
                                <td>
                                    <input type="hidden" name="edit_product_id[]" class="form-control" value="${item.product_id}" />
                                    <input type="text" name="edit_product_name[]" class="form-control" value="${item.product_name}" readonly />
                                </td>
                                <td>
                                    <input type="text" name="edit_sku[]" class="form-control" value="${item.sku}" readonly />
                                </td>
                                <td>
                                    <input type="hidden" name="edit_category_id[]" value="${item.category_id}" />
                                    <input type="text" class="form-control" value="${item.category_name || 'N/A'}" readonly />
                                </td>
                                <td>
                                    <input type="number" name="edit_qty[]" class="form-control edit_qty" style="margin:20px 0 0 0;"
                                        value="${availableQty > 0 ? item.qty : 0}" min="1" max="${availableQty}" data-available="${availableQty}" />
                                    <small class="available-qty">Available Qty: ${availableQty}</small>
                                </td>
                                <td>
                                    <input type="text" name="edit_price[]" class="form-control" value="${item.price}" readonly />
                                </td>
                                <td >
                                    <a class="btn btn-danger btn-sm delete-row" href="javascript:void(0);">
                                        <i data-feather="trash-2" class="feather-trash-2"></i>
                                    </a>
                                </td>
                            </tr>`;
                        $('#edit_product_tbody').append(row);
                        feather.replace();
                    });


                    $('#edit-order').modal('show');
                    setTimeout(() => {
                        $('.edit-payment-option').removeClass('selected');
                        $('.edit-payment-option[data-method="' + order.payment_method + '"]').addClass('selected');

                    }, 300); // Delay to ensure DOM is fully loaded
                    updateEditOrderTotals();
                    $(document).on('input change', 'input[name="edit_qty[]"],  #edit_taxDropdown, #edit_discountDropdown', function () {
                        updateEditOrderTotals();
                    });
                } else {
                    Swal.fire('Error', 'Failed to load invoice data', 'error');
                }
            },
            error: function () {
                Swal.fire('Error', 'Server error while loading invoice', 'error');
            }
        });
    });

    // Product Search for Edit Modal
    $("#edit_product_search").on("keyup focus", function () {
        let query = $(this).val();
        let storeId = $("#edit_store_from").val();

        if (!storeId) {
            Swal.fire({
                icon: "warning",
                title: "Select Store First",
                text: "Please select a store before searching for products.",
            });
            return;
        }

        fetchEditModalProducts(storeId, query);
    });

    function fetchEditModalProducts(storeId, query) {
        $.ajax({
            url: "<?php echo e(route('admin.get-products-invoice')); ?>",
            method: "GET",
            data: { store_id: storeId, query: query },
            success: function (response) {
                $("#edit_product_list").empty().show();

                if (response.length === 0) {
                    $("#edit_product_list").append('<li class="list-group-item">No products found</li>');
                } else {
                    $.each(response, function (index, product) {
                        $("#edit_product_list").append(`
                            <li class="list-group-item edit-product-item"
                                data-id="${product.product_id}"
                                data-name="${product.product_name}"
                                data-sku="${product.sku}"
                                data-category="${product.category_name}"
                                data-category_id="${product.category_id}"
                                data-qty="${product.total_quantity}"
                                data-price="${product.price}">
                                ${product.product_name} - SKU: ${product.sku} - Qty: ${product.total_quantity}
                            </li>`);
                    });
                }
            },
            error: function () {
                Swal.fire({
                    icon: "error",
                    title: "Error!",
                    text: "Failed to fetch products.",
                });
            }
        });
    }

    $(document).on("click", ".edit-product-item", function () {
        let productId = $(this).data("id");
        let productName = $(this).data("name");
        let sku = $(this).data("sku");
        let category = $(this).data("category");
        let category_id = $(this).data("category_id");
        let availableQty = $(this).data("qty");
        let price = $(this).data("price");

        let isDuplicate = false;
        $("#edit_product_tbody tr").each(function () {
            if ($(this).find('input[name="edit_product_id[]"]').val() == productId) {
                isDuplicate = true;
                return false;
            }
        });

        if (isDuplicate) {
            Swal.fire({
                icon: "warning",
                title: "Duplicate Product",
                text: "This product is already added.",
            });
            return;
        }

        const newRow = `
        <tr>
            <td>
                <input type="hidden" name="edit_product_id[]" class="form-control" value="${productId}" />
                <input type="text" name="edit_product_name[]" class="form-control" value="${productName}" readonly />
            </td>
            <td>
                <input type="text" name="edit_sku[]" class="form-control" value="${sku}" readonly />
            </td>
            <td>
                <input type="hidden" name="edit_category_id[]" value="${category_id}" />
                <input type="text" class="form-control" value="${category}" readonly />
            </td>
            <td>
                <input type="number" name="edit_qty[]" class="form-control edit-qty" style="margin:20px 0 0 0;"
                    value="${availableQty > 0 ? 1 : 0}" min="1" max="${availableQty}" data-available="${availableQty}" />
                <small class="available-qty">Available Qty: ${availableQty}</small>
            </td>
            <td>
                <input type="text" name="edit_price[]" class="form-control" value="${price}" readonly />
            </td>
            <td >
                <a class="btn btn-danger btn-sm delete-row" href="javascript:void(0);">
                    <i data-feather="trash-2" class="feather-trash-2"></i>
                </a>
            </td>
        </tr>`;

        $("#edit_product_tbody").append(newRow);
        $("#edit_product_list").empty().hide();
        $("#edit_product_search").val("");
        feather.replace();
        updateEditOrderTotals();
        $(document).on('input change', 'input[name="edit_qty[]"], #edit_taxDropdown, #edit_discountDropdown', function () {
            updateEditOrderTotals();
        });
    });

    $(document).on("click", function (e) {
        if (!$(e.target).closest("#edit_product_search, #edit_product_list").length) {
            $("#edit_product_list").hide();
        }
    });

    $(document).on('click', '#submit_edit_invoice', function (e) {
        e.preventDefault();
        let formData = {
            order_id: $('#edit-order-id').val(), // ensure this hidden field exists in modal
            store_id: $('#edit_store_from').val(),
            customer_id: $('#edit_customer_select').val(),
            tax: $('#edit_taxDropdown').val(),
            discount: $('#edit_discountDropdown').val(),
            payment_method: $('#edit_payment_method').val(),
            product_id: $("input[name='edit_product_id[]']").map(function () { return $(this).val(); }).get(),
            product_name: $("input[name='edit_product_name[]']").map(function () { return $(this).val(); }).get(),
            sku: $("input[name='edit_sku[]']").map(function () { return $(this).val(); }).get(),
            qty: $("input[name='edit_qty[]']").map(function () { return $(this).val(); }).get(),
            price: $("input[name='edit_price[]']").map(function () { return $(this).val(); }).get(),
            category_id: $("input[name='edit_category_id[]']").map(function () { return $(this).val(); }).get(),
            _token: "<?php echo e(csrf_token()); ?>"
        };

        $.ajax({
            url: "<?php echo e(route('admin.invoice-update')); ?>",
            method: "POST",
            data: formData,
            success: function (response) {
                if (response.success) {
                    $('#edit-order').modal('hide');
                    Swal.fire('Success', response.message, 'success');
                    // Optionally reload table or page
                    location.reload();
                } else {
                    Swal.fire('Error', response.message, 'error');
                }
            },
            error: function () {
                Swal.fire('Error', 'Server error while updating invoice.', 'error');
            }
        });
    });

</script>

<script>
    //OPEN THE CUSTOMER MODAL OVER THE INVOICE GENERATION MODAL
    $(document).on('click', '.open-create-modal', function (e) {
        e.preventDefault();
        $('#create').modal({
            backdrop: false, // Prevents closing both modals when clicking outside
            keyboard: false  // Optional: disables ESC close for the second modal
        });
        $('#create').modal('show');
        // Optionally, adjust z-index if needed:
        $('#create').css('z-index', 1061); // Bootstrap default is 1050 for modals
        $('.modal-backdrop').last().css('z-index', 1060); // Ensure backdrop is below the top modal
    });
</script>
<script>
    $(document).on('click', '.payment-option', function () {
        $('.payment-option').removeClass('selected');
        $(this).addClass('selected');
        let method = $(this).data('method');
        $('#payment_method').val(method);
    });

    $(document).on('click', '.edit-payment-option', function () {
        $('.edit-payment-option').removeClass('selected');
        $(this).addClass('selected');
        let method = $(this).data('method');
        $('#edit_payment_method').val(method);
    });
</script>
<script>
    $("#create-customer-form").on("submit", function (event) {
        event.preventDefault();
        var customerData = $(this).serialize();

        $.ajax({
            url: "<?php echo e(route('admin.create-customer')); ?>",
            method: "POST",
            data: customerData,
            success: function (response) {
                if (response.success && response.data) {
                    let newOption = `<option value="${response.data.id}" selected>
                    ${response.data.customer_name}
                </option>`;
                    $("#customer-select")
                        .append(newOption)
                        .val(response.data.id)
                        .trigger("change");

                    Swal.fire({
                        icon: "success",
                        title: "Customer Created",
                        text: response.message,
                    });
                    $("#create").modal("hide");
                    $(".modal-backdrop").remove();
                    $("body").removeClass("modal-open");
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Failed to create customer.",
                    });
                }
            },
            error: function (error) {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: error.responseJSON?.message || "Something went wrong.",
                });
            },
        });
    });

</script>
<script>
    function calculateTotals() {
        let subtotal = 0;

        $("#product-tbody tr").each(function () {
            const qty = parseFloat($(this).find('input[name="qty[]"]').val()) || 0;
            const price = parseFloat($(this).find('input[name="price[]"]').val()) || 0;
            subtotal += qty * price;
        });

        const taxRate = parseFloat($("#taxDropdown").val()) || 0;
        const discountRate = parseFloat($("#discountDropdown").val()) || 0;

        const taxAmount = (subtotal * taxRate) / 100;
        const discountAmount = (subtotal * discountRate) / 100;
        const total = subtotal + taxAmount - discountAmount;

        $("#sub-total").text(`$${subtotal.toFixed(2)}`);
        $("#tax").text(`$${taxAmount.toFixed(2)}`);
        $("#discount").text(`$${discountAmount.toFixed(2)}`);
        $("#total").text(`$${total.toFixed(2)}`);
        $("#placeOrderValue").text(total.toFixed(2));
        $("#tax_percentage").text(`Tax (GST ${taxRate}%)`);
        $("#discount_percentage").text(`Discount (${discountRate}%)`);
    }
</script>
<script>
    function updateEditOrderTotals() {
        let subtotal = 0;

        $('#edit_product_tbody tr').each(function () {
            let qty = parseFloat($(this).find('input[name="edit_qty[]"]').val()) || 0;
            let price = parseFloat($(this).find('input[name="edit_price[]"]').val()) || 0;
            subtotal += qty * price;
        });

        let taxPercent = parseFloat($('#edit_taxDropdown').val()) || 0;
        let discountPercent = parseFloat($('#edit_discountDropdown').val()) || 0;

        let tax = subtotal * (taxPercent / 100);
        let discount = subtotal * (discountPercent / 100);
        let total = subtotal + tax - discount;

        $('#edit_sub_total').text('$' + subtotal.toFixed(2));
        $('#edit_tax').text('$' + tax.toFixed(2));
        $('#edit_discount').text('$' + discount.toFixed(2));
        $('#edit_total').text('$' + total.toFixed(2));
        $('#edit_placeOrderValue').text(total.toFixed(2));

        $('#edit_tax_percentage').text('Tax (GST ' + taxPercent + '%)');
        $('#edit_discount_percentage').text('Discount (' + discountPercent + '%)');

    }

</script>
<script>
    $(document).ready(function () {
        $(document).on('click', '.print-receipt', function () {
            let transactionId = $(this).data("id");
            let customerName = $(this).data("customer");
            let date = $(this).data("date");
            let total = $(this).data("total");
            let invoice = $(this).data("invoice");
            let custId = $(this).data("customerid");
            let formattedName = customerName.replace(/\b\w/g, (c) =>
                c.toUpperCase()
            );

            // Update modal content
            $("#print-receipt .invoice-user-name span:contains('Name:')")
                .next()
                .text(formattedName);
            $("#print-receipt .invoice-user-name span:contains('Customer Id:')")
                .next()
                .text(custId);
            $("#print-receipt .invoice-user-name span:contains('Invoice No:')")
                .next()
                .text(invoice);
            $("#print-receipt .invoice-user-name span:contains('Date:')")
                .next()
                .text(date);
            $("#print-receipt .text-end:contains('Total Bill')")
                .next()
                .text(total);
            $("#print-receipt .text-end:contains('Total Payable')")
                .next()
                .text(total);

            $.ajax({
                url: "<?php echo e(route('admin.get-orderItems', '')); ?>/" + transactionId,
                type: "GET",
                success: function (response) {
                    let tbody = $("#print-receipt tbody");
                    tbody.empty();
                    let subTotal = response.sub_total;
                    let discount = response.discount;
                    let shipping = response.shipping;
                    let tax = response.tax;
                    let totalBill = response.total_bill;
                    let totalPayable = response.total_payable;
                    let taxAmount = (tax / 100) * subTotal;
                    let discountAmount = (discount / 100) * subTotal;
                    let shippingAmount = (shipping / 100) * subTotal;
                    $.each(response.items, function (index, item) {
                        let itemTotal = item.price * item.qty;
                        let row = `
                <tr>
                    <td>${item.product_name}</td>
                    <td>${item.price}</td>
                    <td>${item.qty}</td>
                    <td>${itemTotal.toFixed(2)}</td>
                </tr>`;
                        tbody.append(row);
                    });

                    // Append bill summary
                    let summary = `
                    <tr>
                        <td colspan="4">
                            <table class="table-borderless w-100 table-fit">
                                <tr>
                                    <td>Sub Total :</td>
                                    <td class="text-end">$${subTotal.toFixed(
                        2
                    )}</td>
                                </tr>
                                <tr>
                                    <td>Discount (${discount}%):</td>
                                    <td class="text-end">-$${discountAmount.toFixed(
                        2
                    )}</td>
                                </tr>
                                <tr>
                                    <td>Shipping (${shipping}%):</td>
                                    <td class="text-end">$${shippingAmount.toFixed(
                        2
                    )}</td>
                                </tr>
                                <tr>
                                    <td>Tax (${tax}%):</td>
                                    <td class="text-end">$${taxAmount.toFixed(
                        2
                    )}</td>
                                </tr>
                                <tr>
                                    <td>Total Bill :</td>
                                    <td class="text-end">$${totalBill.toFixed(
                        2
                    )}</td>
                                </tr>
                                <tr>
                                    <td>Due :</td>
                                    <td class="text-end">$0.00</td>
                                </tr>
                                <tr>
                                    <td>Total Payable :</td>
                                    <td class="text-end">$${totalPayable.toFixed(
                        2
                    )}</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    `;

                    tbody.append(summary);
                },
            });
        });
    });

    $(document).ready(function () {
        $("#printButton").click(function () {
            let printContents =
                document.getElementById("print-receipt").outerHTML;
            let styles = document.head.innerHTML;

            let printWindow = window.open("", "", "width=800,height=600");
            printWindow.document.write(`
        <html>
        <head>
            <title>Print Receipt</title>
            ${styles}  <!-- This ensures all styles are included -->
        </head>
        <body>
            ${printContents}
            <script>
                document.querySelectorAll(".no-print").forEach(el => el.style.display = "none"); 
                window.print();
                window.close();
            <\/script>
        </body>
        </html>
        `);

            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        });
    });
</script>
<style>
    .modal-backdrop+.modal-backdrop {
        z-index: 1060 !important;
    }

    .modal.show {
        z-index: 1061 !important;
        backdrop-filter: blur(40px);
    }

    #product_list {
        max-height: 200px;
        overflow-y: auto;
        position: absolute;
        z-index: 1000;
        width: 100%;
        display: none;
    }

    .modal-dialog.stock-adjust-modal {
        max-width: 1099px;
    }

    .payment-method .methods .default-cover a {
        box-shadow: rgba(190, 190, 190, 0.27) 0px 4px 60px 0px;
        text-align: center;
        display: block;
        font-size: 15px;
        color: rgb(9, 44, 76);
        padding: 10px 15px;
    }

    .payment-method .methods .default-cover span {
        padding: 13px 15px 12px 6px
    }

    .payment-method .methods .default-cover span img {
        margin: 5px 7px -4px 0;

    }

    .swal2-container {
        z-index: 2000 !important;
    }

    .btn-icon {
        width: 6.313rem;
        height: 2.313rem;
        font-size: 0.95rem;
        flex-shrink: 0;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\stockmgnt\resources\views/admin/invoice.blade.php ENDPATH**/ ?>