 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Profile</h4>
                <h6>User Profile</h6>
            </div>
        </div>

        <!-- /product list -->

        <form
            id="profileForm"
            action="<?php echo e(route('postProfile')); ?>"
            method="post"
            enctype="multipart/form-data"
        >
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="profile-set">
                        <div class="profile-head"></div>
                        <div class="profile-top">
                            <div class="profile-content">
                                <div class="profile-contentimg">
                                    <img
                                    src="<?php echo e($user->profile_image ? asset('storage/' . $user->profile_image) : asset('admin\assets\img\avatar\default-avatar.png')); ?>"
                                        alt="img"
                                        id="blah"
                                        name="profile_image"
                                        class="img-thumbnail"
                                    />
                                    <div class="profileupload">
                                        <input
                                            name="file"
                                            type="file"
                                            id="imgInp"
                                        />
                                        <a href="javascript:void(0);">
                                            <img
                                                src="\admin\assets\img\icons\edit-set.svg"
                                                alt="img"
                                            />
                                        </a>
                                    </div>

                                    
                                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="profile-contentname">
                                    <h2><?php echo e($user->username); ?></h2>
                                    <h4>
                                        Updates Your Photo and Personal Details.
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="input-blocks">
                                <label class="form-label">First Name</label>
                                <input
                                    name="firstName"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter First Name"
                                    value="<?php echo e(old('firstName', $user->first_name)); ?>"
                                />
                                <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="input-blocks">
                                <label class="form-label">Last Name</label>
                                <input
                                    name="lastName"
                                    value="<?php echo e(old('lastName', $user->last_name)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter Last Name"
                                />
                                <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="input-blocks">
                                <label>Email</label>
                                <input
                                    name="email"
                                    value="<?php echo e(old('email', $user->email)); ?>"
                                    type="email"
                                    class="form-control"
                                    placeholder="Enter Email Address"
                                />
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="input-blocks">
                                <label class="form-label">Phone</label>
                                <input
                                    name="phone"
                                    value="<?php echo e(old('phone', $user->phone)); ?>"
                                    class="form-control"
                                    type="text"
                                    placeholder="Enter Phone no."
                                />
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="input-blocks">
                                <label class="form-label">User Name</label>
                                <input
                                    name="username"
                                    value="<?php echo e(old('username', $user->username)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter Username"
                                />
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="input-blocks">
                                <label class="form-label">Password</label>
                                <div class="pass-group">
                                    <input
                                        name="password"
                                        type="password"
                                        class="pass-input form-control"
                                    />
                                    <span
                                        class="fas toggle-password fa-eye-slash"
                                    ></span>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="card-title-head">
                        <h6>
                            <span
                                ><i
                                    data-feather="map-pin"
                                    class="feather-chevron-up"
                                ></i></span
                            >Our Address
                        </h6>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <input
                                    name="address"
                                    value="<?php echo e(old('address', $user->address)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter Address..."
                                />
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="mb-3">
                                <label class="form-label">Country</label>
                                <input
                                    name="country"
                                    value="<?php echo e(old('country', $user->country)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter Country..."
                                />
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="mb-3">
                                <label class="form-label"
                                    >State / Province</label
                                >
                                <input
                                    name="state"
                                    value="<?php echo e(old('state', $user->state)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter State/Province..."
                                />
                                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="mb-3">
                                <label class="form-label">City</label>
                                <input
                                    name="city"
                                    value="<?php echo e(old('city', $user->city)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter City..."
                                />
                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-3">
                            <div class="mb-3">
                                <label class="form-label">Postal Code</label>
                                <input
                                    name="zipcode"
                                    value="<?php echo e(old('zipcode', $user->zipcode)); ?>"
                                    type="text"
                                    class="form-control"
                                    placeholder="Enter Postal Code..."
                                />
                                <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-12">
                            <button class="btn btn-submit me-2" type="submit">
                                submit
                            </button>

                            <a href="/" class="btn btn-cancel"
                                >Cancel</a
                            >
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <!-- /product list -->
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('scripts'); ?>

<script>
    $(document).on("submit", "#profileForm", function (e) {
        e.preventDefault(); // Prevent default form submission

        let formData = new FormData(this);

        // Check if file is selected
        var fileInput = $('input[name="file"]')[0];
        if (fileInput.files.length === 0) {
            var existingProfileImage = $("#profileForm")
                .find("img[name='profile_image']")
                .attr("src");

            // Append existing profile image if no new file is uploaded
            if (existingProfileImage) {
                formData.append("existing_profile_image", existingProfileImage);
            }
        }

        // Log FormData content to debug
        for (let pair of formData.entries()) {
            console.log(pair[0] + ": " + pair[1]);
        }

        $.ajax({
            url: "<?php echo e(route('postProfile')); ?>",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.success) {
                    $(".text-danger").html("");
                    $(".form-control").removeClass("is-invalid");
                    Swal.fire({
                        icon: "success",
                        title: "Profile Updated!",
                        text: response.message,
                        showConfirmButton: false,
                        timer: 2000,
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: response.message,
                    });
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;

                    // Remove all previous error messages
                    $(".text-danger").remove();
                    $(".form-control").removeClass("is-invalid");

                    // Loop through each error and show it below the respective field
                    $.each(errors, function (key, value) {
                        let inputField = $("[name='" + key + "']");
                        if (inputField.length) {
                            inputField.addClass('is-invalid');
                            inputField.closest('.input-blocks, .mb-3').append('<div class="text-danger">' + value[0] + "</div>");
                        }
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: "An error occurred while updating the profile.",
                    });
                }
            },
        });
    });

    // Image Preview on File Select
    // $("#imgInp").change(function () {
    //     let reader = new FileReader();
    //     reader.onload = (e) => {
    //         $("#blah").attr("src", e.target.result);
    //     };
    //     reader.readAsDataURL(this.files[0]);
    // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/profile.blade.php ENDPATH**/ ?>