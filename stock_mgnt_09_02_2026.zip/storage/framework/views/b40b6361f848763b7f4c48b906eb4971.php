<!-- Sidebar -->
<div class="sidebar" id="sidebar">
	<div class="sidebar-inner slimscroll">
		<div id="sidebar-menu" class="sidebar-menu">
			<ul>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Main</h6>
					<ul>
						<li class="submenu">
							<a href="javascript:void(0);" class="subdrop active"><i
									data-feather="grid"></i><span>Dashboard</span><span class="menu-arrow"></span></a>
							<ul>
								<li><a href="<?php echo e(route('admin.superadmin_dashboard')); ?>" class="active">Admin Dashboard</a>
								</li>
								<li><a href="<?php echo e(route('admin.inventory-summary')); ?>">Inventory Dashboard</a></li>
								<li><a href="<?php echo e(route('admin.finance-dashboard')); ?>">Financial Oversight</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Store</h6>
					<ul>
						<li><a href="<?php echo e(route('admin.store-list-superadmin')); ?>"><i data-feather="box"></i><span>All
									Stores</span></a></li>
						<li><a href="<?php echo e(route('admin.stores_communication')); ?>"><i
									data-feather="plus-square"></i><span>Communication</span></a></li>
						<li><a href="<?php echo e(route('admin.daily-operations-overview-superadmin')); ?>"><i
									data-feather="plus-square"></i><span>Daily operations overview</span></a></li>
					</ul>
				</li>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Stock</h6>
					<ul>
						<li><a href="<?php echo e(route('admin.stock.list')); ?>"><i data-feather="box"></i><span>All
									Stock</span></a></li>
						<li><a href="<?php echo e(route('admin.stock.create')); ?>"><i data-feather="plus-square"></i><span>Add
									Stock</span></a></li>
						<li><a href="<?php echo e(route('admin.stocktransfers.index')); ?>"><i data-feather="truck"></i><span>Stock
									transfers</span></a></li>
						<li><a href="<?php echo e(route('admin.stock-adjustment')); ?>"><i data-feather="clipboard"></i><span>Stock
									Adjustment</span></a></li>
						
						<li>
							<a href="<?php echo e(route('admin.categories.index')); ?>"><i data-feather="box"></i><span>All
									Category</span></a>
						</li>
						<li>
							<a href="<?php echo e(route('admin.units.index')); ?>"><i data-feather="box"></i><span>All
									Units</span></a>
						</li>

					</ul>
				</li>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Financial Oversight</h6>
					<ul>
						<li><a href="<?php echo e(route('admin.profit-loss-statement')); ?>"><i data-feather="box"></i><span>Profit &
									Loss Statements</span></a></li>
						<li><a href="<?php echo e(route('admin.balance-sheet')); ?>"><i data-feather="plus-square"></i><span>View
									Balance Sheets</span></a></li>
						<li><a href="<?php echo e(route('admin.invoice')); ?>"><i data-feather="trending-down"></i><span>Invoice
									Management</span></a></li>
						<li><a href="<?php echo e(route('admin.sales-analysis-superadmin')); ?>"><i
									data-feather="codepen"></i><span>Sales Analysis</span></a></li>
					</ul>
				</li>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Staff Management</h6>
					<ul>
						<li><a href="<?php echo e(route('admin.users')); ?>"><i data-feather="user"></i><span>Employees</span></a>
						</li>
						<!-- <li><a href="#"><i data-feather="git-merge"></i><span>permi</span></a></li> -->
						<li><a href="<?php echo e(route('admin.store-employee')); ?>"><i data-feather="user"></i><span>Store
									Employees</span></a></li>
					</ul>
				</li>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Customizable Reports</h6>
					<ul>
						<li><a href="<?php echo e(route('admin.sales-trend')); ?>"><i data-feather="bar-chart-2"></i><span>Sales
									trends</span></a></li>
						<li><a href="<?php echo e(route('admin.inventory-flow-superAdmin')); ?>"><i
									data-feather="inbox"></i><span>Inventory flow</span></a></li>
						<li><a href="<?php echo e(route('admin.top-performing-product')); ?>"><i
									data-feather="bar-chart"></i><span>Top-performing products</span></a></li>
					</ul>
				</li>
				<li class="submenu-open">
					<h6 class="submenu-hdr">Setting</h6>
					<ul>
						<li>
							<a href="<?php echo e(route('admin.history.index')); ?>"><i data-feather="monitor"></i><span>Audit
									Trail</span></a>
						</li>
						<li>
							<a href="<?php echo e(route('admin.setting')); ?>"><i data-feather="monitor"></i><span>Settings</span></a>
						</li>
						<!-- <li>
                            <a href="#"
                                ><i data-feather="hexagon"></i
                                ><span>Audit Logs</span></a
                            >
                        </li> -->
					</ul>
				</li>
				<!-- <li class="submenu-open">
							<h6 class="submenu-hdr">Settings</h6>
							<ul>
								<li><a href="<?php echo e(route('admin.setting')); ?>"><i data-feather="monitor"></i><span>System Settings</span></a></li>
							</ul>
						</li> -->

			</ul>
		</div>
	</div>
</div>
<!-- /Sidebar --><?php /**PATH /var/www/stockmgnt/resources/views/partials/admin/sidebar_superadmin.blade.php ENDPATH**/ ?>