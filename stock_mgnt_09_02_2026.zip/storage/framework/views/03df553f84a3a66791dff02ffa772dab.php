<?php if(is_null($status)): ?>
<span class="badge bg-outline-warning p-2 choose-status" data-id="<?php echo e($id); ?>" data-product="<?php echo e($product_id); ?>"
    data-reference="<?php echo e($reference_no); ?>">
    Pending
</span>
<?php elseif($status === 0): ?>
<span class="badge badge-linedanger choose-status" data-id="<?php echo e($id); ?>">
    Rejected
</span>
<?php elseif($status === 1): ?>
<span class="badge badge-linesuccess choose-status" data-id="<?php echo e($id); ?>">
    Accepted
</span>
<?php endif; ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/partials/storeManagerPartials/outgoing_status_buttons.blade.php ENDPATH**/ ?>