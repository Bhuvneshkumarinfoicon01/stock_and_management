<?php if(is_null($status)): ?>
    <button class="btn btn-primary choose-status" data-id="<?php echo e($id); ?>" data-product="<?php echo e($product_id); ?>"
        onclick="showalert(this,'<?php echo e($id); ?>')" data-reference="<?php echo e($reference_no); ?>">
        Choose Status
    </button>
<?php elseif($status == 0): ?>
    <button class="btn btn-danger choose-status" data-id="<?php echo e($id); ?>">
        Rejected
    </button>
<?php elseif($status == 1): ?>
    <button class="btn btn-success choose-status" data-id="<?php echo e($id); ?>">
        Accepted
    </button>
<?php endif; ?>
<?php /**PATH /var/www/stockmgnt/resources/views/admin/partials/storeManagerPartials/status_buttons.blade.php ENDPATH**/ ?>