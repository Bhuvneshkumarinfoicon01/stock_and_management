<!DOCTYPE html>
<html lang="en" data-layout-mode="light_mode">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="noindex, nofollow">
	<title>Accounting and Stock Management System</title>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<?php echo $__env->make('partials.admin.style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
	<!-- jQuery -->
	<script src="<?php echo e(asset('admin/assets/js/jquery-3.7.1.min.js')); ?>"></script>
	<!-- <script src="<?php echo e(asset('admin/assets/js/jquery.dataTables.min.js')); ?>"></script> -->
	<?php echo $__env->yieldContent('style'); ?>
</head>

<body>
	<div id="global-loader">
		<div class="whirly-loader"> </div>
	</div>
	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<!-- Header -->
		<?php echo $__env->make('partials.admin.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<!-- /Header -->
		<?php //print_r(Auth::user()->role_id);die;?>
		<!-- Sidebar -->
		<?php if(Auth::check()): ?>
		<?php if(Auth::user()->role_id == 1): ?>
		<?php echo $__env->make('partials.admin.sidebar_superadmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php elseif(Auth::user()->role_id == 2): ?>
		<?php echo $__env->make('partials.admin.sidebar_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php elseif(Auth::user()->role_id == 3): ?>
		<?php echo $__env->make('partials.admin.sidebar_storemanager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php elseif(Auth::user()->role_id == 5): ?>
		<?php echo $__env->make('partials.admin.sidebar_clerk', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		<?php endif; ?>
		<?php endif; ?>

		<!-- /Sidebar -->


		<?php echo $__env->make('partials.admin.model', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



		<?php echo $__env->yieldContent('content'); ?>

	</div>
	<!-- /Main Wrapper -->

	<?php echo $__env->make('partials.admin.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
	<?php echo $__env->yieldContent('scripts'); ?>
	<script>
		$(document).on('click', '#refresh-page', function (e) {
			e.preventDefault();
			location.reload();
		});
	</script>

</html><?php /**PATH /var/www/stockmgnt/resources/views/layouts/app_admin.blade.php ENDPATH**/ ?>