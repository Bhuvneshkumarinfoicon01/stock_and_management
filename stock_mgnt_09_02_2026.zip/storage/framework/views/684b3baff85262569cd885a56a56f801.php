 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>>

<div class="page-wrapper">
    <div class="content settings-content">
        <div class="row">
            <div class="col-xl-12">
                <div class="settings-wrapper d-flex">
                    <div class="settings-page-wrap">
                        <div class="setting-title">
                            <h4>Settings</h4>
                        </div>
                        <div class="security-settings">


                            <form action="<?php echo e(route('admin.setting-store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-sm-6 col-12">
                                        <div class="mb-3">
                                            <label class="form-label"><?php echo e($setting->label); ?></label>
                                            <input type="text" placeholder="<?php echo e($setting->placeholder); ?>"
                                                name="<?php echo e($setting->key_name); ?>"
                                                class="form-control <?php $__errorArgs = [$setting->key_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old($setting->key_name, $setting->value ?? '')); ?>">
                                            <?php $__errorArgs = [$setting->key_name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="text-end settings-bottom-btn">
                                    <a href="javascript:void(0);" class="btn btn-cancel me-2">Reset</a>
                                    <button type="submit" class="btn btn-submit">Save Changes</button>
                                </div>
                            </form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "<?php echo e(Js::from(session('success'))); ?>",
        timer: 2000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/setting.blade.php ENDPATH**/ ?>