<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Stock Transfer Status Update</title>
</head>
<body>
    <h2>Stock Transfer Status Updated</h2>

    <p><strong>Reference No:</strong> <?php echo e($transfer->reference_no); ?></p>
    <p><strong>Status:</strong> <?php echo e($statusText); ?></p>
    <p><strong>From Store:</strong> <?php echo e($storeFrom->name ?? 'N/A'); ?></p>
    <p><strong>To Store:</strong> <?php echo e($storeTo->name ?? 'N/A'); ?></p>
    <p><strong>Arrival Date:</strong> <?php echo e($transfer->arrival_date); ?></p>

    <h3>Transferred Products</h3>
    <ul>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->product_name); ?> — Qty: <?php echo e($item->qty); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <p>Thank you.</p>
</body>
</html>
<?php /**PATH /var/www/stockmgnt/resources/views/emails/stock_transfer_status_notification.blade.php ENDPATH**/ ?>