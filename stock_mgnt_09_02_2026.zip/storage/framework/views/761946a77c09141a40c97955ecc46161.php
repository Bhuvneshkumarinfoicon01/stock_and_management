 <?php $__env->startSection('title'); ?> Dashbaord <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Balance Sheet</h4>
                </div>
            </div>
            <ul class="table-top-head">
               
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Excel"
                        href="#"
                        id="export-balance-sheet"
                    >
                        <img src="https://dreamspos.dreamstechnologies.com/html/template/assets/img/icons/excel.svg" alt="img"/>
                    </a>
                </li>
                
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Refresh"
                        id="refresh-page"
                        ><i
                            data-feather="rotate-ccw"
                            class="feather-rotate-ccw"
                        ></i
                    ></a>
                </li>
                <li>
                    <a
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        title="Collapse"
                        id="collapse-header"
                        ><i
                            data-feather="chevron-up"
                            class="feather-chevron-up"
                        ></i
                    ></a>
                </li>
            </ul>
        </div>

        <div class="card table-list-card border-0 mb-0">
            <div class="card-body mb-3">
                <div class="table-top mb-0 profit-table-top">
                    <div class="search-path profit-head">
                        <label class="form-label mb-0">From Date</label>
                        <div class="input-blocks mb-0">
                            <i data-feather="calendar" class="info-img"></i>
                            <div class="input-groupicon">
                                <input
                                    type="text"
                                    id="from_date"
                                    class="datetimepicker"
                                    placeholder="From Date"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="position-relative daterange-wraper input-blocks mb-0">
                        <label class="form-label mb-0">To Date</label>
                        <div class="input-blocks mb-0">
                            <i data-feather="calendar" class="info-img"></i>
                            <div class="input-groupicon">
                                <input
                                    type="text"
                                    id="to_date"
                                    class="datetimepicker"
                                    placeholder="To Date"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="position-relative daterange-wraper input-blocks mb-0">
                        <label class="form-label mb-0">Select Store</label>
                        <div class="input-blocks mb-0 me-2">
                            <select id="store_id" class="select">
                                <option value="">Choose Store</option>
                                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($store->id); ?>"><?php echo e($store->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                   
                    <div class="date-btn">
                        <a
                            href="javascript:void(0);"
                            class="btn btn-secondary d-flex align-items-center"
                            id="display-profit-loss"
                        >
                            <i
                                data-feather="database"
                                class="feather-14 info-img me-2"
                            ></i
                            >Display Data</a
                        >
                    </div>
                </div>
            </div>
        </div>

        <div class="balance-sheet">
            <div class="table-responsive">
                <table class="table balance-sheet datanew">
                    <thead>
                        <tr>
                            <th>Asset Description</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody id="sales-tbody">
                        <tr>
                            <td id="cash">Cash</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td id="digital">Digital</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td id="stock">Inventory (Stocks)</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td id="total_sales">Total Sales</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td id="total_asset"><strong>Total Assets</strong></td>
                            <td><strong></strong></td>
                        </tr>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    


        $("#display-profit-loss").on("click", function () {
            const fromDate = $("#from_date").val();
            const toDate = $("#to_date").val();
            const storeId = $("#store_id").val();

            if (!fromDate || !toDate) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Missing Dates',
                    text: 'Please select both the Dates.',
                    confirmButtonText: 'OK'
                });
                return;
            }

        
        $.ajax({
            url: "<?php echo e(route('admin.balance-sheet-data')); ?>",
            method: "GET",
            data: {
                store_id: storeId,
                start_date: fromDate,
                end_date: toDate,
            },
            success: function (res) {
                
                $("#cash").next().text(`$${res.cash.toLocaleString()}`);
                $("#digital").next().text(`$${res.digital.toLocaleString()}`);
                $("#stock").next().text(`$${res.stock.toLocaleString()}`);
                $("#total_sales").next().text(`$${res.total_sales.toLocaleString()}`);

                const totalAssets = res.cash + res.digital + res.stock;
                $("#total_asset").next().html(`<strong>$${totalAssets.toLocaleString()}</strong>`);
            },

            error: function () {
                
            }
        });
    });

    $("#export-balance-sheet").on("click", function (e) {
        e.preventDefault();
        const fromDate = $("#from_date").val();
        const toDate = $("#to_date").val();
        const storeId = $("#store_id").val();

        if (!fromDate || !toDate) {
            Swal.fire({
                icon: 'warning',
                title: 'Missing Dates',
                text: 'Please select both the Dates.',
                confirmButtonText: 'OK'
            });
            return;
        }

        // Build the export URL with query parameters
        const url = `<?php echo e(route('admin.balance-sheet.export')); ?>?store_id=${encodeURIComponent(storeId)}&start_date=${encodeURIComponent(fromDate)}&end_date=${encodeURIComponent(toDate)}`;
        window.location.href = url;
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stockmgnt/resources/views/admin/balance-sheet.blade.php ENDPATH**/ ?>