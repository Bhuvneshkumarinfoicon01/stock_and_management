<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Dashboard</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="subdrop"><i
                                    data-feather="grid"></i><span>Dashboard</span></a>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Store</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.stores_communication')); ?>"><i
                                    data-feather="plus-square"></i><span>Communication</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.daily-operations-overview-admin')); ?>"><i data-feather="plus-square"></i><span>Daily operation overview</span></a>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Store Operations</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.stock.list')); ?>"><i data-feather="box"></i><span>All
                                    Stock</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.stock.create')); ?>"><i data-feather="plus-square"></i><span>Add
                                    Stock</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.stocktransfers.index')); ?>"><i data-feather="truck"></i><span>Stock
                                    transfers</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.stock-adjustment')); ?>"><i data-feather="clipboard"></i><span>Stock
                                    Adjustment</span></a>
                        </li>
                        <!-- <li>
                            <a href=""
                                ><i data-feather="package"></i
                                ><span>Discrepencies</span></a
                            >
                        </li>
                        <li>
                            <a href=""
                                ><i data-feather="plus-square"></i
                                ><span>Communication</span></a
                            >
                        </li> -->
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Financial Oversight</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.profit-loss-statement')); ?>"><i
                                    data-feather="pie-chart"></i><span>Profit & Loss</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.balance-sheet')); ?>"><i data-feather="plus-square"></i><span>Balance
                                    Sheet</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.invoice')); ?>"><i data-feather="file"></i><span>Invoice</span></a>
                        </li>
                    </ul>
                </li>
                <!-- <li class="submenu-open">
							<h6 class="submenu-hdr">Inventory</h6>
							<ul>
								<li><a href="stock-list.php"><i data-feather="box"></i><span>All Stock</span></a></li>
								<li><a href="add-stock.php"><i data-feather="plus-square"></i><span>Add Stock</span></a></li>
								<li><a href="stock-transfer.php"><i data-feather="truck"></i><span>Stock transfers</span></a></li>
								<li><a href="stock-adjustment.php"><i data-feather="clipboard"></i><span>Stock Adjustment</span></a></li>
								<li><a href="manage-stocks.php"><i data-feather="package"></i><span>Discrepencies</span></a></li>
							</ul>
						</li> -->

                <li class="submenu-open">
                    <h6 class="submenu-hdr">Staff Management</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.users')); ?>"><i data-feather="user"></i><span>Employees</span></a>
                        </li>
                        <li><a href="<?php echo e(route('admin.store-employee')); ?>"><i data-feather="user"></i><span>Store
                                    Employees</span></a></li>
                    </ul>
                </li>
                <!-- <li class="submenu-open">
							<h6 class="submenu-hdr">Promotion</h6>
							<ul>
								<li><a href="Promotion.php"><i data-feather="save"></i><span>Add Promotion</span></a></li>
								<li><a href="view-promotion.php"><i data-feather="eye"></i><span>View Promotion</span></a></li>
							</ul>
						</li> -->
                <!-- <li class="submenu-open">
                    <h6 class="submenu-hdr">Ledger</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.ledger')); ?>"
                                ><i data-feather="columns"></i
                                ><span>View / Add Ledger</span></a
                            >
                        </li>
                    </ul>
                </li> -->
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Point of Sale</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.pos-terminal')); ?>"><i data-feather="hard-drive"></i><span>Configure
                                    POS Terminals</span></a>
                        </li>
                        <li><a href="<?php echo e(route('admin.invoice')); ?>"><i data-feather="trending-down"></i><span>Invoice
                                    Management</span></a></li>
                        <li>
                            <a href="<?php echo e(route('admin.transaction-manage')); ?>"><i
                                    data-feather="refresh-ccw"></i><span>Transaction Management</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.pos-sale-insight')); ?>"><i
                                    data-feather="shopping-cart"></i><span>Sales Insights</span></a>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Reports</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.sales-trend')); ?>"><i data-feather="bar-chart-2"></i><span>Sales
                                    trends</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.inventory-flow-admin')); ?>"><i
                                    data-feather="refresh-cw"></i><span>Inventory flow</span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.top-performing-product')); ?>"><i data-feather="bar-chart"></i><span>Top-performing products</span></a>
                        </li>
                    </ul>
                </li>
                <li class="submenu-open">
                    <h6 class="submenu-hdr">Setting</h6>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.setting')); ?>"><i data-feather="monitor"></i><span>Settings</span></a>
                        </li>
                        <!-- <li>
                            <a href="#"
                                ><i data-feather="hexagon"></i
                                ><span>Audit Logs</span></a
                            >
                        </li> -->
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH C:\xampp\htdocs\stockmgnt\resources\views/partials/admin/sidebar_admin.blade.php ENDPATH**/ ?>