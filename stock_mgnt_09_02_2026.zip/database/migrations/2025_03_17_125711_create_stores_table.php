<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stores', function (Blueprint $table) {
            $table->id();            
            $table->string('name');
            $table->string('address');
            $table->string('city');  
            $table->string('state');
            $table->string('zipcode');
            $table->string('phone'); 
            $table->string('email');   
            $table->tinyInteger('status')->default(1)->unsigned();   
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stores');
    }
};
