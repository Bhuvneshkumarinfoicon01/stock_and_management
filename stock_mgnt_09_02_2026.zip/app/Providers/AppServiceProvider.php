<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\Store;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        View::composer('*', function ($view) {
            $stores = Store::all();  // Fetch all stores
            $view->with('stores', $stores);
        });
        View::composer('*', function ($view) {
            $categories = Category::all();  // Fetch all stores
            $view->with('categories', $categories);
        });
        View::composer('*', function ($view) {
            $user = auth()->user();
            $view->with('user', $user);
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Paginator::useBootstrapFive();
    }
}
