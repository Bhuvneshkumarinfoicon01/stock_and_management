<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProfitLossController extends Controller
{
    public function getMonthlySales(Request $request)
    {
        $storeId = $request->store_id;

        $startDate = Carbon::parse($request->start_date)->startOfMonth();
        $endDate = Carbon::parse($request->end_date)->endOfMonth();

        $salesData = DB::table('orders')
            ->select(
                DB::raw("DATE_FORMAT(created_at, '%b %Y') as month"),
                DB::raw('SUM(total_price) as total_sales')
            )
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($storeId, function ($query) use ($storeId) {
                $query->where('store_id', $storeId);
            })
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(created_at)'))
            ->get();
        $adjustmentData = DB::table('stock_adjustments as sa')
            ->join('stocks as s', function ($join) {
                $join
                    ->on('sa.product_id', '=', 's.product_id')
                    ->on('sa.store_id', '=', 's.store_id');
            })
            ->select(
                DB::raw("DATE_FORMAT(sa.adjust_date, '%b %Y') as month"),
                DB::raw('SUM(s.price * sa.adjust_quantity) as adjustment_value')
            )
            ->whereBetween('sa.adjust_date', [$startDate, $endDate])
            ->when($storeId, function ($query) use ($storeId) {
                $query->where('sa.store_id', $storeId);
            })
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(sa.adjust_date)'))
            ->get();
        $incomingTransfers = DB::table('stock_transfers as st')
            ->join('stock_transfer_items as si', 'st.reference_no', '=', 'si.reference_no')
            ->join('stocks as s', function ($join) {
                $join
                    ->on('si.product_id', '=', 's.product_id')
                    ->on('st.store_to', '=', 's.store_id');
            })
            ->select(
                DB::raw("DATE_FORMAT(st.arrival_date, '%b %Y') as month"),
                DB::raw('SUM(si.qty * s.price) as incoming_value')
            )
            ->where('si.status', 1)  // Accepted only
            ->whereBetween('st.arrival_date', [$startDate, $endDate])
            ->when($storeId, fn($q) => $q->where('st.store_to', $storeId))
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(st.arrival_date)'))
            ->get();

        // Outgoing Transfers
        $outgoingTransfers = DB::table('stock_transfers as st')
            ->join('stock_transfer_items as si', 'st.reference_no', '=', 'si.reference_no')
            ->join('stocks as s', function ($join) {
                $join
                    ->on('si.product_id', '=', 's.product_id')
                    ->on('st.store_from', '=', 's.store_id');
            })
            ->select(
                DB::raw("DATE_FORMAT(st.arrival_date, '%b %Y') as month"),
                DB::raw('SUM(si.qty * s.price) as outgoing_value')
            )
            ->where('si.status', 1)  // Accepted only
            ->whereBetween('st.arrival_date', [$startDate, $endDate])
            ->when($storeId, fn($q) => $q->where('st.store_from', $storeId))
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(st.arrival_date)'))
            ->get();

        $stocks = DB::table('stocks')
            ->select(
                DB::raw("DATE_FORMAT(created_at, '%b %Y') as month"),
                DB::raw('SUM(price*quantity) as stock_value')
            )
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($storeId, function ($query) use ($storeId) {
                $query->where('store_id', $storeId);
            })
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(created_at)'))
            ->get();

        $months = collect($salesData)->pluck('month')->merge(
            collect($adjustmentData)->pluck('month')
        )->unique()->sort();

        $netProfit = $months->map(function ($month) use ($salesData, $adjustmentData) {
            $sales = $salesData->firstWhere('month', $month)?->total_sales ?? 0;
            $adjustments = $adjustmentData->firstWhere('month', $month)?->adjustment_value ?? 0;

            return [
                'month' => $month,
                'net_profit' => $sales - $adjustments
            ];
        })->values();
        return response()->json([
            'sales' => $salesData,
            'adjustments' => $adjustmentData,
            'incoming' => $incomingTransfers,
            'outgoing' => $outgoingTransfers,
            'stocks' => $stocks,
            'net_profit' => $netProfit
        ]);
    }

    public function exportMonthlyProfitLoss(Request $request)
    {
        $storeId = $request->store_id;
        $storeName = 'All Stores';

        if ($storeId) {
            $store = DB::table('stores')->where('id', $storeId)->first();
            $storeName = $store ? $store->name : 'Unknown Store';
        }

        $startDate = Carbon::parse($request->start_date)->startOfMonth();
        $endDate = Carbon::parse($request->end_date)->endOfMonth();

        // Sales
        $salesData = DB::table('orders')
            ->select(DB::raw("DATE_FORMAT(created_at, '%b %Y') as month"), DB::raw('SUM(total_price) as total_sales'))
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($storeId, fn($q) => $q->where('store_id', $storeId))
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(created_at)'))
            ->get();

        // Adjustments
        $adjustments = DB::table('stock_adjustments as sa')
            ->join('stocks as s', fn($join) => $join
                ->on('sa.product_id', '=', 's.product_id')
                ->on('sa.store_id', '=', 's.store_id'))
            ->select(DB::raw("DATE_FORMAT(sa.adjust_date, '%b %Y') as month"), DB::raw('SUM(s.price * sa.adjust_quantity) as adjustment_value'))
            ->whereBetween('sa.adjust_date', [$startDate, $endDate])
            ->when($storeId, fn($q) => $q->where('sa.store_id', $storeId))
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(sa.adjust_date)'))
            ->get();

        // Incoming Transfers
        $incomingTransfers = DB::table('stock_transfers as st')
            ->join('stock_transfer_items as si', 'st.reference_no', '=', 'si.reference_no')
            ->join('stocks as s', function ($join) {
                $join
                    ->on('si.product_id', '=', 's.product_id')
                    ->on('st.store_to', '=', 's.store_id');
            })
            ->select(
                DB::raw("DATE_FORMAT(st.arrival_date, '%b %Y') as month"),
                DB::raw('SUM(si.qty * s.price) as incoming_value')
            )
            ->where('si.status', 1)
            ->whereBetween('st.arrival_date', [$startDate, $endDate])
            ->when($storeId, fn($q) => $q->where('st.store_to', $storeId))
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(st.arrival_date)'))
            ->get();

        // Outgoing Transfers
        $outgoingTransfers = DB::table('stock_transfers as st')
            ->join('stock_transfer_items as si', 'st.reference_no', '=', 'si.reference_no')
            ->join('stocks as s', function ($join) {
                $join
                    ->on('si.product_id', '=', 's.product_id')
                    ->on('st.store_from', '=', 's.store_id');
            })
            ->select(
                DB::raw("DATE_FORMAT(st.arrival_date, '%b %Y') as month"),
                DB::raw('SUM(si.qty * s.price) as outgoing_value')
            )
            ->where('si.status', 1)
            ->whereBetween('st.arrival_date', [$startDate, $endDate])
            ->when($storeId, fn($q) => $q->where('st.store_from', $storeId))
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(st.arrival_date)'))
            ->get();

        // Stocks Value
        $stocks = DB::table('stocks')
            ->select(
                DB::raw("DATE_FORMAT(created_at, '%b %Y') as month"),
                DB::raw('SUM(price*quantity) as stock_value')
            )
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($storeId, function ($query) use ($storeId) {
                $query->where('store_id', $storeId);
            })
            ->groupBy('month')
            ->orderBy(DB::raw('MIN(created_at)'))
            ->get();

        // Collect all months
        $months = collect($salesData)
            ->pluck('month')
            ->merge(collect($adjustments)->pluck('month'))
            ->merge(collect($incomingTransfers)->pluck('month'))
            ->merge(collect($outgoingTransfers)->pluck('month'))
            ->merge(collect($stocks)->pluck('month'))
            ->unique()
            ->sort();

        // Prepare rows
        $rows = [];
        foreach ($months as $month) {
            $sales = $salesData->firstWhere('month', $month)?->total_sales ?? 0;
            $adj = $adjustments->firstWhere('month', $month)?->adjustment_value ?? 0;
            $incoming = $incomingTransfers->firstWhere('month', $month)?->incoming_value ?? 0;
            $outgoing = $outgoingTransfers->firstWhere('month', $month)?->outgoing_value ?? 0;
            $stockValue = $stocks->firstWhere('month', $month)?->stock_value ?? 0;
            $net = $sales - $adj;

            $rows[] = [
                $month,
                $storeName,
                number_format($sales, 2),
                number_format($adj, 2),
                number_format($incoming, 2),
                number_format($outgoing, 2),
                number_format($stockValue, 2),
                number_format($net, 2),
            ];
        }

        // CSV headers
        $filename = 'profit_loss_' . now()->format('Ymd_His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $columns = [
            'Month',
            'Store',
            'Total Sales',
            'Adjustment Value',
            'Incoming Stocks',
            'Outgoing Stocks',
            'Stocks Value',
            'Net Profit',
        ];

        // CSV callback
        $callback = function () use ($columns, $rows) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
            foreach ($rows as $row) {
                fputcsv($file, $row);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
