<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Stock;
use App\Models\Store;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function index(Request $request)
    {
        $customers = Customer::get();
        $discount_percentage = User::where('role_id', 5)->value('max_discount');
        if ($request->ajax()) {
            $query = Order::with('orderItems')->where('type', 'offline');

            if ($request->has('store') && $request->store !== 'choose') {
                $query->where('store_id', $request->store);
            }
            if ($request->filled('date_from') && $request->filled('date_to')) {
                $query->whereBetween('created_at', [
                    Carbon::parse($request->date_from)->startOfDay(),
                    Carbon::parse($request->date_to)->endOfDay()
                ]);
            }
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }
            return datatables()
                ->eloquent($query)
                ->addColumn('order_id', fn($row) => $row->id)
                ->addColumn('store_name', fn($row) => $row->store->name)
                ->addColumn('created_at', fn($row) => $row->created_at->format('d M Y'))
                ->addColumn('total_price', fn($row) => '$' . $row->total_price)
                ->addColumn('paid_price', fn($row) => '$' . $row->total_price)
                ->addColumn('due', fn($row) => '$0.00')
                ->addColumn('payment_status', function ($order) {
                    if ($order->status == 0) {
                        return '<span class="badge badge-linedanger">Unpaid</span>';
                    } else {
                        return '<span class="badge badge-linesuccess">Paid</span>';
                    }
                })
                ->addColumn('actions', function ($order) {
                    $actions = '
        <div class="edit-delete-action">
            <a class="me-2 p-2 print-receipt"
                href="javascript:void(0);"
                data-bs-toggle="modal"
                data-bs-target="#print-receipt"
                data-id="' . $order->id . '"
                data-customer="' . $order->customer_name . '"
                data-customerid="' . $order->customer_id . '"
                data-date="' . $order->created_at->format('d M Y') . '"
                data-total="$' . $order->total_price . '"
                data-invoice="INV/' . $order->id . '"
            >
                <i data-feather="printer" class="feather-edit"></i>
            </a>
    ';

                    if (hasPermission('update', 'order')) {
                        $actions .= '
            <a class="me-2 p-2 edit-order"
                href="javascript:void(0);"
                data-id="' . $order->id . '"
            >
                <i data-feather="edit" class="feather-edit"></i>
            </a>
        ';
                    }

                    $actions .= '</div>';

                    return $actions;
                })
                ->rawColumns(['actions', 'payment_status'])
                ->make(true);
        }

        return view('admin.invoice', compact('customers', 'discount_percentage'));
    }

    public function sales(Request $request)
    {
        $storeId = session('selected_store_id');
        if ($request->ajax()) {
            $query = Order::with(['orderItems', 'store', 'customer'])
                ->where('store_id', $storeId);
            // ->orderBy('created_at', 'desc');  // latest first
            if ($request->has('from_date') && $request->from_date) {
                $query->whereDate('created_at', '>=', \Carbon\Carbon::createFromFormat('d-m-Y', $request->from_date)->format('Y-m-d'));
            }

            if ($request->has('to_date') && $request->to_date) {
                $query->whereDate('created_at', '<=', \Carbon\Carbon::createFromFormat('d-m-Y', $request->to_date)->format('Y-m-d'));
            }
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }
            if ($search = $request->input('search.value')) {
                $query->where(function ($q) use ($search) {
                    $q
                        ->where('orders.id', 'like', "%{$search}%")
                        ->orWhereHas('store', fn($q2) => $q2->where('name', 'like', "%{$search}%"))
                        ->orWhereHas('customer', fn($q3) => $q3->where('customer_name', 'like', "%{$search}%"));
                });
            }

            $orders = $query->get();
            return datatables()
                ->eloquent($query)
                ->addColumn('order_id', fn($row) => $row->id)
                ->addColumn('date', fn($row) => \Carbon\Carbon::parse($row->created_at)->format('d-m-Y'))
                ->addColumn('store_name', fn($row) => $row->store->name)
                ->addColumn('customer_name', fn($row) => $row->customer->customer_name)
                ->addColumn('quantity', fn($row) => $row->quantity)
                ->addColumn('total_price', fn($row) => $row->total_price)
                ->addColumn('due', fn($row) => '$0.00')
                ->addColumn('status', function ($order) {
                    if ($order->status == 0) {
                        return '<span class="badge badge-linedanger">Unpaid</span>';
                    } else {
                        return '<span class="badge badge-linesuccess">Paid</span>';
                    }
                })
                ->addColumn('payment_type', fn($row) => $row->payment_method)
                ->addColumn('action', function ($order) {
                    return '
                            <a class="me-2 edit-icon p-2 viewDetails" href="#" data-id="' . $order->id . '"
                                data-bs-toggle="modal" data-bs-target="#sales-details-new">
                                <i data-feather="eye" class="feather-eye"></i>
                            </a>
                    ';
                })
                ->rawColumns(['action', 'status'])
                ->make(true);
        }

        return view('storemanager.sales');
    }

    public function viewInvoice(Request $request)  // VIEW EMPLOYEE FUNCTION
    {
        $order = Order::find($request->invoiceId);
        $store = Store::find($order->store_id);
        if ($order) {
            return response()->json([
                'success' => true,
                'data' => $order,
                'store_name' => $store->name,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Invoice not found!',
            ]);
        }
    }

    public function filter(Request $request)
    {
        $query = Order::with('store');

        if ($request->store_id) {
            $query->where('store_id', $request->store_id);
        }

        if ($request->status !== null && $request->status !== '') {
            $query->where('status', $request->status);
        }

        if ($request->date_from) {
            $query->whereDate('created_at', '>=', Carbon::createFromFormat('d-m-Y', $request->date_from)->format('Y-m-d'));
        }

        if ($request->date_to) {
            $query->whereDate('created_at', '<=', Carbon::createFromFormat('d-m-Y', $request->date_to)->format('Y-m-d'));
        }

        $orders = $query->get();
        // Render only the table rows to return
        $view = view('admin.partials.invoice_table_rows', compact('orders'))->render();

        return response()->json([
            'success' => true,
            'html' => $view
        ]);
    }

    public function showSalesDetail(Request $request)  // FOR STOREMANAGER SIDEBAR SALES TRANSACTION
    {
        $orderId = $request->invoiceId;
        $order = Order::with('orderItems', 'customer')->find($orderId);

        if (!$order) {
            return response()->json([
                'success' => false,
                'message' => 'Order not found!'
            ]);
        }

        $tax = $order->tax;  // Replace with actual tax value
        $discount = $order->discount;  // Replace with actual discount value
        $totalPrice = $order->total_price;  // You might have a method to calculate the total price

        $stocks = Stock::where('store_id', $order->store_id)
            ->whereIn('product_id', $order->orderItems->pluck('product_id'))
            ->get();

        return response()->json([
            'success' => true,
            'data' => $order,
            'stocks' => $stocks,
            'store_name' => $order->store->name
        ]);
    }

    public function customerReportIndex(Request $request)
    {
        $storeId = session('selected_store_id');
        $payment_method = config('payment_methods');
        if ($request->ajax()) {
            $query = Order::with(['customer', 'orderItems.stock'])
                ->where('store_id', $storeId);

            // Ensure the latest orders are displayed first by default
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            } else {
                // Default to descending order if no order_type is provided
                $query->orderBy('created_at', 'desc');
            }

            if ($request->method) {
                $query->where('payment_method', $request->method);
            }

            return datatables()
                ->of($query)
                ->editColumn('customer_id', fn($row) => $row->customer_id)
                ->editColumn('customer_name', fn($row) => $row->customer_name)
                ->editColumn('amount', fn($row) => '$' . $row->total_price)
                ->editColumn('paid', fn($row) => '$' . $row->total_price)
                ->editColumn('due', fn($row) => '$0.00')
                ->editColumn('status', function ($row) {
                    if ($row->status == 0) {
                        return '<span class="badge badge-linedanger">Unpaid</span>';
                    } else {
                        return '<span class="badge badge-linesuccess">Paid</span>';
                    }
                })
                ->editColumn('payment_method', fn($row) => ucfirst($row->payment_method))
                ->rawColumns(['status'])
                ->make(true);
        }

        return view('storemanager.customer-report', compact('payment_method'));
    }

    public function soldProductReportIndex(Request $request)
    {
        $storeId = session('selected_store_id');
        $payment_method = config('payment_methods');

        if ($request->ajax()) {
            $query = OrderItem::with(['order.customer', 'stock'])
                ->whereHas('order', function ($q) use ($storeId, $request) {
                    $q->where('store_id', $storeId);
                });

            // Sort dynamically based on the request 'order_type'
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);  // correct
            } else {
                $query->orderBy('created_at', 'desc');
            }

            // Return the DataTable with the queried data
            return datatables()
                ->of($query)
                ->addColumn('sold_amount', fn($row) => '$' . number_format($row->price * $row->qty, 2))
                ->addColumn('sold_qty', fn($row) => $row->qty ?? '-')
                ->addColumn('instock_qty', fn($row) => $row->stock->quantity ?? '-')
                ->addColumn('product_info', function ($row) {
                    $stock = $row->stock;
                    $imagePath = $stock && $stock->images
                        ? asset('storage/' . $stock->images)
                        : asset('admin/assets/img/avatar/default-product.png');

                    $productName = $stock->product_name ?? '-';

                    return '
                    <div class="productimgname d-flex align-items-center mb-1">
                        <div class="view-product me-2">
                            <a href="javascript:void(0);">
                                <img src="' . $imagePath . '" alt="product" width="40">
                            </a>
                        </div>
                        <a href="javascript:void(0);">' . htmlspecialchars($productName) . '</a>
                    </div>
                ';
                })
                ->rawColumns(['product_info'])
                ->make(true);
        }
    }

    public function exportCsv(Request $request)
    {
        $query = Order::query();

        // Filter only 'offline' orders
        $query->where('type', 'offline');

        if ($request->has('store') && $request->store !== 'choose') {
            $query->where('store_id', $request->store);
        }

        if ($request->filled('date_from') && $request->filled('date_to')) {
            $query->whereBetween('created_at', [
                Carbon::parse($request->date_from)->startOfDay(),
                Carbon::parse($request->date_to)->endOfDay()
            ]);
        }

        $orders = $query->with('store')->get();

        $filename = 'orders_' . now()->format('Ymd_His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $columns = [
            'Order ID',
            // 'Type',
            'Store Name',
            'Date',
            'Total Price',
        ];

        $callback = function () use ($orders, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($orders as $order) {
                fputcsv($file, [
                    $order->id,
                    // $order->type,
                    $order->store ? $order->store->name : '',
                    $order->created_at ? $order->created_at->format('Y-m-d') : '',
                    $order->total_price,
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    public function getProductsByStore(Request $request)
    {
        $storeId = $request->store_id;
        $query = $request->input('query', '');

        if (!$storeId) {
            return response()->json(['error' => 'Store ID is required!'], 400);
        }

        try {
            $products = DB::table('stocks')
                ->where('stocks.store_id', $storeId)
                ->when($query, function ($q) use ($query) {
                    $q->where(function ($subQ) use ($query) {
                        $subQ
                            ->where('stocks.product_name', 'LIKE', "%{$query}%")
                            ->orWhere('stocks.sku', 'LIKE', "%{$query}%");
                    });
                })
                ->join('categories', 'stocks.category_id', '=', 'categories.id')
                ->selectRaw('
                stocks.id,
                stocks.product_id,
                stocks.product_name,
                stocks.sku,
                stocks.price,
                stocks.category_id,
                categories.name as category_name,
                SUM(stocks.quantity) as total_quantity
                
            ')
                ->groupBy('stocks.id', 'stocks.product_name', 'stocks.sku', 'stocks.price', 'stocks.category_id', 'categories.name', 'stocks.product_id')
                ->orderBy('stocks.product_name')  // Alphabetical order
                ->get();

            return response()->json($products);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch products!'], 500);
        }
    }

    public function editInvoice(Request $request)
    {
        $id = $request->id;
        $order = Order::with('orderItems')->find($id);

        if (!$order) {
            return response()->json(['success' => false]);
        }

        $items = [];

        foreach ($order->orderItems as $item) {
            $stock = Stock::where('store_id', $order->store_id)
                ->where('product_id', $item->product_id)
                ->first();

            $itemData = $item->toArray();  // Convert to array
            $itemData['available_qty'] = $stock ? $stock->quantity : 0;
            $itemData['category_name'] = $stock && $stock->category ? $stock->category->name : null;

            $items[] = $itemData;
        }

        $orderData = $order->toArray();  // Convert order
        $orderData['order_items'] = $items;  // Override with updated array

        return response()->json([
            'success' => true,
            'data' => $orderData,
        ]);
    }
}
