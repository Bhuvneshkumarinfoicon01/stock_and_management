<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BalanceSheetController extends Controller
{
    public function getBalanceSheetData(Request $request)
    {
        $storeId = $request->store_id;
        $startDate = Carbon::createFromFormat('d-m-Y', $request->start_date)->startOfDay();
        $endDate = Carbon::createFromFormat('d-m-Y', $request->end_date)->endOfDay();

        $cashQuery = DB::table('orders')
            ->where('payment_method', 'cash')
            ->whereBetween('created_at', [$startDate, $endDate]);

        $digitalQuery = DB::table('orders')
            ->whereIn('payment_method', ['debit card', 'scan'])
            ->whereBetween('created_at', [$startDate, $endDate]);

        $stockQuery = DB::table('stocks')
            ->whereBetween('updated_at', [$startDate, $endDate]);

        $salesQuery = DB::table('orders')
            ->whereBetween('created_at', [$startDate, $endDate]);

        if ($storeId) {
            $cashQuery->where('store_id', $storeId);
            $digitalQuery->where('store_id', $storeId);
            $stockQuery->where('store_id', $storeId);
            $salesQuery->where('store_id', $storeId);
        }

        $cash = $cashQuery->sum('total_price');
        $digital = $digitalQuery->sum('total_price');
        $stock = $stockQuery->select(DB::raw('SUM(price * quantity) as total_stock_value'))->value('total_stock_value');
        $totalSales = $salesQuery->sum('total_price');

        return response()->json([
            'cash' => $cash,
            'digital' => $digital,
            'stock' => $stock,
            'total_sales' => $totalSales,
        ]);
    }

    public function exportBalanceSheet(Request $request)
    {
        $storeId = $request->store_id;
        $startDate = Carbon::createFromFormat('d-m-Y', $request->start_date)->startOfDay();
        $endDate = Carbon::createFromFormat('d-m-Y', $request->end_date)->endOfDay();

        $cashQuery = DB::table('orders')
            ->where('payment_method', 'cash')
            ->whereBetween('created_at', [$startDate, $endDate]);

        $digitalQuery = DB::table('orders')
            ->whereIn('payment_method', ['debit card', 'scan'])
            ->whereBetween('created_at', [$startDate, $endDate]);

        $stockQuery = DB::table('stocks')
            ->whereBetween('updated_at', [$startDate, $endDate]);

        $salesQuery = DB::table('orders')
            ->whereBetween('created_at', [$startDate, $endDate]);

        if ($storeId) {
            $cashQuery->where('store_id', $storeId);
            $digitalQuery->where('store_id', $storeId);
            $stockQuery->where('store_id', $storeId);
            $salesQuery->where('store_id', $storeId);
        }

        $cash = $cashQuery->sum('total_price');
        $digital = $digitalQuery->sum('total_price');
        $stock = $stockQuery->select(DB::raw('SUM(price * quantity) as total_stock_value'))->value('total_stock_value');
        $totalSales = $salesQuery->sum('total_price');
        $totalAssets = $cash + $digital + $stock;

        $storeName = 'All Stores';
        if ($storeId) {
            $store = DB::table('stores')->where('id', $storeId)->first();
            $storeName = $store ? $store->name : 'Unknown Store';
        }

        $filename = 'balance_sheet_' . now()->format('Ymd_His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $columns = [
            'Store',
            'Start Date',
            'End Date',
            'Cash Sales',
            'Digital Sales',
            'Stock Value',
            'Total Sales',
            'Total Assets',
        ];

        // Use ISO date format for Excel compatibility, and raw numbers for currency columns
        $row = [
            $storeName,
            $startDate->format('Y-m-d'),  // ISO format
            $endDate->format('Y-m-d'),  // ISO format
            $cash,  // raw number, Excel will treat as currency if column formatted
            $digital,
            $stock,
            $totalSales,
            $totalAssets,
        ];

        $callback = function () use ($columns, $row) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
            fputcsv($file, $row);
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
