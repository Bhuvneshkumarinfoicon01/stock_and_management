<?php

namespace App\Http\Controllers\admin;

use App\Helpers\NotificationHelper;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Stock;
use App\Models\Store;
use App\Models\Unit;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class StockController extends Controller
{
    public function index(Request $request)
    {
        $units = Unit::all();
        $categories = Category::all();
        $stores = Store::all();

        if ($request->ajax()) {
            $query = Stock::with(['store', 'category', 'unit']);

            $user = auth()->user();
            $sessionStoreId = session('selected_store_id');

            if (in_array($user->role_id, [1, 2, 3, 5])) {
                if ($request->has('store') && $request->store === 'all') {
                } elseif ($sessionStoreId) {
                    $query->where('store_id', $sessionStoreId);
                }
            }

            if ($request->has('category') && $request->category !== 'choose') {
                $query->where('category_id', $request->category);
            }

            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }

            $stocks = $query->get();
            return datatables()
                ->of($stocks)
                ->addColumn('store_name', fn($row) => $row->store->name)
                ->addColumn('product', function ($row) {
                    $imagePath = $row->images;  // value from DB
                    $image = asset('admin/assets/img/avatar/default-product.png');  // default

                    if (
                        $imagePath &&  // not null / not empty
                        Str::startsWith($imagePath, 'products/') &&  // real upload, not pending
                        Storage::disk('public')->exists($imagePath)  // file is present
                    ) {
                        $image = asset('storage/' . $imagePath);  // serve the real image
                    }

                    return '
        <div class="productimgname">
            <a href="javascript:void(0);" class="product-img stock-img">
                <img src="' . $image . '" alt="' . e($row->product_name) . '" />
            </a>
            <a href="javascript:void(0);">' . e($row->product_name) . '</a>
        </div>';
                })
                ->addColumn('sku', fn($row) => $row->sku)
                ->addColumn('category', fn($row) => $row->category->name)
                ->addColumn('price', fn($row) => $row->price)
                ->addColumn('unit', fn($row) => $row->unit->name)
                ->addColumn('quantity', fn($row) => $row->quantity)
                ->addColumn('actions', function ($stock) {
                    $user = auth()->user();
                    if (!$user)
                        return '';

                    $editBtn = '';
                    $deleteBtn = '';

                    if (hasPermission('update', 'stock')) {
                        $editUrl = route('admin.stock.edit', $stock->id);
                        $editBtn = '
            <a class="p-2" href="' . $editUrl . '">
                <i data-feather="edit" class="feather-edit"></i>
            </a>
        ';
                    }

                    if (hasPermission('delete', 'stock')) {
                        $deleteBtn = '
            <a href="javascript:void(0);" class="delete-stock confirm-text p-2" data-id="' . $stock->id . '">
                <i data-feather="trash-2" class="feather-trash-2"></i>
            </a>
        ';
                    }

                    if ($editBtn || $deleteBtn) {
                        return '<div class="edit-delete-action">' . $editBtn . $deleteBtn . '</div>';
                    }

                    return '';
                })
                ->rawColumns(['product', 'actions'])
                ->make(true);
        }

        return view('admin.stock-list', compact('categories', 'stores', 'units'));
    }

    public function create()
    {
        $categories = Category::get();
        $units = Unit::all();
        // $stock_last_insert_id = Stock::latest()->value('id');
        // Get the last inserted Stock ID
        $lastStock = Stock::orderBy('id', 'desc')->first();
        $lastId = $lastStock ? $lastStock->id : 0;

        // Generate formatted stock ID with "p_" prefix and zero-padding (e.g., p_001, p_002)
        $stock_last_insert_id = 'P_' . str_pad($lastId + 1, 3, '0', STR_PAD_LEFT);

        return view('admin.add-stock', compact('categories', 'units', 'stock_last_insert_id'));
    }

    public function store(Request $request)
    {
        if (!hasPermission('create', 'stock')) {
            return view('admin.partials.authorisation');
        }
        $product_id = $request->product_id ?? ('P_' . str_pad(Stock::count() + 1, 3, '0', STR_PAD_LEFT));

        $request->validate([
            'store_id' => 'required|exists:stores,id',
            'product_id' => 'required|string|unique:stocks,product_id,NULL,id,store_id,' . $request->store_id,
            'product_name' => 'required|string|max:255',
            'sku' => 'required|string|unique:stocks,sku',
            'category_id' => 'required|exists:categories,id',
            'unit_id' => 'required|exists:units,id',
            'supplier_name' => 'nullable|string',
            'purchase_date' => 'required|date_format:d-m-Y',
            'qty' => 'required|integer|min:1|max:999999999',
            'price' => 'required|numeric|min:0',
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'manufactured_date' => 'nullable|date',
            'expiry_on' => 'nullable|date|after:manufactured_date',
        ], [
            'qty.max' => 'Quantity limit exceed (max qty:999999999)'
        ]);

        $imagePath = $request->hasFile('image')
            ? $request->file('image')->store('products', 'public')
            : null;

        $stock = Stock::create([
            'store_id' => $request->store_id,
            'unit_id' => $request->unit_id,
            'product_id' => $product_id,
            'product_name' => $request->product_name,
            'sku' => $request->sku,
            'category_id' => $request->category_id,
            'supplier_name' => $request->supplier_name,
            'purchase_date' => Carbon::createFromFormat('d-m-Y', $request->purchase_date)->format('Y-m-d'),
            'description' => $request->description,
            'quantity' => $request->qty,
            'price' => $request->price,
            'discount' => $request->discount,
            'tax' => $request->tax,
            'manufactured_date' => $request->manufactured_date ? Carbon::createFromFormat('d-m-Y', $request->manufactured_date)->format('Y-m-d') : null,
            'expiry_date' => $request->expiry_on ? Carbon::createFromFormat('d-m-Y', $request->expiry_on)->format('Y-m-d') : null,
            'images' => $imagePath
        ]);

        storeHistory(
            'stock_form',
            'created',
            'stock',
            $stock->id,
            $stock->toArray(),  // new values
            null  // no old values on creation
        );

        $userId = auth()->id();
        $storeName = \App\Models\Store::find($request->store_id)?->name;
        $message = 'New Stock has been added to store (' . $storeName . ')';
        NotificationHelper::add($userId, $message);
        NotificationHelper::pushRealtime($userId, $message);

        return redirect()->back()->with('success', 'Stock added successfully!');
    }

    public function edit(Stock $stock)
    {
        $categories = Category::all();
        $stores = Store::all();
        $units = Unit::all();
        return view('admin.add-stock', compact('stock', 'categories', 'stores', 'units'));
    }

    // public function update(Request $request, $id)
    // {
    //     // dd($request->all());
    //     $stock = Stock::findOrFail($id);
    //     if ($request->remove_image == '1') {
    //         if ($stock->images) {
    //             Storage::delete('public/' . $stock->images);
    //             $imagePath = null;
    //         }
    //     } else {
    //         $imagePath = $stock->images;
    //     }

    //     if ($request->hasFile('image')) {
    //         if ($stock->images) {
    //             Storage::delete('public/' . $stock->images);
    //         }
    //         $imagePath = $request->file('image')->store('products', 'public');
    //     }

    //     $product_id = $request->product_id ?? $stock->product_id ?? ('P_' . str_pad(Stock::count() + 1, 3, '0', STR_PAD_LEFT));

    //     $request->validate([
    //         'store_id' => 'required|exists:stores,id',
    //         'unit_id' => 'required|exists:units,id',
    //         'product_id' => 'required|string|unique:stocks,product_id,' . $stock->id . ',id,store_id,' . $request->store_id,
    //         'product_name' => 'required|string|max:255',
    //         'sku' => [
    //             'required',
    //             Rule::unique('stocks')->where(function ($query) use ($request, $stock) {
    //                 return $query
    //                     ->where('store_id', $request->store_id)
    //                     ->where('sku', $request->sku)
    //                     ->where('product_id', $request->product_id);
    //             })->ignore($stock->id),
    //         ],
    //         'category_id' => 'required|exists:categories,id',
    //         'supplier_name' => 'nullable|string',
    //         'purchase_date' => 'required|date_format:d-m-Y',
    //         'description' => 'nullable|string|max:255',
    //         'qty' => 'required|integer|min:1|max:999999999',
    //         'price' => 'required|numeric|min:0',
    //         'discount' => 'nullable|numeric|min:0',
    //         'tax' => 'nullable|numeric|min:0',
    //         'manufactured_date' => 'nullable|date',
    //         'expiry_on' => 'nullable|date|after:manufactured_date',
    //         // 'image' => 'nullable|image|mimes:jpeg,png,jpg,gif'
    //     ], [
    //         'qty.max' => 'Quantity limit exceed (Max Qty: 999999999)'
    //     ]);

    //     $stock->update([
    //         'store_id' => $request->store_id,
    //         'unit_id' => $request->unit_id,
    //         'product_name' => $request->product_name,
    //         'product_id' => $product_id,
    //         'sku' => $request->sku,
    //         'category_id' => $request->category_id,
    //         'supplier_name' => $request->supplier_name,
    //         'purchase_date' => Carbon::createFromFormat('d-m-Y', $request->purchase_date)->format('Y-m-d'),
    //         'description' => $request->description,
    //         'quantity' => $request->qty,
    //         'price' => $request->price,
    //         'discount' => $request->discount ?? 0,
    //         'tax' => $request->tax ?? 0,
    //         'manufactured_date' => $request->manufactured_date ? Carbon::createFromFormat('d-m-Y', $request->manufactured_date)->format('Y-m-d') : null,
    //         'expiry_date' => $request->expiry_on ? Carbon::createFromFormat('d-m-Y', $request->expiry_on)->format('Y-m-d') : null,
    //         'images' => $imagePath
    //     ]);
    //     $userId = auth()->id();
    //     $stockName = $request->product_name;
    //     $storeName = \App\Models\Store::find($request->store_id)?->name;
    //     $message = 'Stock (' . $stockName . ') has been updated in store (' . $storeName . ')';
    //     $userName = auth()->user()->name;
    //     $port = env('NOTIFICATION_PORT');
    //     $url = "http://localhost:$port/notify";
    //     $response = Http::post($url, [
    //         'userId' => $userId,
    //         'message' => $message,
    //         'user_name' => $userName,  // Send the user's name
    //     ]);
    //     NotificationHelper::add(auth()->id(), $message);
    //     return redirect()->route('admin.stock.list')->with('success', 'Stock updated successfully!');
    // }
    public function update(Request $request, $id)
    {
        if (!hasPermission('update', 'stock')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized access.'], 403);
        }
        $stock = Stock::findOrFail($id);
        $oldData = $stock->toArray();  // 🟡 Step 1: Capture old data

        // Image logic (no change)

        if ($request->remove_image == '1') {
            if ($stock->images) {
                Storage::delete('public/' . $stock->images);
                $imagePath = null;
            }
        } else {
            $imagePath = $stock->images;
        }

        if ($request->hasFile('image')) {
            if ($stock->images) {
                Storage::delete('public/' . $stock->images);
            }
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $product_id = $request->product_id ?? $stock->product_id ?? ('P_' . str_pad(Stock::count() + 1, 3, '0', STR_PAD_LEFT));

        $request->validate([
            'store_id' => 'required|exists:stores,id',
            'unit_id' => 'required|exists:units,id',
            'product_id' => 'required|string|unique:stocks,product_id,' . $stock->id . ',id,store_id,' . $request->store_id,
            'product_name' => 'required|string|max:255',
            'sku' => [
                'required',
                Rule::unique('stocks')->where(function ($query) use ($request, $stock) {
                    return $query
                        ->where('store_id', $request->store_id)
                        ->where('sku', $request->sku)
                        ->where('product_id', $request->product_id);
                })->ignore($stock->id),
            ],
            'category_id' => 'required|exists:categories,id',
            'supplier_name' => 'nullable|string',
            'purchase_date' => 'required|date_format:d-m-Y',
            'description' => 'nullable|string|max:255',
            'qty' => 'required|integer|min:1|max:999999999',
            'price' => 'required|numeric|min:0',
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'manufactured_date' => 'nullable|date',
            'expiry_on' => 'nullable|date|after:manufactured_date',
        ], [
            'qty.max' => 'Quantity limit exceed (Max Qty: 999999999)'
        ]);

        // 🟡 Step 2: Prepare update data
        $updateData = [
            'store_id' => $request->store_id,
            'unit_id' => $request->unit_id,
            'product_name' => $request->product_name,
            'product_id' => $product_id,
            'sku' => $request->sku,
            'category_id' => $request->category_id,
            'supplier_name' => $request->supplier_name,
            'purchase_date' => Carbon::createFromFormat('d-m-Y', $request->purchase_date)->format('Y-m-d'),
            'description' => $request->description,
            'quantity' => $request->qty,
            'price' => $request->price,
            'discount' => $request->discount ?? 0,
            'tax' => $request->tax ?? 0,
            'manufactured_date' => $request->manufactured_date
                ? Carbon::createFromFormat('d-m-Y', $request->manufactured_date)->format('Y-m-d')
                : null,
            'expiry_date' => $request->expiry_on
                ? Carbon::createFromFormat('d-m-Y', $request->expiry_on)->format('Y-m-d')
                : null,
            'images' => $imagePath,
        ];

        // 🟡 Step 3: Compare differences
        $new = array_diff_assoc_recursive($updateData, $oldData);
        $old = array_diff_assoc_recursive($oldData, $updateData);

        // 🟢 Step 4: Save history only if there are changes
        if ($new || $old) {
            storeHistory(
                'stock_form',
                'updated',
                'stock',
                $stock->id,
                $new,
                $old
            );
        }

        $stock->update($updateData);

        // Notification logic
        $userId = auth()->id();
        $stockName = $request->product_name;
        $storeName = \App\Models\Store::find($request->store_id)?->name;
        $message = 'Stock (' . $stockName . ') has been updated in store (' . $storeName . ')';
        NotificationHelper::add($userId, $message);
        NotificationHelper::pushRealtime($userId, $message);

        return redirect()->route('admin.stock.list')->with('success', 'Stock updated successfully!');
    }

    // public function destroy(Request $request, $id): JsonResponse
    // {
    //     try {
    //         $stock = Stock::findOrFail($id);
    //         $productName = $stock->product_name ?? 'Unknown Product';
    //         $storeName = $stock->store?->name ?? 'Unknown Store';
    //         $message = 'Stock (' . $productName . ') has been deleted from store (' . $storeName . ')';
    //         $stock->delete();
    //         $port = env('NOTIFICATION_PORT');
    //         $url = "http://localhost:$port/notify";
    //         $response = Http::post($url, [
    //             'userId' => auth()->id(),
    //             'message' => $message,
    //             'user_name' => auth()->user()->name,  // Send the user's name
    //         ]);
    //         if ($response->failed()) {
    //             \Log::error('Notification failed: ' . $response->body());
    //         }
    //         NotificationHelper::add(auth()->id(), $message);
    //         return response()->json(['success' => true, 'message' => 'Stock deleted successfully.']);
    //     } catch (\Exception $e) {
    //         \Log::error('Failed to delete stock: ' . $e->getMessage());
    //         return response()->json(['success' => false, 'message' => 'Failed to delete stock.']);
    //     }
    // }

    public function destroy(Request $request, $id): JsonResponse
    {
        if (!hasPermission('delete', 'stock')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized access.'], 403);
        }
        try {
            $stock = Stock::findOrFail($id);
            $oldData = $stock->toArray();  // 🔍 Capture data before deletion

            $productName = $stock->product_name ?? 'Unknown Product';
            $storeName = $stock->store?->name ?? 'Unknown Store';
            $message = 'Stock (' . $productName . ') has been deleted from store (' . $storeName . ')';

            // 🔐 Store delete history
            storeHistory(
                'stock_form',
                'deleted',
                'stock',
                $stock->id,
                null,  // no new values on delete
                $oldData  // full old data before deletion
            );

            $stock->delete();

            NotificationHelper::add(auth()->id(), $message);
            NotificationHelper::pushRealtime(auth()->id(), $message);

            return response()->json(['success' => true, 'message' => 'Stock deleted successfully.']);
        } catch (\Exception $e) {
            \Log::error('Failed to delete stock: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Failed to delete stock.']);
        }
    }

    public function export()
    {
        $stocks = Stock::select(
            'stocks.product_name',
            'stocks.product_id',
            'stores.name as store_name',
            'stocks.sku',
            'categories.name as category_name',
            'units.name as unit_name',
            'stocks.supplier_name',
            'stocks.purchase_date',
            'stocks.quantity',
            'stocks.price',
            'stocks.manufactured_date',
            'stocks.expiry_date'
        )
            ->leftJoin('stores', 'stocks.store_id', '=', 'stores.id')
            ->leftJoin('categories', 'stocks.category_id', '=', 'categories.id')
            ->leftJoin('units', 'stocks.unit_id', '=', 'units.id')
            ->get();

        $filename = 'stocks_export_' . now()->format('Y-m-d_H-i-s') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $columns = [
            'Product Name',
            'Product ID',
            'Store Name',
            'SKU',
            'Category Name',
            'Unit Name',
            'Supplier Name',
            'Purchase Date',
            'Quantity',
            'Price',
            'Manufactured Date',
            'Expiry Date'
        ];

        $callback = function () use ($stocks, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($stocks as $stock) {
                fputcsv($file, [
                    $stock->product_name,
                    $stock->product_id,
                    $stock->store_name,
                    $stock->sku,
                    $stock->category_name,
                    $stock->unit_name,
                    $stock->supplier_name,
                    $stock->purchase_date,
                    $stock->quantity,
                    $stock->price,
                    $stock->manufactured_date,
                    $stock->expiry_date,
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    // public function import(Request $request)
    // {
    //     /* 1. Validate inputs */
    //     $request->validate([
    //         'csv_file' => 'required|mimes:csv,txt',
    //         'images.*' => 'nullable|file|mimes:jpg,jpeg,png,webp,bmp,gif,svg,jfif'
    //     ]);

    //     /* 2. Index uploaded images by original filename */
    //     $imageMap = [];
    //     $hasImageFolder = $request->hasFile('images');  // flag for later
    //     if ($hasImageFolder) {
    //         foreach ($request->file('images') as $img) {
    //             $imageMap[$img->getClientOriginalName()] = $img;
    //         }
    //     }

    //     /* 3. Open CSV & verify header */
    //     $file = fopen($request->file('csv_file')->getRealPath(), 'r');
    //     $header = array_map('trim', fgetcsv($file));
    //     $expected = [
    //         'Product Name', 'Product ID', 'Store Name', 'SKU', 'Category Name',
    //         'Unit Name', 'Supplier Name', 'Purchase Date', 'Quantity', 'Price',
    //         'Manufactured Date', 'Expiry Date', 'Image'
    //     ];
    //     if ($header !== $expected) {
    //         fclose($file);
    //         return back()->withErrors(['csv_file' => 'Header mismatch. Download a fresh dummy CSV.']);
    //     }

    //     /* 4. Prep helpers */
    //     $baseCount = Stock::count();
    //     $newCounter = 1;
    //     $pad = 3;
    //     $parseDate = fn($d) => $d ? Carbon::parse($d)->format('Y-m-d') : null;

    //     $rowsImported = 0;
    //     $conflicts = [];
    //     $missingImgs = [];
    //     $storeErrors = [];

    //     DB::beginTransaction();
    //     $rowNumber = 1;

    //     /* 5. Row loop */
    //     while (($row = fgetcsv($file)) !== false) {
    //         $rowNumber++;
    //         $row = array_map('trim', $row);

    //         /* Skip blank lines */
    //         if (!array_filter($row))
    //             continue;

    //         [
    //             $productName, $productIdCsv, $storeName, $sku, $categoryName,
    //             $unitName, $supplier, $purchase, $qty, $price,
    //             $mfgDate, $expDate, $imageFile
    //         ] = $row;

    //         /* Store must pre-exist (case-insensitive) */
    //         $store = Store::whereRaw('LOWER(name) = ?', [strtolower($storeName)])->first();
    //         if (!$store) {
    //             $storeErrors[] = "Row $rowNumber: store '$storeName' does not exist";
    //             continue;
    //         }

    //         /* Category & Unit */
    //         $category = Category::firstOrCreate(['name' => $categoryName]);
    //         $unit = $unitName ? Unit::firstOrCreate(['name' => $unitName]) : null;

    //         /* Duplicate-SKU check */
    //         if (Stock::where('store_id', $store->id)->where('sku', $sku)->exists()) {
    //             $conflicts[] = "Row $rowNumber: SKU '$sku' already exists in store '$storeName'";
    //             continue;
    //         }

    //         /* Product-ID */
    //         $productId = 'P_' . str_pad($baseCount + $newCounter, $pad, '0', STR_PAD_LEFT);
    //         $newCounter++;

    //         /* Image handling */
    //         $imagePath = null;
    //         if ($imageFile) {
    //             if ($hasImageFolder && isset($imageMap[$imageFile])) {
    //                 $imagePath = $imageMap[$imageFile]->storeAs('products', $imageFile, 'public');
    //             } elseif ($hasImageFolder) {
    //                 // Only warn if user actually uploaded a folder
    //                 $missingImgs[] = "Row $rowNumber: image '$imageFile' not found in uploaded folder";
    //             }
    //             // If no image folder uploaded, silently ignore
    //         }

    //         /* Insert stock */
    //         Stock::create([
    //             'store_id' => $store->id,
    //             'product_id' => $productId,
    //             'product_name' => $productName,
    //             'sku' => $sku,
    //             'category_id' => $category->id,
    //             'unit_id' => $unit?->id,
    //             'supplier_name' => $supplier,
    //             'purchase_date' => $parseDate($purchase),
    //             'manufactured_date' => $parseDate($mfgDate),
    //             'expiry_date' => $parseDate($expDate),
    //             'quantity' => is_numeric($qty) ? (int) $qty : 0,
    //             'price' => is_numeric($price) ? (float) $price : 0,
    //             'discount' => 0,
    //             'tax' => 0,
    //             'status' => 1,
    //             'images' => $imagePath,
    //         ]);

    //         $rowsImported++;
    //     }
    //     fclose($file);

    //     /* 6. Abort if any unknown store */
    //     if ($storeErrors) {
    //         DB::rollBack();
    //         return back()->with(['storeErrors' => $storeErrors]);
    //     }

    //     DB::commit();

    //     /* 7. Build flash messages */
    //     $message = "$rowsImported new stocks imported.";
    //     if ($conflicts)
    //         $message .= ' Some rows skipped (duplicate SKUs).';
    //     if ($missingImgs)
    //         $message .= ' Some images were not found.';

    //     return back()->with([
    //         'success' => $message,
    //         'conflicts' => $conflicts,
    //         'missing' => $missingImgs
    //     ]);
    // }

    public function import(Request $request)
    {
        if (!hasPermission('create', 'stock')) {
            return view('admin.partials.authorisation');
        }
        /* 1. Validate inputs */
        $request->validate([
            'csv_file' => 'required|mimes:csv,txt',
            'images.*' => 'nullable|file|mimes:jpg,jpeg,png,webp,bmp,gif,svg,jfif'
        ]);

        /* 2. Index uploaded images by original filename */
        $hasImageFolder = $request->hasFile('images');
        $imageMap = [];
        if ($hasImageFolder) {
            foreach ($request->file('images') as $img) {
                $imageMap[$img->getClientOriginalName()] = $img;
            }
        }

        /* 3. Verify CSV header */
        $file = fopen($request->file('csv_file')->getRealPath(), 'r');
        $header = array_map('trim', fgetcsv($file));
        $expected = [
            'Product Name', 'Product ID', 'Store Name', 'SKU', 'Category Name',
            'Unit Name', 'Supplier Name', 'Purchase Date', 'Quantity', 'Price',
            'Manufactured Date', 'Expiry Date', 'Image'
        ];
        if ($header !== $expected) {
            fclose($file);
            return back()->withErrors(['csv_file' => 'Header mismatch. Download a fresh dummy CSV.']);
        }

        /* 4. Helpers */
        $baseCount = Stock::count();
        $newCounter = 1;
        $pad = 3;
        $parseDate = fn($d) => $d ? Carbon::parse($d)->format('Y-m-d') : null;

        $rowsImported = 0;
        $conflicts = [];
        $missingImgs = [];
        $storeErrors = [];

        DB::beginTransaction();
        $rowNumber = 1;

        /* 5. Row loop */
        while (($row = fgetcsv($file)) !== false) {
            $rowNumber++;
            $row = array_map('trim', $row);
            if (!array_filter($row))
                continue;  // skip blank rows

            [
                $productName, $productIdCsv, $storeName, $sku, $categoryName,
                $unitName, $supplier, $purchase, $qty, $price,
                $mfgDate, $expDate, $imageFile
            ] = $row;

            /* store must pre‑exist */
            $store = Store::whereRaw('LOWER(name)=?', [strtolower($storeName)])->first();
            if (!$store) {
                $storeErrors[] = "Row $rowNumber: store '$storeName' does not exist";
                continue;
            }

            /* category & unit */
            $category = Category::firstOrCreate(['name' => $categoryName]);
            $unit = $unitName ? Unit::firstOrCreate(['name' => $unitName]) : null;

            /* duplicate SKU */
            if (Stock::where('store_id', $store->id)->where('sku', $sku)->exists()) {
                $conflicts[] = "Row $rowNumber: SKU '$sku' already exists in store '$storeName'";
                continue;
            }

            /* product id */
            $productId = 'P_' . str_pad($baseCount + $newCounter, $pad, '0', STR_PAD_LEFT);
            $newCounter++;

            /* image logic */
            $imagePath = null;
            if ($imageFile) {
                if ($hasImageFolder && isset($imageMap[$imageFile])) {
                    // image provided now
                    $imagePath = $imageMap[$imageFile]->storeAs('products', $imageFile, 'public');
                } else {
                    // image missing or folder not uploaded → mark as pending (raw filename)
                    $imagePath = $imageFile;
                    if ($hasImageFolder) {
                        $missingImgs[] = "Row $rowNumber: image '$imageFile' not found in uploaded folder";
                    }
                }
            }

            /* insert */
            $created = Stock::create([
                'store_id' => $store->id,
                'product_id' => $productId,
                'product_name' => $productName,
                'sku' => $sku,
                'category_id' => $category->id,
                'unit_id' => $unit?->id,
                'supplier_name' => $supplier,
                'purchase_date' => $parseDate($purchase),
                'manufactured_date' => $parseDate($mfgDate),
                'expiry_date' => $parseDate($expDate),
                'quantity' => is_numeric($qty) ? (int) $qty : 0,
                'price' => is_numeric($price) ? (float) $price : 0,
                'discount' => 0,
                'tax' => 0,
                'status' => 1,
                'images' => $imagePath,
            ]);

            // ✅ Store history
            storeHistory(
                'stock_import',
                'created',
                'stock',
                $created->id,
                $created->toArray(),
                null
            );

            $rowsImported++;
        }
        fclose($file);

        /* abort on unknown store */
        if ($storeErrors) {
            DB::rollBack();
            return back()->with(['storeErrors' => $storeErrors]);
        }
        DB::commit();

        /* summary */
        $message = "$rowsImported products imported.";
        if ($conflicts)
            $message .= ' Some rows skipped (duplicate SKUs).';
        if ($missingImgs)
            $message .= ' Some images were not found.';

        return back()->with([
            'success' => $message,
            'conflicts' => $conflicts,
            'missing' => $missingImgs,
        ]);
    }

    // public function uploadImages(Request $request)
    // {
    //     if (!hasPermission('create', 'stock')) {
    //         return view('admin.partials.authorisation');
    //     }
    //     // 1. Ensure at least one file was selected
    //     if (!$request->hasFile('images')) {
    //         return back()->withErrors(['images' => 'No images were uploaded.']);
    //     }

    //     // 2. Validate
    //     $request->validate([
    //         'images.*' => 'file|mimes:jpg,jpeg,png,webp,bmp,gif,svg,jfif'
    //     ]);

    //     $updated = 0;
    //     $notMatched = [];

    //     foreach ($request->file('images') as $image) {
    //         $filename = $image->getClientOriginalName();  // e.g. airpods.jpg

    //         // 3. Find stock where images column is either raw filename OR already prefixed
    //         $stock = Stock::where('images', $filename)
    //             ->orWhere('images', 'products/' . $filename)
    //             ->first();

    //         if (!$stock) {
    //             $notMatched[] = $filename;
    //             continue;
    //         }

    //         // 4. Store image to public/products/
    //         $storedPath = $image->storeAs('products', $filename, 'public');

    //         // 5. Update DB only if prefix missing OR file previously absent
    //         if (!Str::startsWith($stock->images, 'products/') ||
    //                 !Storage::disk('public')->exists($stock->images)) {
    //             $stock->update(['images' => $storedPath]);
    //         }

    //         $updated++;
    //     }

    //     /* 6. Build flash message */
    //     $msg = "$updated image(s) processed.";
    //     if ($notMatched) {
    //         return back()->with([
    //             'success' => $msg,
    //             'unmatched' => $notMatched  // show via SweetAlert
    //         ]);
    //     }

    //     return back()->with('success', $msg);
    // }
    public function uploadImages(Request $request)
    {
        if (!hasPermission('create', 'stock')) {
            return view('admin.partials.authorisation');
        }

        if (!$request->hasFile('images')) {
            return back()->withErrors(['images' => 'No images were uploaded.']);
        }

        $request->validate([
            'images.*' => 'file|mimes:jpg,jpeg,png,webp,bmp,gif,svg,jfif'
        ]);

        $updated = 0;
        $notMatched = [];

        foreach ($request->file('images') as $image) {
            $filename = $image->getClientOriginalName();  // e.g. wm.jpg

            // 🔹 Only match stocks where images == raw filename (NOT starting with products/)
            $stock = Stock::where('images', $filename)
                ->where(function ($q) {
                    $q
                        ->whereNull('images')
                        ->orWhereRaw("images NOT LIKE 'products/%'");
                })
                ->first();

            if (!$stock) {
                $notMatched[] = $filename;
                continue;
            }

            // Save file into /products
            $storedPath = $image->storeAs('products', $filename, 'public');

            // Update DB with prefixed path
            $stock->update(['images' => $storedPath]);

            $updated++;
        }

        $msg = "$updated image(s) processed.";
        if ($notMatched) {
            return back()->with([
                'success' => $msg,
                'unmatched' => $notMatched
            ]);
        }

        return back()->with('success', $msg);
    }

    public function downloadDummy()
    {
        $filename = 'dummy_stock_import.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $columns = [
            'Product Name',
            'Product ID',
            'Store Name',
            'SKU',
            'Category Name',
            'Unit Name',
            'Supplier Name',
            'Purchase Date',
            'Quantity',
            'Price',
            'Manufactured Date',
            'Expiry Date',
            'Image'
        ];

        $exampleRows = [
            ['T-Shirt', '', 'Main Store', 'SKU-001', 'Apparel', 'Pcs', 'Supplier A', '15-06-2024', '100', '250.00', '10-06-2024', '10-06-2025', 'tshirt.jpg'],
            ['Jeans', '', 'Main Store', 'SKU-002', 'Apparel', 'Pcs', 'Supplier B', '10-06-2024', '50', '800.00', '01-06-2024', '01-06-2026', 'jeans.png'],
            ['Bluetooth Speaker', '', 'Electronics Hub', 'SKU-003', 'Electronics', 'Box', 'Supplier C', '20-06-2024', '30', '1500.00', '05-06-2024', '05-06-2027', 'product1.png'],
            ['Notebook', '', 'Main Store', 'SKU-004', 'Stationery', 'Piece', 'Supplier D', '12-06-2024', '200', '50.00', '', '', 'product2.png'],
            ['Coffee Mug', '', 'Cafe Shop', 'SKU-005', 'Kitchenware', 'Piece', 'Supplier E', '18-06-2024', '80', '120.00', '15-06-2024', '15-06-2025', 'product3.png'],
        ];

        $callback = function () use ($columns, $exampleRows) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
            foreach ($exampleRows as $row) {
                fputcsv($file, $row);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    public function indexStoreManager(Request $request)
    {
        $units = Unit::all();
        $categories = Category::all();
        $sessionStoreId = session('selected_store_id');
        if ($request->ajax()) {
            $query = Stock::with(['store', 'category', 'unit'])->where('store_id', $sessionStoreId);

            if ($request->has('category') && $request->category !== 'choose') {
                $query->where('category_id', $request->category);
            }

            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }

            $stocks = $query->get();
            return datatables()
                ->of($stocks)
                ->addColumn('store_name', fn($row) => $row->store->name)
                ->addColumn('product', function ($row) {
                    $image = $row->images
                        ? asset('storage/' . $row->images)
                        : asset('admin/assets/img/avatar/default-product.png');

                    return '
                    <div class="productimgname">
                        <a href="javascript:void(0);" class="product-img stock-img">
                            <img src="' . $image . '" alt="product" />
                        </a>
                        <a href="javascript:void(0);">' . e($row->product_name) . '</a>
                    </div>';
                })
                ->addColumn('sku', fn($row) => $row->sku)
                ->addColumn('category', fn($row) => $row->category->name)
                ->addColumn('price', fn($row) => $row->price)
                ->addColumn('unit', fn($row) => $row->unit->name)
                ->addColumn('quantity', fn($row) => $row->quantity)
                ->addColumn('actions', function ($stock) {
                    $user = auth()->user();
                    if ($user) {
                        $editUrl = route('admin.stock.edit', $stock->id);
                        $editBtn = '
                            <a class=" p-2" href="' . $editUrl . '">
                                <i data-feather="edit" class="feather-edit"></i>
                            </a>
                        ';
                        $deleteBtn = '
                            <a href="javascript:void(0);" class="delete-stock confirm-text p-2" data-id="' . $stock->id . '">
                                <i data-feather="trash-2" class="feather-trash-2"></i>
                            </a>
                        ';

                        // Admin: show both edit and delete
                        return '<div class="edit-delete-action">' . $editBtn . $deleteBtn . '</div>';
                    }
                    return '';
                })
                ->rawColumns(['product', 'actions'])
                ->make(true);
        }

        return view('storemanager.stock-list', compact('categories', 'units'));
    }
}
