<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index()
    {
        $settings = Setting::all();
        return view('admin.setting', compact('settings'));
    }

    public function storeSetting(Request $request)
    {
        $settings = Setting::all();
        $rules = [];

        foreach ($settings as $setting) {
            $rules[$setting->key_name] = 'required|string|max:255';  // customize per setting type
        }

        $validated = $request->validate($rules);

        // Save each setting
        foreach ($settings as $setting) {
            $setting->value = $validated[$setting->key_name];
            $setting->save();
        }

        return back()->with('success', 'Settings updated successfully.');
    }
}
