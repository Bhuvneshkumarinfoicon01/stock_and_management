<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SalesAnalysisSuperAdminController extends Controller
{
    public function index(Request $request)
    {
        $stores = Store::orderBy('name')->get();
        $categories = Category::orderBy('name')->get();

        $data = [];

        if ($request->ajax()) {
            $storeId = $request->input('store_id');
            $categoryId = $request->input('category_id');

            $query = DB::table('orders')
                ->join('order_items', 'orders.id', '=', 'order_items.order_id')
                ->join('stocks', function ($join) {
                    $join
                        ->on('stocks.store_id', '=', 'orders.store_id')
                        ->on('stocks.product_id', '=', 'order_items.product_id');
                })
                ->where('orders.store_id', $storeId)
                ->when($categoryId, function ($query, $categoryId) {
                    return $query->where('stocks.category_id', $categoryId);
                })
                ->selectRaw("DATE_FORMAT(orders.created_at, '%b') as month, SUM(orders.total_price) as total")
                ->groupByRaw("DATE_FORMAT(orders.created_at, '%b')")
                ->orderByRaw('MIN(orders.created_at)');

            $data = $query->get();

            return response()->json($data);
        }

        return view('SuperAdmin.sales-analysis', compact('stores', 'categories'));
    }
}
