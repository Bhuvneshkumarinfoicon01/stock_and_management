<?php

namespace App\Http\Controllers\admin;

use App\Helpers\NotificationHelper;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $storeId = session('selected_store_id');  // Make sure you're saving it with this key
        $discount_percentage = User::where('role_id', 5)->value('max_discount');
        if (!$storeId) {
            return redirect()->back()->with('error', 'Please select a store first.');
        }
        $customers = Customer::get();
        $categories = Category::whereHas('stocks', function ($query) use ($storeId) {
            $query->where('store_id', $storeId);
        })->get();
        $categoryProductCounts = [];
        $categoryProducts = [];
        foreach ($categories as $category) {
            $categoryProductCounts[$category->id] = Stock::where('store_id', $storeId)
                ->where('category_id', $category->id)
                ->count();

            $categoryProducts[$category->id] = Stock::where('store_id', $storeId)
                ->where('category_id', $category->id)
                ->get();
        }
        return view('admin.orders.pos-terminal', compact('categories', 'categoryProductCounts', 'categoryProducts', 'customers', 'discount_percentage'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        \Log::info('Incoming Order Data:', $request->all());
        // Validate incoming data
        $request->validate([
            'store_from' => 'required|exists:stores,id',
            'store_to' => 'required|exists:stores,id|different:store_from',
            'rperson_from' => 'required|string',
            'rperson_to' => 'required|string',
            'product_id.*' => 'required|exists:stocks,id',
            'product_name.*' => 'required|string',
            'sku.*' => 'required|string',
            'qty.*' => 'required|integer|min:1',
            'category_id.*' => 'nullable|exists:categories,id',
        ]);

        // Proceed to store order after validation
        DB::beginTransaction();  // Start transaction to ensure data consistency

        try {
            // Step 1: Create Order
            $order = Order::create([
                'store_from' => $request->store_from,
                'store_to' => $request->store_to,
                'rperson_from' => $request->rperson_from,
                'rperson_to' => $request->rperson_to,
                'reference_no' => time(),  // Unique reference number
                'notes' => $request->notes,
            ]);

            // Step 2: Add Order Items
            foreach ($request->product_id as $key => $productId) {
                \App\Models\OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $productId,
                    'product_name' => $request->product_name[$key],
                    'sku' => $request->sku[$key],
                    'qty' => $request->qty[$key],
                    'category_id' => $request->category_id[$key],
                ]);

                // Step 3: Update Stock for Source Store
                $stock = Stock::where('store_id', $request->store_from)
                    ->where('product_id', $productId)
                    ->first();

                if ($stock) {
                    $stock->decrement('quantity', $request->qty[$key]);
                }

                // Step 4: Update or Create Stock in Destination Store
                $destinationStock = Stock::where('store_id', $request->store_to)
                    ->where('product_id', $productId)
                    ->first();

                if ($destinationStock) {
                    $destinationStock->increment('quantity', $request->qty[$key]);
                } else {
                    Stock::create([
                        'store_id' => $request->store_to,
                        'product_id' => $productId,
                        'product_name' => $request->product_name[$key],
                        'sku' => $request->sku[$key],
                        'category_id' => $request->category_id[$key],
                        'quantity' => $request->qty[$key],
                    ]);
                }
            }

            DB::commit();  // Commit transaction
            return response()->json(['success' => true, 'message' => 'Order placed successfully!']);
        } catch (\Exception $e) {
            DB::rollBack();  // Rollback on error
            return response()->json(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    public function getStores()
    {
        $stores = Store::where('status', 1)->get();
        return response()->json($stores);
    }

    public function getProductsByStore(Request $request)
    {
        $storeId = $request->store_id;
        $query = $request->input('query', '');
        if (!$storeId) {
            return response()->json(['error' => 'Store ID is required!'], 400);
        }
        $products = \DB::table('stocks')
            ->where('store_id', $storeId)
            ->where(function ($q) use ($query) {
                $q
                    ->where('product_name', 'LIKE', "%{$query}%")
                    ->orWhere('sku', 'LIKE', "%{$query}%");
            })
            ->join('categories', 'stocks.category_id', '=', 'categories.id')
            ->selectRaw('
                stocks.id,
                stocks.product_name,
                stocks.sku,
                categories.name as category_name,
                SUM(stocks.quantity) as total_quantity
            ')
            ->groupBy('stocks.id', 'stocks.product_name', 'stocks.sku', 'categories.name')
            ->get();
        return response()->json($products);
    }

    // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function addToCart(Request $request)
    {
        $cart = session()->get('cart', []);

        $productId = $request->product_id;
        $quantity = $request->quantity ?? 1;  // Default quantity is 1

        if (isset($cart[$productId])) {
            $cart[$productId]['quantity'] = $quantity;
        } else {
            $cart[$productId] = [
                'product_id' => $productId,
                'product_name' => $request->product_name,
                'price' => $request->price,
                'image' => $request->image,
                'quantity' => $quantity,
                'sku' => $request->sku,
                'category_id' => $request->category_id,
                // 'total_price' => $quantity * $request->price,
            ];
        }

        session()->put('cart', $cart);
        return response()->json(['success' => true, 'cart' => $cart]);
    }

    // ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function getCart()
    {
        $cart = Session::get('cart', []);
        return response()->json(['cart' => $cart]);
    }

    // /////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function updateProduct(Request $request)
    {
        $validated = $request->validate([
            'product_id' => 'required|integer|exists:products,id',
            'product_name' => 'required|string|max:255',
            'tax' => 'required|numeric',
            'discount' => 'required|numeric',
            'sale_unit' => 'required|string|max:255',
        ]);
        $product = Product::findOrFail($request->product_id);

        $product->update([
            'product_name' => $request->product_name,
            'tax' => $request->tax,
            'discount' => $request->discount,
            'sale_unit' => $request->sale_unit,
        ]);
        return response()->json(['success' => true, 'product' => $product]);
    }

    public function removeFromCart(Request $request)
    {
        $cart = session()->get('cart', []);

        if (isset($cart[$request->product_id])) {
            unset($cart[$request->product_id]);
            session()->put('cart', $cart);
        }

        return response()->json(['success' => true]);
    }

    public function clearCart()
    {
        session()->forget('cart');  // Clear cart session
        return response()->json(['message' => 'Cart cleared successfully']);
    }

    // public function placeOrder(Request $request)
    // {
    //     $request->validate([
    //         'store_id' => 'nullable|integer',
    //         'customer_id' => 'required|integer',
    //         'customer_name' => 'required|string',
    //         'subtotal_price' => 'required|numeric',
    //         'total_price' => 'required|numeric',
    //         'payment_method' => 'required|string',
    //         'items' => 'required|array|min:1',
    //     ]);

    //     DB::beginTransaction();

    //     try {
    //         $storeId = session('selected_store_id');

    //         //  Step 1: Validate stock availability
    //         foreach ($request->items as $item) {
    //             $stock = Stock::where('store_id', $storeId)
    //                 ->where('product_id', $item['product_id'])
    //                 ->first();

    //             if (!$stock || $stock->quantity < $item['qty']) {
    //                 DB::rollBack();
    //                 return response()->json([
    //                     'success' => false,
    //                     'message' => "Insufficient stock for product: {$item['product_name']} (SKU: {$item['sku']})",
    //                 ], 400);
    //             }
    //         }

    //         //  Step 2: Create Order
    //         $order = Order::create([
    //             'store_id' => $storeId,
    //             'customer_id' => $request->customer_id,
    //             'customer_name' => $request->customer_name,
    //             'subtotal_price' => $request->subtotal_price,
    //             'total_price' => $request->total_price,
    //             'tax' => $request->tax ?? 0,
    //             'discount' => $request->discount ?? 0,
    //             'shipping' => $request->shipping ?? 0,
    //             'payment_method' => $request->payment_method,
    //             'notes' => $request->notes ?? null,
    //             'type' => $request->type ?? 'online',
    //         ]);

    //         //  Step 3: Insert Order Items and update stock
    //         foreach ($request->items as $item) {
    //             OrderItem::create([
    //                 'order_id' => $order->id,
    //                 'product_id' => $item['product_id'],
    //                 'product_name' => $item['product_name'],
    //                 'sku' => $item['sku'],
    //                 'qty' => $item['qty'],
    //                 'category_id' => $item['category_id'],
    //                 'price' => $item['price'],
    //             ]);

    //             // Reduce stock
    //             Stock::where('store_id', $storeId)
    //                 ->where('product_id', $item['product_id'])
    //                 ->decrement('quantity', $item['qty']);
    //         }

    //         DB::commit();
    //         session()->forget('cart');
    //         // NOTIFICATION

    //         $userId = auth()->id();
    //         $message = 'New Order has been created.';  // Custom message
    //         $userName = auth()->user()->name;
    //         $port = env('NOTIFICATION_PORT');
    //         $url = "http://localhost:$port/notify";
    //         $response = Http::post($url, [
    //             'userId' => $userId,
    //             'message' => $message,
    //             'user_name' => $userName,
    //         ]);
    //         NotificationHelper::add(auth()->id(), $message);

    //         return response()->json(['success' => true, 'message' => 'Order placed successfully!']);
    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Order placement failed!',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }
    public function placeOrder(Request $request)
    {
        // if (auth()->user()->role_id != 5) {
        if (!hasPermission('create', 'order')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized access.'], 403);
        }
        // }
        $request->validate([
            'store_id' => 'nullable|integer',
            'customer_id' => 'required|integer',
            'customer_name' => 'required|string',
            'subtotal_price' => 'required|numeric',
            'total_price' => 'required|numeric',
            'payment_method' => 'required|string',
            'items' => 'required|array|min:1',
        ]);

        DB::beginTransaction();

        try {
            $storeId = session('selected_store_id');

            // 1. Validate stock availability
            foreach ($request->items as $item) {
                $stock = Stock::where('store_id', $storeId)
                    ->where('product_id', $item['product_id'])
                    ->first();

                if (!$stock || $stock->quantity < $item['qty']) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => "Insufficient stock for {$item['product_name']} (SKU {$item['sku']})",
                    ], 400);
                }
            }

            // 2. Create Order
            $order = Order::create([
                'store_id' => $storeId,
                'customer_id' => $request->customer_id,
                'customer_name' => $request->customer_name,
                'subtotal_price' => $request->subtotal_price,
                'total_price' => $request->total_price,
                'tax' => $request->tax ?? 0,
                'discount' => $request->discount ?? 0,
                'shipping' => $request->shipping ?? 0,
                'payment_method' => $request->payment_method,
                'notes' => $request->notes ?? null,
                'type' => $request->type ?? 'online',
            ]);

            // 3. Insert Order Items and update stock
            $orderItems = [];
            $newStocks = [];

            foreach ($request->items as $item) {
                $orderItems[] = OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['product_id'],
                    'product_name' => $item['product_name'],
                    'sku' => $item['sku'],
                    'qty' => $item['qty'],
                    'category_id' => $item['category_id'],
                    'price' => $item['price'],
                ])->toArray();

                Stock::where('store_id', $storeId)
                    ->where('product_id', $item['product_id'])
                    ->decrement('quantity', $item['qty']);

                $newStocks[$item['product_id']] = Stock::where('store_id', $storeId)
                    ->where('product_id', $item['product_id'])
                    ->first()
                    ->toArray();
            }

            // 4. Store in history (only new)
            storeHistory(
                'pos_order_form',
                'created',
                'order',
                $order->id,
                [
                    'order' => $order->toArray(),
                    'items' => $orderItems,
                    // 'stock_after' => $newStocks,
                ],
                null
            );

            DB::commit();
            session()->forget('cart');

            // 5. Notification only for POS/online orders (not when creating an invoice)
            $isInvoice = ($request->type ?? 'online') === 'offline';
            if (! $isInvoice) {
                $userId = auth()->id();
                $message = 'New order has been created.';
                NotificationHelper::add($userId, $message);
                NotificationHelper::pushRealtime($userId, $message);
            }

            return response()->json(['success' => true, 'message' => 'Order placed successfully!']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Order placement failed!',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    // ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public function manageTransactions()
    {
        $storeId = session('selected_store_id');

        $transactions = Order::with('orderItems')
            ->where('store_id', $storeId)
            ->where('type', 'online')
            ->latest()
            ->get();

        return view('admin.transaction-manage', compact('transactions'));
    }

    public function getOrderItems($id)
    {
        $order = Order::with('orderItems')->find($id);

        if (!$order) {
            return response()->json(['error' => 'Order not found'], 404);
        }

        $subTotal = floatval($order->subtotal_price);
        $discount = floatval($order->discount);
        $shipping = floatval($order->shipping);
        $tax = floatval($order->tax);

        // Calculate discount and tax amounts and shipping amount
        $discountAmount = ($discount / 100) * $subTotal;
        $taxAmount = ($tax / 100) * $subTotal;
        $shippingAmount = ($shipping / 100) * $subTotal;

        $totalBill = $subTotal - $discountAmount + $shippingAmount + $taxAmount;
        $totalPayable = $totalBill;

        return response()->json([
            'sub_total' => $subTotal,
            'discount' => $discount,
            'discount_amount' => $discountAmount,
            'shipping' => $shipping,
            'shipping_amount' => $shippingAmount,
            'tax' => $tax,
            'tax_amount' => $taxAmount,
            'total_bill' => $totalBill,
            'total_payable' => $totalPayable,
            'items' => $order->orderItems->map(function ($item) {
                return [
                    'product_name' => $item->product_name,
                    'price' => floatval($item->price),
                    'qty' => intval($item->qty),
                ];
            }),
        ]);
    }

    public function invoiceOrderCreate(Request $request)
    {
        // if (auth()->user()->role_id != 5) {
        if (!hasPermission('create', 'order')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized access.'], 403);
        }
        // }
        $storeId = session('selected_store_id');

        // Extract arrays from the request
        $productIds = $request->input('product_id', []);
        $productNames = $request->input('product_name', []);
        $skus = $request->input('sku', []);
        $categories = $request->input('category_id', []);
        $quantities = $request->input('qty', []);
        $prices = $request->input('price', []);

        $items = [];
        $subtotal = 0;

        for ($i = 0; $i < count($productIds); $i++) {
            $qty = (float) $quantities[$i];
            $price = (float) $prices[$i];
            $lineTotal = $qty * $price;

            $items[] = [
                'product_id' => $productIds[$i],
                'product_name' => $productNames[$i],
                'sku' => $skus[$i],
                'category_id' => $categories[$i],
                'qty' => $qty,
                'price' => $price,
            ];

            $subtotal += $lineTotal;
        }

        $tax = (float) $request->input('tax', 0);
        $discount = (float) $request->input('discount', 0);
        $shipping = (float) $request->input('shipping', 0);

        // Calculate grand total
        $total = $subtotal + ($subtotal * $tax / 100) - ($subtotal * $discount / 100) + $shipping;

        // Prepare data to pass to placeOrder
        $orderData = new Request([
            'store_id' => $storeId,
            'customer_id' => $request->customer_id,
            'customer_name' => Customer::find($request->customer_id)?->customer_name,
            'subtotal_price' => round($subtotal, 2),
            'total_price' => round($total, 2),
            'tax' => $tax,
            'discount' => $discount,
            'shipping' => $shipping,
            'payment_method' => $request->payment_method,
            'type' => 'offline',
            'items' => $items,
        ]);

        // storeHistory(
        //     'invoice_order_form',  // key
        //     'created',  // event
        //     'invoice_order',  // entity type
        //     null,  // entity id (none yet)
        //     $orderData->all(),  // new values
        //     null  // no old values
        // );

        return $this->placeOrder($orderData);
    }

    // public function invoiceOrderUpdate(Request $request)
    // {
    //     DB::beginTransaction();

    //     try {
    //         $orderId = $request->input('order_id');
    //         $order = Order::with('orderItems')->findOrFail($orderId);

    //         // Reverse previous stock changes
    //         foreach ($order->orderItems as $oldItem) {
    //             Stock::where('store_id', $order->store_id)
    //                 ->where('product_id', $oldItem->product_id)
    //                 ->increment('quantity', $oldItem->qty);
    //         }

    //         // Delete old items
    //         OrderItem::where('order_id', $orderId)->delete();

    //         // Recalculate items and subtotal
    //         $items = [];
    //         $subtotal = 0;

    //         $productIds = $request->input('product_id', []);
    //         $productNames = $request->input('product_name', []);
    //         $skus = $request->input('sku', []);
    //         $quantities = $request->input('qty', []);
    //         $prices = $request->input('price', []);
    //         $categories = $request->input('category_id', []);

    //         for ($i = 0; $i < count($productIds); $i++) {
    //             $qty = (float) $quantities[$i];
    //             $price = (float) $prices[$i];
    //             $lineTotal = $qty * $price;

    //             $items[] = [
    //                 'order_id' => $orderId,
    //                 'product_id' => $productIds[$i],
    //                 'product_name' => $productNames[$i],
    //                 'sku' => $skus[$i],
    //                 'category_id' => $categories[$i],
    //                 'qty' => $qty,
    //                 'price' => $price,
    //                 'created_at' => now(),
    //                 'updated_at' => now(),
    //             ];

    //             $subtotal += $lineTotal;

    //             // Decrease stock
    //             Stock::where('store_id', $order->store_id)
    //                 ->where('product_id', $productIds[$i])
    //                 ->decrement('quantity', $qty);
    //         }

    //         OrderItem::insert($items);

    //         // Tax, discount, and total calculation
    //         $tax = (float) $request->input('tax', 0);
    //         $discount = (float) $request->input('discount', 0);
    //         $shipping = 0;

    //         $total = $subtotal + ($subtotal * $tax / 100) - ($subtotal * $discount / 100) + $shipping;

    //         $order->update([
    //             'customer_id' => $request->input('customer_id'),
    //             'subtotal_price' => round($subtotal, 2),
    //             'total_price' => round($total, 2),
    //             'tax' => $tax,
    //             'discount' => $discount,
    //             'payment_method' => $request->input('payment_method'),
    //         ]);

    //         DB::commit();

    //         return response()->json(['success' => true, 'message' => 'Invoice updated successfully.']);
    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         return response()->json(['success' => false, 'message' => 'Update failed: ' . $e->getMessage()]);
    //     }
    // }
    public function invoiceOrderUpdate(Request $request)
    {
        // if (auth()->user()->role_id != 5) {
        if (!hasPermission('update', 'order')) {
            return response()->json(['success' => false, 'message' => 'Unauthorized access.'], 403);
        }
        // }
        DB::beginTransaction();

        try {
            /* ────── 1  Fetch order and old snapshots ────── */
            $orderId = $request->input('order_id');
            $order = Order::with('orderItems')->findOrFail($orderId);

            $oldOrder = $order->toArray();
            $oldItems = $order->orderItems->keyBy('product_id')->toArray();

            /* ────── 2  Reverse previous stock changes ────── */
            foreach ($order->orderItems as $oldItem) {
                Stock::where('store_id', $order->store_id)
                    ->where('product_id', $oldItem->product_id)
                    ->increment('quantity', $oldItem->qty);
            }

            /* ────── 3  Delete old items ────── */
            OrderItem::where('order_id', $orderId)->delete();

            /* ────── 4  Rebuild items & adjust stock ────── */
            $items = [];
            $subtotal = 0;
            $newStocks = [];

            $productIds = $request->input('product_id', []);
            $productNames = $request->input('product_name', []);
            $skus = $request->input('sku', []);
            $quantities = $request->input('qty', []);
            $prices = $request->input('price', []);
            $categories = $request->input('category_id', []);

            for ($i = 0; $i < count($productIds); $i++) {
                $qty = (float) $quantities[$i];
                $price = (float) $prices[$i];
                $subtotal += $qty * $price;

                $items[] = [
                    'order_id' => $orderId,
                    'product_id' => $productIds[$i],
                    'product_name' => $productNames[$i],
                    'sku' => $skus[$i],
                    'category_id' => $categories[$i],
                    'qty' => $qty,
                    'price' => $price,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];

                Stock::where('store_id', $order->store_id)
                    ->where('product_id', $productIds[$i])
                    ->decrement('quantity', $qty);

                // snapshot stock after decrement
                $newStocks[$productIds[$i]] = Stock::where('store_id', $order->store_id)
                    ->where('product_id', $productIds[$i])
                    ->first()
                    ->toArray();
            }

            OrderItem::insert($items);

            /* ────── 5  Recompute totals & update order ────── */
            $tax = (float) $request->input('tax', 0);
            $discount = (float) $request->input('discount', 0);
            $shipping = 0;

            $total = $subtotal + ($subtotal * $tax / 100) - ($subtotal * $discount / 100) + $shipping;

            $order->update([
                'customer_id' => $request->input('customer_id'),
                'subtotal_price' => round($subtotal, 2),
                'total_price' => round($total, 2),
                'tax' => $tax,
                'discount' => $discount,
                'payment_method' => $request->input('payment_method'),
            ]);

            /* ────── 6  New snapshots ────── */
            $newOrder = $order->fresh()->toArray();
            $newItems = OrderItem::where('order_id', $orderId)->get()->keyBy('product_id')->toArray();

            /* ────── 7  Audit trail ────── */
            $masterNew = array_diff_assoc_recursive($newOrder, $oldOrder);
            $masterOld = array_diff_assoc_recursive($oldOrder, $newOrder);

            $itemsNew = array_diff_assoc_recursive($newItems, $oldItems);
            $itemsOld = array_diff_assoc_recursive($oldItems, $newItems);

            storeHistory(
                'pos_order_form',
                'updated',
                'order',
                $orderId,
                ['order' => $masterNew, 'items' => $itemsNew, 'stock_after' => $newStocks],
                ['order' => $masterOld, 'items' => $itemsOld]
            );

            DB::commit();

            return response()->json(['success' => true, 'message' => 'Invoice updated successfully.']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Update failed: ' . $e->getMessage()]);
        }
    }
}
