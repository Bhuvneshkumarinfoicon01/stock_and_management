<?php

namespace App\Http\Controllers\admin;

use App\Helpers\NotificationHelper;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class CustomerController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required',
            'country' => 'required|string|max:100',
            'city' => 'required|string|max:100',
            'address' => 'required|string|max:255',
            'description' => 'nullable|string|max:60',
        ]);

        try {
            $customer = Customer::create([
                'customer_name' => $request->input('customer_name'),
                'email' => $request->input('email'),
                'phone' => $request->input('phone'),
                'country' => $request->input('country'),
                'city' => $request->input('city'),
                'address' => $request->input('address'),
                'description' => $request->input('description'),
            ]);
            storeHistory(
                'customer_form',
                'created',
                'customer',
                $customer->id,
                $customer->toArray(),
                []
            );
            $userId = auth()->id();
            $message = 'New Customer has been Added.';
            NotificationHelper::add($userId, $message);
            NotificationHelper::pushRealtime($userId, $message);

            return response()->json([
                'success' => true,
                'message' => 'Customer added successfully!',
                'data' => $customer
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to add customer!',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function index(Request $request)
    {
        $countryList = config('countries');
        if ($request->ajax()) {
            $query = Customer::query();

            if ($request->has('country') && $request->country !== 'choose') {
                $query->where('country', $request->country);
            }
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }

            $customer = $query->get();
            return datatables()
                ->eloquent($query)
                ->editColumn('customer_name', fn($row) => $row->customer_name)
                ->editColumn('code', fn($row) => $row->id)
                ->editColumn('email', fn($row) => $row->email)
                ->editColumn('phone', fn($row) => $row->phone)
                ->editColumn('city', fn($row) => $row->city)
                ->editColumn('country', fn($row) => $row->country)
                ->editColumn('action', function ($customer) {
                    return '
                            <div class="edit-delete-action">
                                <a class="me-2 p-2 viewCustomer" href="#" data-id="' . $customer->id . '" 
                                  data-bs-toggle="modal" data-bs-target="#view-customer">         
                                  <i data-feather="eye" class="feather-eye"></i>
                                </a>                 
                                <a class="me-2 p-2 editCustomer" href="#" data-id="' . $customer->id . '"
                                   data-bs-toggle="modal" data-bs-target="#edit-units">         
                                    <i data-feather="edit" class="feather-edit"></i>
                                 </a>                   
                                <a class="confirm-text p-2 deleteCustomer" href="javascript:void(0);"
                                    data-id="' . $customer->id . '">        
                                    <i data-feather="trash-2" class="feather-trash-2" ></i >    
                                 </a>                   
                            </div>                    
                        ';
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('storemanager.customer', compact('countryList'));
    }

    public function viewCustomer(Request $request)  // VIEW EMPLOYEE FUNCTION
    {
        $customer = Customer::find($request->empId);

        if ($customer) {
            return response()->json([
                'success' => true,
                'data' => $customer,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Employee not found!',
            ]);
        }
    }

    public function editCustomer(Request $request)  // EDIT EMPLOYEE FUNCTION
    {
        $customer = Customer::find($request->empId);

        if (!$customer) {
            return response()->json(['success' => false, 'message' => 'Employee not found!']);
        }
        return response()->json([
            'success' => true,
            'data' => $customer,
        ]);
    }

    public function updateCustomer(Request $request)  // UPDATE EMPLOYEE FUNCTION
    {
        // dd($request->all());
        $customer = Customer::find($request->id);
        // print_r($request->id);
        if (!$customer) {
            return response()->json([
                'success' => false,
                'message' => 'Customer not found!',
            ], 404);
        }
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:15',
        ]);
        $oldPayload = $customer->toArray();
        $customer->customer_name = $request->input('customer_name');
        $customer->email = $request->input('email');
        $customer->phone = $request->input('phone');
        $customer->address = $request->input('address');
        $customer->country = $request->input('country');
        $customer->city = $request->input('city');
        $customer->description = $request->input('description');
        $customer->save();
        $newPayload = $customer->toArray();
        storeHistory(
            'customer_form',  // key
            'updated',  // event
            'customer',  // entity type
            $customer->id,  // entity id
            $newPayload,  // new values
            $oldPayload  // old values
        );
        $userId = auth()->id();
        $message = 'Customer (' . $customer->customer_name . ') has been Updated.';
        NotificationHelper::add($userId, $message);
        NotificationHelper::pushRealtime($userId, $message);
        return response()->json(['success' => true, 'message' => 'Customer updated successfully.']);
    }

    public function deleteCustomer(Request $request)
    {
        $customer = Customer::findOrFail($request->empId);
        if (!$customer) {
            return response()->json(['success' => false, 'message' => 'Customer not found!']);
        }
        $oldPayload = $customer->toArray();
        if ($customer->profile_image) {
            Storage::disk('public')->delete($customer->profile_image);
        }
        $customer->delete();
        storeHistory(
            'customer_form',  // key
            'deleted',  // event
            'customer',  // entity type
            $request->empId,  // entity ID
            [],  // new data (empty for delete)
            $oldPayload  // old data
        );
        $userId = auth()->id();
        $message = 'Customer (' . $customer->customer_name . ') has been Deleted.';
        NotificationHelper::add($userId, $message);
        NotificationHelper::pushRealtime($userId, $message);
        return response()->json(['success' => true, 'message' => 'Employee deleted successfully!']);
    }
}
