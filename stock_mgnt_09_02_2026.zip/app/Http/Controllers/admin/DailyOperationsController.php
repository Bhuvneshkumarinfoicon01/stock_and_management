<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Stock;
use App\Models\StockTransfer;
use App\Models\StockTransferItem;
use App\Models\Store;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DailyOperationsController extends Controller
{
    public function index(Request $request)
    {
        $storeId = session('selected_store_id');
        $sort = $request->get('sort', 'newest');
        if ($request->ajax()) {
            $storeId = $request->store_id;
            $sort = $request->sort ?? 'newest';

            $query = StockTransfer::with('storeFrom', 'storeTo', 'items');

            if ($storeId) {
                $query->where(function ($q) use ($storeId) {
                    $q
                        ->whereHas('storeFrom', fn($q) => $q->where('id', $storeId))
                        ->orWhereHas('storeTo', fn($q) => $q->where('id', $storeId));
                });
            }
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }
            // Filter for records created within the last 24 hours
            $query->where('created_at', '>=', Carbon::now()->subDay());

            $query->orderBy('created_at', $sort === 'newest' ? 'desc' : 'asc');
            $orderItems = $query->get();
            return datatables()
                ->of($orderItems)
                ->addColumn('store_from', fn($row) => $row->storeFrom->name ?? '-')
                ->addColumn('store_to', fn($row) => $row->storeTo->name ?? '-')
                ->addColumn('item_name', fn($row) => $row->items->pluck('product_name')->implode(', '))
                ->addColumn('item_qty', fn($row) => $row->items->pluck('qty')->implode(', '))
                ->make(true);
        }

        $categoryData = Category::withCount(['stocks as product_count' => function ($query) use ($storeId) {
            $query
                ->where('store_id', $storeId)
                ->where('quantity', '>', 0);  // Exclude stocks with 0 quantity
        }])
            ->get()
            ->map(function ($category) {
                return [
                    'name' => $category->name,
                    'count' => $category->product_count,  // Use the alias
                ];
            });

        return view('SuperAdmin.daily-operations-overview', compact('categoryData'));
    }

    public function dailyoperations(Request $request)
    {
        $storeId = session('selected_store_id');
        $sort = $request->get('sort', 'newest');
        if ($request->ajax()) {
            $storeId = $request->store_id;
            $sort = $request->sort ?? 'newest';

            $query = StockTransfer::with('storeFrom', 'storeTo', 'items');

            if ($storeId) {
                $query->where(function ($q) use ($storeId) {
                    $q
                        ->whereHas('storeFrom', fn($q) => $q->where('id', $storeId))
                        ->orWhereHas('storeTo', fn($q) => $q->where('id', $storeId));
                });
            }
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $query->orderBy('created_at', $request->order_type);
            }
            // Filter for records created within the last 24 hours
            $query->where('created_at', '>=', Carbon::now()->subDay());

            $query->orderBy('created_at', $sort === 'newest' ? 'desc' : 'asc');
            $orderItems = $query->get();
            return datatables()
                ->of($orderItems)
                ->addColumn('store_from', fn($row) => $row->storeFrom->name ?? '-')
                ->addColumn('store_to', fn($row) => $row->storeTo->name ?? '-')
                ->addColumn('item_name', fn($row) => $row->items->pluck('product_name')->implode(', '))
                ->addColumn('item_qty', fn($row) => $row->items->pluck('qty')->implode(', '))
                ->make(true);
        }

        $categoryData = Category::withCount(['stocks as product_count' => function ($query) use ($storeId) {
            $query
                ->where('store_id', $storeId)
                ->where('quantity', '>', 0);  // Exclude stocks with 0 quantity
        }])
            ->get()
            ->map(function ($category) {
                return [
                    'name' => $category->name,
                    'count' => $category->product_count,  // Use the alias
                ];
            });

        return view('admin.daily-operations-overview', compact('categoryData'));
    }

    public function dailySalesOverview(Request $request)
    {
        $storeId = session('selected_store_id');

        if ($request->ajax()) {
            $salesData = OrderItem::with(['order',
                    'stock' => function ($query) use ($storeId) {
                        $query->where('store_id', $storeId);
                    }])
                ->whereHas('order', function ($query) use ($storeId) {
                    $query->where('store_id', $storeId);
                });
            if ($request->has('order_type') && in_array($request->order_type, ['asc', 'desc'])) {
                $salesData->orderBy('created_at', $request->order_type);
            }
            $salesData->where('created_at', '>=', Carbon::now()->subDay());
            return datatables()
                ->eloquent($salesData)
                ->addColumn('sku', fn($row) => $row->sku ?? '-')
                ->addColumn('product_name', fn($row) => $row->product_name ?? '-')
                ->addColumn('price', fn($row) => '$' . number_format($row->price, 2) ?? '-')
                ->addColumn('qty', fn($row) => $row->qty ?? '-')
                ->addColumn('totalPrice', fn($row) => '$' . number_format($row->qty * $row->price, 2) ?? '-')
                ->make(true);
        }
    }
}
