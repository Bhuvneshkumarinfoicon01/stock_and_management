<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'address', 'city', 'state', 'zipcode', 'phone', 'email', 'status'
    ];

    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }

    public function assignedUsers()
    {
        return $this->hasMany(User::class, 'assigned_store', 'id');
    }
}
