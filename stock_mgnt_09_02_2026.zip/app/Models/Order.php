<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'store_id',
        // 'product_id',
        'customer_id',
        // 'product_name',
        'customer_name',
        // 'quantity',
        'total_price',
        'subtotal_price',
        'tax',
        'shipping',
        'discount',
        'payment_method',
        'notes',
        'type',
    ];

    protected $casts = [
        'created_at' => 'datetime',  // Ensure the created_at field is treated as a Carbon instance
    ];

    public function orderItems()
    {
        return $this
            ->hasMany(OrderItem::class, 'order_id', 'id');
    }

    public function store()
    {
        return $this->belongsTo(Store::class, 'store_id')->withDefault();
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id')->withDefault();
    }

    public function getQuantityAttribute()
    {
        return $this->orderItems()->sum('qty');
    }
}
