<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    protected $fillable = [
        'store_id', 'product_id', 'product_name', 'sku', 'category_id', 'unit_id', 'supplier_name',
        'purchase_date', 'description', 'quantity', 'price', 'discount', 'tax', 'manufactured_date',
        'expiry_date', 'images'
    ];

    public function store()
    {
        return $this->belongsTo(Store::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function unit()
    {
        return $this->belongsTo(Unit::class);
    }

    public function adjustments()
    {
        return $this->hasMany(StockAdjustment::class, 'product_id');
    }

    public function orderItems()
    {
        return $this
            ->hasMany(OrderItem::class, 'product_id', 'product_id');
    }
}
